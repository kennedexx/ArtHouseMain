"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, X, Plus, ArrowLeftRight, Download, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"

export default function ComparadorTexturas() {
  const [selectedTexturas, setSelectedTexturas] = useState<string[]>([
    "/catalog-images/texturas-129.jpg",
    "/catalog-images/texturas-130.jpg",
  ])
  const [viewMode, setViewMode] = useState<"grid" | "side-by-side">("grid")

  const texturas = [
    { id: "textura-1", nome: "Mármore Bege", imagem: "/catalog-images/texturas-129.jpg", codigo: "VR980304R" },
    { id: "textura-2", nome: "Linho Cinza", imagem: "/catalog-images/texturas-130.jpg", codigo: "5E050704" },
    { id: "textura-3", nome: "Azul Profundo", imagem: "/catalog-images/texturas-131.jpg", codigo: "CLASSY06" },
    { id: "textura-4", nome: "Floral Bege", imagem: "/catalog-images/texturas-132.jpg", codigo: "NN590902R" },
    { id: "textura-5", nome: "Damasco Cinza", imagem: "/catalog-images/texturas-133.jpg", codigo: "VR981303T" },
    { id: "textura-6", nome: "Concreto Desgastado", imagem: "/catalog-images/texturas-134.jpg", codigo: "AD200602R" },
    { id: "textura-7", nome: "Metálico Listrado", imagem: "/catalog-images/texturas-135.jpg", codigo: "BR208003R" },
    { id: "textura-8", nome: "Blocos de Concreto", imagem: "/catalog-images/texturas-136.jpg", codigo: "AD201301R" },
    { id: "textura-9", nome: "Terrazzo", imagem: "/catalog-images/texturas-137.jpg", codigo: "BR205005R" },
    { id: "textura-10", nome: "Linho Premium", imagem: "/catalog-images/texturas-138.jpg", codigo: "CR333016R" },
    { id: "textura-11", nome: "Mármore Cinza", imagem: "/catalog-images/texturas-1.jpg", codigo: "MT300602R" },
    { id: "textura-12", nome: "Linho Premium", imagem: "/catalog-images/texturas-4.jpg", codigo: "CR333030R" },
    { id: "textura-13", nome: "Concreto Industrial", imagem: "/catalog-images/texturas-109.jpg", codigo: "VR980106R" },
    { id: "textura-14", nome: "Listrado Vertical", imagem: "/catalog-images/texturas-110.jpg", codigo: "VR982004T" },
    { id: "textura-15", nome: "Tons Suaves", imagem: "/catalog-images/texturas-111.jpg", codigo: "AD201101R" },
    { id: "textura-16", nome: "Geométrico Losangos", imagem: "/catalog-images/texturas-112.jpg", codigo: "MT300402R" },
    { id: "textura-17", nome: "Pedra Natural", imagem: "/catalog-images/texturas-113.jpg", codigo: "EL501008R" },
    { id: "textura-18", nome: "Madeira Natural", imagem: "/catalog-images/texturas-114.jpg", codigo: "GR400102R" },
    { id: "textura-19", nome: "Círculos Relevo", imagem: "/catalog-images/texturas-115.jpg", codigo: "MT301105R" },
    { id: "textura-20", nome: "Listras Verticais", imagem: "/catalog-images/texturas-116.jpg", codigo: "EL500408R" },
  ]

  const handleAddTextura = (textura: string) => {
    if (selectedTexturas.length < 4 && !selectedTexturas.includes(textura)) {
      setSelectedTexturas([...selectedTexturas, textura])
    }
  }

  const handleRemoveTextura = (index: number) => {
    const newTexturas = [...selectedTexturas]
    newTexturas.splice(index, 1)
    setSelectedTexturas(newTexturas)
  }

  const handleReplaceTextura = (index: number, textura: string) => {
    if (!selectedTexturas.includes(textura)) {
      const newTexturas = [...selectedTexturas]
      newTexturas[index] = textura
      setSelectedTexturas(newTexturas)
    }
  }

  const getTexturaInfo = (imagePath: string) => {
    return texturas.find((t) => t.imagem === imagePath) || { nome: "Textura", codigo: "N/A" }
  }

  const handleDownload = () => {
    // Implementação futura: capturar a tela e baixar como imagem
    alert("Funcionalidade em desenvolvimento")
  }

  const handleShare = () => {
    // Implementação futura: compartilhar a comparação
    alert("Funcionalidade em desenvolvimento")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50">
      <Header />

      <div className="pt-24">
        {/* Breadcrumb */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 text-gray-700 hover:text-gray-800 transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span className="font-medium">Voltar</span>
              </Link>
              <div className="h-6 w-px bg-gray-300" />
              <h1 className="text-2xl font-bold text-gray-900">Comparador de Texturas</h1>
            </div>
          </div>
        </div>

        {/* Conteúdo Principal */}
        <div className="container mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Texturas Selecionadas</h2>
                <p className="text-gray-600">Selecione até 4 texturas para comparar</p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                >
                  Grade
                </Button>
                <Button
                  variant={viewMode === "side-by-side" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("side-by-side")}
                >
                  Lado a Lado
                </Button>
              </div>
            </div>

            {/* Área de Comparação */}
            <div className={`grid ${viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2" : "grid-cols-1"} gap-4 mb-6`}>
              {selectedTexturas.map((textura, index) => (
                <div key={index} className="relative border rounded-lg overflow-hidden">
                  <div className="absolute top-2 right-2 z-10 flex gap-2">
                    <Button
                      variant="secondary"
                      size="icon"
                      className="w-8 h-8 bg-white/90 hover:bg-white"
                      onClick={() => handleRemoveTextura(index)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="absolute top-2 left-2 z-10 bg-black/60 text-white text-xs px-2 py-1 rounded">
                    {getTexturaInfo(textura).nome} - {getTexturaInfo(textura).codigo}
                  </div>
                  <Image
                    src={textura || "/placeholder.svg"}
                    alt={`Textura ${index + 1}`}
                    width={500}
                    height={500}
                    className="w-full aspect-square object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                    <Select value={textura} onValueChange={(value) => handleReplaceTextura(index, value)}>
                      <SelectTrigger className="bg-white/90 border-0">
                        <SelectValue placeholder="Trocar textura" />
                      </SelectTrigger>
                      <SelectContent>
                        {texturas.map((t) => (
                          <SelectItem key={t.id} value={t.imagem} disabled={selectedTexturas.includes(t.imagem)}>
                            {t.nome} - {t.codigo}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}

              {selectedTexturas.length < 4 && (
                <div className="border border-dashed rounded-lg flex items-center justify-center p-8 min-h-[300px]">
                  <div className="text-center">
                    <Plus className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600 mb-4">Adicionar textura para comparação</p>
                    <Select onValueChange={handleAddTextura}>
                      <SelectTrigger className="w-full max-w-xs mx-auto">
                        <SelectValue placeholder="Selecionar textura" />
                      </SelectTrigger>
                      <SelectContent>
                        {texturas
                          .filter((t) => !selectedTexturas.includes(t.imagem))
                          .map((t) => (
                            <SelectItem key={t.id} value={t.imagem}>
                              {t.nome} - {t.codigo}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2">
              <Button onClick={handleDownload} className="flex-1">
                <Download className="w-4 h-4 mr-2" />
                Baixar Comparação
              </Button>
              <Button variant="outline" onClick={handleShare} className="flex-1">
                <Share2 className="w-4 h-4 mr-2" />
                Compartilhar
              </Button>
              <Link href="/visualizador-ambientes" className="flex-1">
                <Button variant="secondary" className="w-full">
                  <ArrowLeftRight className="w-4 h-4 mr-2" />
                  Visualizar em Ambiente
                </Button>
              </Link>
            </div>
          </div>

          {/* Catálogo de Texturas */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Catálogo de Texturas</h2>
            <Tabs defaultValue="todas">
              <TabsList className="mb-4">
                <TabsTrigger value="todas">Todas</TabsTrigger>
                <TabsTrigger value="marmores">Mármores</TabsTrigger>
                <TabsTrigger value="linho">Linho</TabsTrigger>
                <TabsTrigger value="geometricas">Geométricas</TabsTrigger>
                <TabsTrigger value="concreto">Concreto</TabsTrigger>
              </TabsList>

              <TabsContent
                value="todas"
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
              >
                {texturas.map((textura) => (
                  <div
                    key={textura.id}
                    className={`relative rounded-lg overflow-hidden border cursor-pointer ${
                      selectedTexturas.includes(textura.imagem) ? "opacity-50" : ""
                    }`}
                    onClick={() => !selectedTexturas.includes(textura.imagem) && handleAddTextura(textura.imagem)}
                  >
                    <Image
                      src={textura.imagem || "/placeholder.svg"}
                      alt={textura.nome}
                      width={150}
                      height={150}
                      className="w-full aspect-square object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-2">
                      <p className="text-white text-xs font-medium">{textura.nome}</p>
                      <p className="text-gray-300 text-xs">{textura.codigo}</p>
                    </div>
                    {selectedTexturas.includes(textura.imagem) && (
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <span className="bg-white text-gray-800 text-xs font-medium px-2 py-1 rounded">
                          Selecionada
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </TabsContent>

              <TabsContent
                value="marmores"
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
              >
                {texturas
                  .filter((t) => t.nome.toLowerCase().includes("mármore"))
                  .map((textura) => (
                    <div
                      key={textura.id}
                      className={`relative rounded-lg overflow-hidden border cursor-pointer ${
                        selectedTexturas.includes(textura.imagem) ? "opacity-50" : ""
                      }`}
                      onClick={() => !selectedTexturas.includes(textura.imagem) && handleAddTextura(textura.imagem)}
                    >
                      <Image
                        src={textura.imagem || "/placeholder.svg"}
                        alt={textura.nome}
                        width={150}
                        height={150}
                        className="w-full aspect-square object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-2">
                        <p className="text-white text-xs font-medium">{textura.nome}</p>
                        <p className="text-gray-300 text-xs">{textura.codigo}</p>
                      </div>
                    </div>
                  ))}
              </TabsContent>

              <TabsContent
                value="linho"
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
              >
                {texturas
                  .filter((t) => t.nome.toLowerCase().includes("linho"))
                  .map((textura) => (
                    <div
                      key={textura.id}
                      className={`relative rounded-lg overflow-hidden border cursor-pointer ${
                        selectedTexturas.includes(textura.imagem) ? "opacity-50" : ""
                      }`}
                      onClick={() => !selectedTexturas.includes(textura.imagem) && handleAddTextura(textura.imagem)}
                    >
                      <Image
                        src={textura.imagem || "/placeholder.svg"}
                        alt={textura.nome}
                        width={150}
                        height={150}
                        className="w-full aspect-square object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-2">
                        <p className="text-white text-xs font-medium">{textura.nome}</p>
                        <p className="text-gray-300 text-xs">{textura.codigo}</p>
                      </div>
                    </div>
                  ))}
              </TabsContent>

              <TabsContent
                value="geometricas"
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
              >
                {texturas
                  .filter(
                    (t) =>
                      t.nome.toLowerCase().includes("geométric") ||
                      t.nome.toLowerCase().includes("losango") ||
                      t.nome.toLowerCase().includes("chevron"),
                  )
                  .map((textura) => (
                    <div
                      key={textura.id}
                      className={`relative rounded-lg overflow-hidden border cursor-pointer ${
                        selectedTexturas.includes(textura.imagem) ? "opacity-50" : ""
                      }`}
                      onClick={() => !selectedTexturas.includes(textura.imagem) && handleAddTextura(textura.imagem)}
                    >
                      <Image
                        src={textura.imagem || "/placeholder.svg"}
                        alt={textura.nome}
                        width={150}
                        height={150}
                        className="w-full aspect-square object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-2">
                        <p className="text-white text-xs font-medium">{textura.nome}</p>
                        <p className="text-gray-300 text-xs">{textura.codigo}</p>
                      </div>
                    </div>
                  ))}
              </TabsContent>

              <TabsContent
                value="concreto"
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
              >
                {texturas
                  .filter(
                    (t) =>
                      t.nome.toLowerCase().includes("concreto") ||
                      t.nome.toLowerCase().includes("terrazzo") ||
                      t.nome.toLowerCase().includes("industrial"),
                  )
                  .map((textura) => (
                    <div
                      key={textura.id}
                      className={`relative rounded-lg overflow-hidden border cursor-pointer ${
                        selectedTexturas.includes(textura.imagem) ? "opacity-50" : ""
                      }`}
                      onClick={() => !selectedTexturas.includes(textura.imagem) && handleAddTextura(textura.imagem)}
                    >
                      <Image
                        src={textura.imagem || "/placeholder.svg"}
                        alt={textura.nome}
                        width={150}
                        height={150}
                        className="w-full aspect-square object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-2">
                        <p className="text-white text-xs font-medium">{textura.nome}</p>
                        <p className="text-gray-300 text-xs">{textura.codigo}</p>
                      </div>
                    </div>
                  ))}
              </TabsContent>
            </Tabs>

            <div className="mt-6 text-center">
              <Link href="/catalogos/texturas">
                <Button variant="outline">Ver Catálogo Completo</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <WhatsAppFloat />
    </div>
  )
}
