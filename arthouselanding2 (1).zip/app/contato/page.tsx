import Link from "next/link"
import { ArrowLeft, Mail, Phone, MapPin, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"

export default function ContatoPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <WhatsAppFloat />

      {/* Back Button */}
      <div className="container mx-auto px-4 py-6 pt-24">
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Voltar ao início
          </Link>
        </Button>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 pb-16">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-8 text-center">Entre em Contato</h1>

          <p className="text-xl text-gray-600 text-center mb-12 max-w-3xl mx-auto">
            Estamos prontos para transformar seu ambiente! Entre em contato conosco e descubra como nossos papéis de
            parede podem revolucionar sua decoração.
          </p>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Informações de Contato</h2>

              <div className="space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="bg-green-100 p-3 rounded-full">
                        <Phone className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">Telefone / WhatsApp</h3>
                        <p className="text-gray-600">(61) 9 8679-2057</p>
                        <Button asChild variant="link" className="p-0 h-auto text-green-600">
                          <a
                            href="https://wa.me/5561986792057?text=Olá! Gostaria de saber mais sobre os papéis de parede da Art House."
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            Conversar no WhatsApp
                          </a>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="bg-blue-100 p-3 rounded-full">
                        <Mail className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">E-mail</h3>
                        <p className="text-gray-600">contato@arthousepapeldeparede.com.br</p>
                        <Button asChild variant="link" className="p-0 h-auto text-blue-600">
                          <a href="mailto:contato@arthousepapeldeparede.com.br">Enviar e-mail</a>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="bg-red-100 p-3 rounded-full">
                        <MapPin className="h-6 w-6 text-red-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">Localização</h3>
                        <p className="text-gray-600">CLS 311, Bloco C, Loja 29, Asa Sul, Brasília - DF</p>
                        <p className="text-sm text-gray-500 mt-1">
                          Entre em contato para agendar uma visita à nossa loja
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="bg-purple-100 p-3 rounded-full">
                        <Clock className="h-6 w-6 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">Horário de Atendimento</h3>
                        <p className="text-gray-600">Segunda a Sexta: 8h às 18h</p>
                        <p className="text-gray-600">Sábado: 8h às 12h</p>
                        <p className="text-sm text-gray-500 mt-1">WhatsApp disponível 24h</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-green-50 p-6 rounded-lg">
                <h3 className="font-semibold text-green-900 mb-2">Atendimento Personalizado</h3>
                <p className="text-green-800 text-sm">
                  Oferecemos consultoria gratuita para escolha do papel de parede ideal para seu projeto. Entre em
                  contato e agende uma conversa!
                </p>
              </div>
            </div>

            {/* Map */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Nossa Localização</h2>

              <div className="bg-gray-100 rounded-lg overflow-hidden shadow-lg">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3839.2!2d-47.8828!3d-15.7942!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTXCsDQ3JzM5LjEiUyA0N8KwNTInNTguMSJX!5e0!3m2!1spt-BR!2sbr!4v1"
                  width="100%"
                  height="400"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Localização da Art House"
                ></iframe>
              </div>

              <p className="text-sm text-gray-500 mt-4 text-center">
                * Entre em contato conosco para obter o endereço exato e agendar sua visita
              </p>
            </div>
          </div>

          {/* CTA Section */}
          <div className="text-center mt-16 bg-gray-50 p-8 rounded-lg">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Pronto para Transformar seu Ambiente?</h2>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Nossa equipe está pronta para ajudar você a escolher o papel de parede perfeito. Entre em contato agora
              mesmo!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-green-600 hover:bg-green-700">
                <a
                  href="https://wa.me/5561986792057?text=Olá! Gostaria de agendar uma consulta sobre papéis de parede."
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  WhatsApp
                </a>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="mailto:contato@arthousepapeldeparede.com.br">Enviar E-mail</a>
              </Button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
