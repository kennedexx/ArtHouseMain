"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Camera, Download, Share2, Undo2, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"

export default function VisualizadorAmbientes() {
  const [selectedAmbiente, setSelectedAmbiente] = useState("sala-estar")
  const [selectedTextura, setSelectedTextura] = useState("/catalog-images/texturas-129.jpg")
  const [brightness, setBrightness] = useState(100)
  const [contrast, setContrast] = useState(100)
  const [scale, setScale] = useState(100)
  const [rotation, setRotation] = useState(0)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isRendering, setIsRendering] = useState(true)

  const ambientes = [
    { id: "sala-estar", nome: "Sala de Estar", imagem: "/ambientes/sala-estar.png" },
    { id: "quarto", nome: "Quarto", imagem: "/ambientes/quarto.png" },
    { id: "cozinha", nome: "Cozinha", imagem: "/ambientes/cozinha.png" },
    { id: "banheiro", nome: "Banheiro", imagem: "/ambientes/banheiro.png" },
    { id: "escritorio", nome: "Home Office", imagem: "/ambientes/escritorio.png" },
    { id: "sala-jantar", nome: "Sala de Jantar", imagem: "/ambientes/sala-jantar.png" },
  ]

  const texturas = [
    { id: "textura-1", nome: "Mármore Bege", imagem: "/catalog-images/texturas-129.jpg" },
    { id: "textura-2", nome: "Linho Cinza", imagem: "/catalog-images/texturas-130.jpg" },
    { id: "textura-3", nome: "Azul Profundo", imagem: "/catalog-images/texturas-131.jpg" },
    { id: "textura-4", nome: "Floral Bege", imagem: "/catalog-images/texturas-132.jpg" },
    { id: "textura-5", nome: "Damasco Cinza", imagem: "/catalog-images/texturas-133.jpg" },
    { id: "textura-6", nome: "Concreto Desgastado", imagem: "/catalog-images/texturas-134.jpg" },
    { id: "textura-7", nome: "Metálico Listrado", imagem: "/catalog-images/texturas-135.jpg" },
    { id: "textura-8", nome: "Blocos de Concreto", imagem: "/catalog-images/texturas-136.jpg" },
    { id: "textura-9", nome: "Terrazzo", imagem: "/catalog-images/texturas-137.jpg" },
    { id: "textura-10", nome: "Linho Premium", imagem: "/catalog-images/texturas-138.jpg" },
  ]

  // Áreas de aplicação para cada ambiente (coordenadas da parede)
  const areasAplicacao = {
    "sala-estar": { x: 0, y: 0, width: 800, height: 600 },
    quarto: { x: 50, y: 50, width: 700, height: 500 },
    cozinha: { x: 100, y: 100, width: 600, height: 400 },
    banheiro: { x: 150, y: 150, width: 500, height: 300 },
    escritorio: { x: 200, y: 200, width: 400, height: 200 },
    "sala-jantar": { x: 250, y: 250, width: 300, height: 100 },
  }

  const renderCanvas = async () => {
    const canvas = canvasRef.current
    if (!canvas) return

    setIsRendering(true)
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Limpar o canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    try {
      // Carregar a imagem do ambiente
      const ambienteImg = new Image()
      ambienteImg.crossOrigin = "anonymous"
      ambienteImg.src = ambientes.find((a) => a.id === selectedAmbiente)?.imagem || ambientes[0].imagem

      await new Promise((resolve, reject) => {
        ambienteImg.onload = resolve
        ambienteImg.onerror = reject
      })

      // Desenhar o ambiente
      ctx.drawImage(ambienteImg, 0, 0, canvas.width, canvas.height)

      // Carregar a textura
      const texturaImg = new Image()
      texturaImg.crossOrigin = "anonymous"
      texturaImg.src = selectedTextura

      await new Promise((resolve, reject) => {
        texturaImg.onload = resolve
        texturaImg.onerror = reject
      })

      // Obter a área de aplicação para o ambiente selecionado
      const area = areasAplicacao[selectedAmbiente as keyof typeof areasAplicacao]

      // Criar um padrão com a textura
      const pattern = ctx.createPattern(texturaImg, "repeat")
      if (!pattern) return

      // Salvar o estado atual do contexto
      ctx.save()

      // Aplicar transformações
      ctx.translate(area.x + area.width / 2, area.y + area.height / 2)
      ctx.rotate((rotation * Math.PI) / 180)
      ctx.scale(scale / 100, scale / 100)
      ctx.translate(-(area.x + area.width / 2), -(area.y + area.height / 2))

      // Aplicar o padrão
      ctx.fillStyle = pattern
      ctx.fillRect(area.x, area.y, area.width, area.height)

      // Restaurar o contexto
      ctx.restore()

      // Aplicar brilho e contraste
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
      const data = imageData.data

      const brightnessValue = brightness / 100
      const contrastValue = contrast / 100

      for (let i = 0; i < data.length; i += 4) {
        // Brilho
        data[i] = data[i] * brightnessValue
        data[i + 1] = data[i + 1] * brightnessValue
        data[i + 2] = data[i + 2] * brightnessValue

        // Contraste
        data[i] = ((data[i] / 255 - 0.5) * contrastValue + 0.5) * 255
        data[i + 1] = ((data[i + 1] / 255 - 0.5) * contrastValue + 0.5) * 255
        data[i + 2] = ((data[i + 2] / 255 - 0.5) * contrastValue + 0.5) * 255
      }

      ctx.putImageData(imageData, 0, 0)
    } catch (error) {
      console.error("Erro ao renderizar o canvas:", error)
    } finally {
      setIsRendering(false)
    }
  }

  // Renderizar o canvas quando os parâmetros mudarem
  useEffect(() => {
    renderCanvas()
  }, [selectedAmbiente, selectedTextura, brightness, contrast, scale, rotation])

  const handleDownload = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement("a")
    link.download = `visualizacao-${selectedAmbiente}-${new Date().getTime()}.png`
    link.href = canvas.toDataURL("image/png")
    link.click()
  }

  const handleShare = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    canvas.toBlob(async (blob) => {
      if (!blob) return

      try {
        if (navigator.share) {
          const file = new File([blob], "visualizacao.png", { type: "image/png" })
          await navigator.share({
            title: "Visualização de Ambiente",
            text: "Confira como ficou minha simulação de ambiente com papel de parede da Art House!",
            files: [file],
          })
        } else {
          // Fallback para navegadores que não suportam Web Share API
          const url = URL.createObjectURL(blob)
          const link = document.createElement("a")
          link.download = `visualizacao-${selectedAmbiente}-${new Date().getTime()}.png`
          link.href = url
          link.click()
          URL.revokeObjectURL(url)
        }
      } catch (error) {
        console.error("Erro ao compartilhar:", error)
        alert("Não foi possível compartilhar. Tente fazer o download da imagem.")
      }
    })
  }

  const resetAjustes = () => {
    setBrightness(100)
    setContrast(100)
    setScale(100)
    setRotation(0)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50">
      <Header />

      <div className="pt-24">
        {/* Breadcrumb */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 text-gray-700 hover:text-gray-800 transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span className="font-medium">Voltar</span>
              </Link>
              <div className="h-6 w-px bg-gray-300" />
              <h1 className="text-2xl font-bold text-gray-900">Visualizador de Ambientes</h1>
            </div>
          </div>
        </div>

        {/* Conteúdo Principal */}
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Coluna da Esquerda - Controles */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Escolha o Ambiente</h2>
                <Select value={selectedAmbiente} onValueChange={setSelectedAmbiente}>
                  <SelectTrigger className="w-full mb-4">
                    <SelectValue placeholder="Selecione um ambiente" />
                  </SelectTrigger>
                  <SelectContent>
                    {ambientes.map((ambiente) => (
                      <SelectItem key={ambiente.id} value={ambiente.id}>
                        {ambiente.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="grid grid-cols-3 gap-2 mb-6">
                  {ambientes.map((ambiente) => (
                    <div
                      key={ambiente.id}
                      className={`relative rounded-md overflow-hidden cursor-pointer border-2 ${
                        selectedAmbiente === ambiente.id ? "border-green-500" : "border-transparent"
                      }`}
                      onClick={() => setSelectedAmbiente(ambiente.id)}
                    >
                      <Image
                        src={ambiente.imagem || "/placeholder.svg"}
                        alt={ambiente.nome}
                        width={100}
                        height={75}
                        className="w-full h-auto object-cover aspect-video"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                        <span className="text-white text-xs font-medium drop-shadow-md">{ambiente.nome}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <h2 className="text-xl font-bold text-gray-900 mb-4">Escolha a Textura</h2>
                <div className="grid grid-cols-4 gap-2 mb-6">
                  {texturas.map((textura) => (
                    <div
                      key={textura.id}
                      className={`relative rounded-md overflow-hidden cursor-pointer border-2 ${
                        selectedTextura === textura.imagem ? "border-green-500" : "border-transparent"
                      }`}
                      onClick={() => setSelectedTextura(textura.imagem)}
                    >
                      <Image
                        src={textura.imagem || "/placeholder.svg"}
                        alt={textura.nome}
                        width={60}
                        height={60}
                        className="w-full h-auto object-cover aspect-square"
                      />
                    </div>
                  ))}
                </div>

                <Link href="/catalogos/texturas" className="block w-full">
                  <Button variant="outline" className="w-full mb-6">
                    Ver Mais Texturas no Catálogo
                  </Button>
                </Link>

                <h2 className="text-xl font-bold text-gray-900 mb-4">Ajustes</h2>
                <Tabs defaultValue="basicos" className="mb-6">
                  <TabsList className="w-full">
                    <TabsTrigger value="basicos" className="flex-1">
                      Básicos
                    </TabsTrigger>
                    <TabsTrigger value="avancados" className="flex-1">
                      Avançados
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="basicos" className="space-y-4 pt-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <label className="text-sm font-medium text-gray-700">Brilho</label>
                        <span className="text-sm text-gray-500">{brightness}%</span>
                      </div>
                      <Slider
                        value={[brightness]}
                        min={50}
                        max={150}
                        step={1}
                        onValueChange={(value) => setBrightness(value[0])}
                      />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <label className="text-sm font-medium text-gray-700">Contraste</label>
                        <span className="text-sm text-gray-500">{contrast}%</span>
                      </div>
                      <Slider
                        value={[contrast]}
                        min={50}
                        max={150}
                        step={1}
                        onValueChange={(value) => setContrast(value[0])}
                      />
                    </div>
                  </TabsContent>
                  <TabsContent value="avancados" className="space-y-4 pt-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <label className="text-sm font-medium text-gray-700">Escala</label>
                        <span className="text-sm text-gray-500">{scale}%</span>
                      </div>
                      <Slider
                        value={[scale]}
                        min={50}
                        max={200}
                        step={1}
                        onValueChange={(value) => setScale(value[0])}
                      />
                    </div>
                    <div>
                      <div className="flex justify-between mb-2">
                        <label className="text-sm font-medium text-gray-700">Rotação</label>
                        <span className="text-sm text-gray-500">{rotation}°</span>
                      </div>
                      <Slider
                        value={[rotation]}
                        min={0}
                        max={360}
                        step={1}
                        onValueChange={(value) => setRotation(value[0])}
                      />
                    </div>
                  </TabsContent>
                </Tabs>

                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={resetAjustes}>
                    <Undo2 className="w-4 h-4 mr-2" />
                    Resetar
                  </Button>
                  <Button variant="outline" className="flex-1" onClick={renderCanvas}>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Atualizar
                  </Button>
                </div>
              </div>
            </div>

            {/* Coluna da Direita - Visualização */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-sm border p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Visualização</h2>
                <div className="relative rounded-lg overflow-hidden border mb-4">
                  <canvas ref={canvasRef} width={800} height={600} className="w-full h-auto" />
                  {isRendering && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <div className="text-white text-center">
                        <RefreshCw className="w-8 h-8 mx-auto animate-spin mb-2" />
                        <p>Renderizando...</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button onClick={handleDownload} className="flex-1">
                    <Download className="w-4 h-4 mr-2" />
                    Baixar Imagem
                  </Button>
                  <Button variant="outline" onClick={handleShare} className="flex-1">
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartilhar
                  </Button>
                  <Button variant="secondary" className="flex-1">
                    <Camera className="w-4 h-4 mr-2" />
                    Enviar Foto do Ambiente
                  </Button>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border p-6 mt-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Dicas de Uso</h2>
                <ul className="list-disc list-inside space-y-2 text-gray-700">
                  <li>Escolha o ambiente que mais se assemelha ao seu espaço</li>
                  <li>Selecione a textura desejada do nosso catálogo</li>
                  <li>Ajuste o brilho e contraste para visualizar melhor os detalhes</li>
                  <li>Use os controles avançados para ajustar a escala e rotação da textura</li>
                  <li>Baixe ou compartilhe a imagem para consultar depois ou pedir opinião</li>
                  <li>Para uma simulação mais precisa, envie uma foto do seu próprio ambiente</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <WhatsAppFloat />
    </div>
  )
}
