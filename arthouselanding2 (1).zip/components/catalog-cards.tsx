import type React from "react"

interface CatalogCardProps {
  title: string
  description: string
  imageUrl: string
}

const CatalogCard: React.FC<CatalogCardProps> = ({ title, description, imageUrl }) => {
  return (
    <div className="relative rounded-lg overflow-hidden shadow-md">
      <img src={imageUrl || "/placeholder.svg"} alt={title} className="w-full h-48 object-cover" />
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
    </div>
  )
}

interface CatalogCardsProps {
  cards: {
    title: string
    description: string
    imageUrl: string
  }[]
}

const CatalogCards: React.FC<CatalogCardsProps> = ({ cards }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {cards.map((card, index) => (
        <CatalogCard key={index} title={card.title} description={card.description} imageUrl={card.imageUrl} />
      ))}
    </div>
  )
}

export default CatalogCards
