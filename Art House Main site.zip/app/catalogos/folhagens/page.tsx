"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Share2, Search, Filter, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"
import ImageModal from "@/components/ImageModal"
import { useState } from "react"

export default function CatalogoFolhagens() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedColor, setSelectedColor] = useState("Todas as Cores")
  const [selectedProduto, setSelectedProduto] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const produtos = [
    // Folhagens Douradas Luxuosas
    {
      id: 1,
      nome: "Folhagens Douradas Elegantes",
      modelos: [
        { codigo: "VR980706T", cor: "Dourado", descricao: "Folhagem Dourada sobre Fundo Escuro Premium" },
        { codigo: "VR980803R", cor: "Preto", descricao: "Textura Lisa Escura Complementar" },
      ],
      cores: ["Dourado", "Preto"],
      textura: "Folhagem Dourada",
      categoria: "Luxo Premium",
      imagem: "/catalog-images/folhagens-4.jpg",
      descricao: "Elegância suprema com folhagens douradas sobre fundo escuro sofisticado.",
    },

    // Tropicais Modernas Preto e Branco
    {
      id: 2,
      nome: "Tropicais Modernas Monocromáticas",
      modelos: [
        { codigo: "EL500105R", cor: "Preto", descricao: "Folhas Tropicais Preto e Branco Modernas" },
        { codigo: "EL500101R", cor: "Branco", descricao: "Textura Lisa Branca Complementar" },
      ],
      cores: ["Preto", "Branco"],
      textura: "Tropical Moderna",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/folhagens-5.jpg",
      descricao: "Ambiente de sala de jantar com folhas tropicais em estilo monocromático moderno.",
    },

    // Coleção Tropical Vibrante
    {
      id: 3,
      nome: "Coleção Tropical Vibrante Premium",
      modelos: [
        { codigo: "GR402301", cor: "Azul", descricao: "Folhagem Tropical sobre Fundo Azul Petróleo" },
        { codigo: "GR402361", cor: "Bege", descricao: "Folhagem Tropical sobre Fundo Bege Sofisticado" },
        { codigo: "GR402304", cor: "Dourado", descricao: "Folhagem Tropical sobre Fundo Dourado" },
        { codigo: "GR402302", cor: "Verde", descricao: "Folhagem Tropical sobre Fundo Verde Escuro" },
      ],
      cores: ["Azul", "Bege", "Dourado", "Verde"],
      textura: "Tropical Vibrante",
      categoria: "Tropical Premium",
      imagem: "/catalog-images/folhagens-8.jpg",
      descricao: "Coleção completa de folhagens tropicais em 4 cores vibrantes e sofisticadas.",
    },

    // Folhagem Dourada Azul Premium
    {
      id: 4,
      nome: "Folhagem Dourada Azul Sofisticada",
      modelos: [{ codigo: "VR980704T", cor: "Azul", descricao: "Folhagem Dourada sobre Fundo Azul Acinzentado" }],
      cores: ["Azul", "Dourado"],
      textura: "Folhagem Dourada",
      categoria: "Luxo Contemporâneo",
      imagem: "/catalog-images/folhagens-7.jpg",
      descricao: "Ambiente moderno com poltrona destacando folhagem dourada sobre fundo azul sofisticado.",
    },

    // Folhagens Sutis Neutras
    {
      id: 5,
      nome: "Folhagens Sutis Neutras",
      modelos: [
        { codigo: "VR980703T", cor: "Cinza", descricao: "Folhagem Sutil sobre Fundo Cinza Claro" },
        { codigo: "VR980806R", cor: "Cinza", descricao: "Textura Lisa Cinza Complementar" },
      ],
      cores: ["Cinza"],
      textura: "Folhagem Sutil",
      categoria: "Minimalista",
      imagem: "/catalog-images/folhagens-3.jpg",
      descricao: "Padrões sutis e elegantes para ambientes minimalistas sofisticados.",
    },

    // Tropicais Neutras Clean
    {
      id: 6,
      nome: "Tropicais Neutras Clean",
      modelos: [
        { codigo: "AD200301R", cor: "Bege", descricao: "Folhagem Tropical Bege com Detalhes Dourados" },
        { codigo: "AD200302R", cor: "Branco", descricao: "Folhagem Tropical Branco com Detalhes Prateados" },
      ],
      cores: ["Bege", "Branco"],
      textura: "Tropical Clean",
      categoria: "Contemporâneo Clean",
      imagem: "/catalog-images/folhagens-9.jpg",
      descricao: "Ambiente clean com sofá branco, destacando folhagens tropicais em tons neutros sofisticados.",
    },

    // Coleção Neutra Premium
    {
      id: 7,
      nome: "Coleção Neutra Premium",
      modelos: [
        { codigo: "VR980207S", cor: "Bege", descricao: "Textura Neutra Premium" },
        { codigo: "VR980702T", cor: "Bege", descricao: "Folhagem Sutil Bege Elegante" },
        { codigo: "VR980805R", cor: "Bege", descricao: "Textura Lisa Bege Sofisticada" },
      ],
      cores: ["Bege"],
      textura: "Neutra Premium",
      categoria: "Elegância Neutra",
      imagem: "/catalog-images/folhagens-1.jpg",
      descricao: "Trio de padrões neutros em bege para máxima versatilidade decorativa.",
    },

    // Folhagens Verdes Naturais
    {
      id: 8,
      nome: "Folhagens Verdes Naturais",
      modelos: [
        { codigo: "VR980707T", cor: "Verde", descricao: "Folhagem Sutil Verde Natural" },
        { codigo: "VR980804R", cor: "Verde", descricao: "Textura Lisa Verde Complementar" },
      ],
      cores: ["Verde"],
      textura: "Folhagem Natural",
      categoria: "Natural Orgânico",
      imagem: "/catalog-images/folhagens-2.jpg",
      descricao: "Tons verdes naturais que trazem tranquilidade e conexão com a natureza.",
    },

    // Coleção Tropical Exuberante
    {
      id: 9,
      nome: "Coleção Tropical Exuberante",
      modelos: [
        { codigo: "GR402101", cor: "Verde", descricao: "Folhas Tropicais Verdes Exuberantes" },
        { codigo: "GR401501", cor: "Verde", descricao: "Palmeiras Tropicais Verde Intenso" },
        { codigo: "GR403001", cor: "Verde", descricao: "Fauna e Flora Tropical com Pássaros" },
        { codigo: "GR403002", cor: "Rosa", descricao: "Flores Tropicais Rosa e Verde" },
      ],
      cores: ["Verde", "Rosa"],
      textura: "Tropical Exuberante",
      categoria: "Tropical Luxuoso",
      imagem: "/catalog-images/folhagens-10.jpg",
      descricao: "Coleção completa com folhas tropicais, pássaros exóticos e flores vibrantes.",
    },

    // Folhagens Sutis Cinza e Cobre
    {
      id: 10,
      nome: "Folhagens Sutis Cinza e Cobre",
      modelos: [
        { codigo: "VR980701T", cor: "Cinza", descricao: "Folhagens Delicadas Cinza com Detalhes Cobre" },
        { codigo: "VR980801R", cor: "Cinza", descricao: "Textura Lisa Cinza Complementar" },
      ],
      cores: ["Cinza", "Cobre"],
      textura: "Folhagem Sutil",
      categoria: "Elegância Discreta",
      imagem: "/catalog-images/folhagens-11.jpg",
      descricao: "Padrões delicados com folhagens em tons cinza e detalhes em cobre para ambientes sofisticados.",
    },

    // Coleção Artística Premium
    {
      id: 11,
      nome: "Coleção Artística Premium",
      modelos: [
        { codigo: "PT400901R", cor: "Bege", descricao: "Folhagens Artísticas Bege Neutro" },
        { codigo: "PT400902R", cor: "Cinza", descricao: "Folhagens Artísticas Cinza Claro" },
        { codigo: "PT400903R", cor: "Bege", descricao: "Folhagens Artísticas Bege Rosado" },
        { codigo: "PT400904R", cor: "Azul", descricao: "Flores Coloridas sobre Fundo Azul Escuro" },
      ],
      cores: ["Bege", "Cinza", "Azul", "Rosa"],
      textura: "Artística Premium",
      categoria: "Arte Contemporânea",
      imagem: "/catalog-images/folhagens-12.jpg",
      descricao: "Coleção artística com 4 padrões únicos, incluindo flores vibrantes sobre fundo azul.",
    },

    // Florais Rosa Vibrante
    {
      id: 12,
      nome: "Florais Rosa Vibrante",
      modelos: [
        { codigo: "GR402401", cor: "Rosa", descricao: "Flores Grandes Rosa sobre Fundo Claro" },
        { codigo: "GR402402", cor: "Verde", descricao: "Folhagens Verdes Complementares" },
      ],
      cores: ["Rosa", "Verde"],
      textura: "Floral Vibrante",
      categoria: "Romântico Moderno",
      imagem: "/catalog-images/folhagens-13.jpg",
      descricao: "Ambiente alegre com flores grandes em rosa vibrante, perfeito para espaços femininos.",
    },

    // Folhagens Douradas Elegantes Premium
    {
      id: 13,
      nome: "Folhagens Douradas Elegantes Premium",
      modelos: [{ codigo: "VR980705T", cor: "Dourado", descricao: "Folhagens Sutis Douradas sobre Bege" }],
      cores: ["Dourado", "Bege"],
      textura: "Folhagem Dourada Premium",
      categoria: "Luxo Clássico",
      imagem: "/catalog-images/folhagens-14.jpg",
      descricao: "Ambiente de jantar sofisticado com folhagens douradas delicadas sobre fundo bege.",
    },

    // Tropicais Prateadas Modernas
    {
      id: 14,
      nome: "Tropicais Prateadas Modernas",
      modelos: [
        { codigo: "EL500104R", cor: "Prateado", descricao: "Folhagens Tropicais Prateadas" },
        { codigo: "EL500102R", cor: "Cinza", descricao: "Folhagens Tropicais Cinza Claro" },
        { codigo: "EL500103R", cor: "Cinza", descricao: "Folhagens Tropicais Cinza Escuro" },
      ],
      cores: ["Prateado", "Cinza"],
      textura: "Tropical Prateada",
      categoria: "Moderno Sofisticado",
      imagem: "/catalog-images/folhagens-15.jpg",
      descricao: "Trio de folhagens tropicais em tons prateados e cinza para ambientes contemporâneos.",
    },

    // Palmeiras Tropicais Verdes
    {
      id: 15,
      nome: "Palmeiras Tropicais Verdes",
      modelos: [{ codigo: "MT300003R", cor: "Verde", descricao: "Folhas de Palmeira Grandes Verde Intenso" }],
      cores: ["Verde"],
      textura: "Palmeira Tropical",
      categoria: "Tropical Exuberante",
      imagem: "/catalog-images/folhagens-16.jpg",
      descricao: "Ambiente clássico com papel de palmeiras tropicais em verde exuberante.",
    },

    // Botanicais Minimalistas
    {
      id: 16,
      nome: "Botanicais Minimalistas",
      modelos: [
        { codigo: "NN591501R", cor: "Bege", descricao: "Folhagens Minimalistas Bege Claro" },
        { codigo: "NN591502R", cor: "Cinza", descricao: "Folhagens Minimalistas Cinza Suave" },
      ],
      cores: ["Bege", "Cinza"],
      textura: "Botânica Minimalista",
      categoria: "Minimalista Moderno",
      imagem: "/catalog-images/folhagens-17.jpg",
      descricao: "Ambiente minimalista moderno com folhagens sutis em tons neutros e clean.",
    },
  ]

  const cores = ["Todas as Cores", "Bege", "Branco", "Verde", "Dourado", "Prateado", "Preto", "Cinza", "Azul", "Rosa"]

  const filteredProducts = produtos.filter((produto) => {
    const matchesSearch = produto.cores.some((cor) => cor.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesColor = selectedColor === "Todas as Cores" || produto.cores.includes(selectedColor)
    return matchesSearch && matchesColor
  })

  const openModal = (produto: any) => {
    setSelectedProduto(produto)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setSelectedProduto(null)
    setIsModalOpen(false)
  }

  const goToPrevious = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const previousIndex = currentIndex === 0 ? filteredProducts.length - 1 : currentIndex - 1
      setSelectedProduto(filteredProducts[previousIndex])
    }
  }

  const goToNext = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const nextIndex = currentIndex === filteredProducts.length - 1 ? 0 : currentIndex + 1
      setSelectedProduto(filteredProducts[nextIndex])
    }
  }

  const handlePedirOrcamento = (produto: any) => {
    const modelosTexto = produto.modelos
      .map((modelo: any) => `• ${modelo.codigo} - ${modelo.descricao} (${modelo.cor})`)
      .join("\n")

    const mensagem = `Olá! Gostaria de solicitar um orçamento para os papéis de parede:

*${produto.nome}*

Modelos inclusos:
${modelosTexto}

Aguardo retorno. Obrigado!`

    const whatsappUrl = `https://wa.me/5561986792057?text=${encodeURIComponent(mensagem)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      <Header />

      <div className="pt-24">
        {/* Breadcrumb */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 text-green-700 hover:text-green-800 transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span className="font-medium">Voltar</span>
              </Link>
              <div className="h-6 w-px bg-gray-300" />
              <h1 className="text-2xl font-bold text-gray-900">Catálogo Folhagens</h1>
            </div>
          </div>
        </div>

        {/* Hero Section */}
        <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Coleção Folhagens</h2>
            <p className="text-xl md:text-2xl mb-6 text-green-100">Natureza e elegância em harmonia</p>
            <p className="text-lg text-green-200 max-w-2xl mx-auto">
              Descubra nossa linha de papéis com estampas de folhagens que trazem a natureza para dentro de casa.
            </p>
          </div>
        </div>

        {/* Filtros e Busca */}
        <div className="container mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="flex-1 max-w-md">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar por cor..."
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">Filtrar por cor:</span>
                <div className="flex flex-wrap gap-2">
                  {cores.slice(0, 4).map((cor) => (
                    <Badge
                      key={cor}
                      variant={cor === selectedColor ? "default" : "outline"}
                      className="cursor-pointer hover:bg-green-100"
                      onClick={() => setSelectedColor(cor)}
                    >
                      {cor}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Grid de Produtos */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((produto) => (
              <div
                key={produto.id}
                className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-all duration-300 overflow-hidden group"
              >
                <div className="relative">
                  <Image
                    src={produto.imagem || "/placeholder.svg"}
                    alt={produto.nome}
                    width={450}
                    height={300}
                    className="w-full aspect-[3/2] object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                    onClick={() => openModal(produto)}
                  />
                  <div className="absolute top-3 right-3 flex gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="w-8 h-8 p-0 bg-white/90 hover:bg-white"
                      onClick={() => openModal(produto)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white">
                      <Heart className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white">
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="absolute bottom-3 left-3 flex gap-1">
                    {produto.cores.map((cor, index) => (
                      <div
                        key={index}
                        className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
                        style={{
                          backgroundColor:
                            cor === "Bege"
                              ? "#D2B48C"
                              : cor === "Branco"
                                ? "#FFFFFF"
                                : cor === "Verde"
                                  ? "#10B981"
                                  : cor === "Dourado"
                                    ? "#FFD700"
                                    : cor === "Prateado"
                                      ? "#C0C0C0"
                                      : cor === "Preto"
                                        ? "#000000"
                                        : cor === "Cinza"
                                          ? "#808080"
                                          : cor === "Azul"
                                            ? "#0000FF"
                                            : cor === "Rosa"
                                              ? "#FF69B4"
                                              : "#9CA3AF",
                        }}
                      />
                    ))}
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="font-semibold text-lg text-gray-900 mb-2">{produto.nome}</h3>
                  <p className="text-sm text-gray-600 mb-2">{produto.modelos.length} modelos inclusos</p>
                  <p className="text-sm text-gray-600 mb-3">Cores: {produto.cores.join(", ")}</p>

                  <div className="flex items-center justify-center">
                    <Button
                      className="w-full bg-green-600 hover:bg-green-700 text-white"
                      onClick={() => handlePedirOrcamento(produto)}
                    >
                      💬 Pedir Orçamento
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-500">Tente buscar por uma cor diferente</p>
            </div>
          )}

          {/* Informações Adicionais */}
          <div className="mt-12 bg-white rounded-lg shadow-sm border p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Por que escolher nossa Coleção Folhagens?
            </h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🌿</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">Conexão com a Natureza</h4>
                <p className="text-gray-600">
                  Estampas que trazem a serenidade e beleza da natureza para os ambientes.
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🏡</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">Bem-estar</h4>
                <p className="text-gray-600">Padrões que promovem tranquilidade e harmonia nos espaços.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">✨</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">Elegância Natural</h4>
                <p className="text-gray-600">Sofisticação que combina com qualquer estilo decorativo.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <WhatsAppFloat />

      {/* Image Modal */}
      <ImageModal
        isOpen={isModalOpen}
        onClose={closeModal}
        imageSrc={selectedProduto?.imagem || "/placeholder.svg"}
        imageAlt={selectedProduto?.nome || ""}
        imageTitle={selectedProduto?.nome || ""}
        description={selectedProduto?.descricao}
        modelosHtml={
          selectedProduto?.modelos
            ?.map(
              (modelo: any) =>
                `<p class="text-sm mb-1"><strong>${modelo.codigo}:</strong> ${modelo.descricao} (${modelo.cor})</p>`,
            )
            .join("") || ""
        }
        currentIndex={selectedProduto ? filteredProducts.findIndex((p) => p.id === selectedProduto.id) : 0}
        totalItems={filteredProducts.length}
        onNext={goToNext}
        onPrev={goToPrevious}
      />
    </div>
  )
}
