"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Calculator, Download, Share2, Info, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"

export default function CalculadoraMetragem() {
  const [medidaParede, setMedidaParede] = useState<"metros" | "centimetros">("metros")
  const [largura, setLargura] = useState<string>("")
  const [altura, setAltura] = useState<string>("")
  const [quantidadeParedes, setQuantidadeParedes] = useState<string>("1")
  const [descontoJanelas, setDescontoJanelas] = useState<string>("0")
  const [descontoPortas, setDescontoPortas] = useState<string>("0")
  const [tipoRolo, setTipoRolo] = useState<string>("padrao")
  const [resultado, setResultado] = useState<{
    areaTotal: number
    areaLiquida: number
    rolosNecessarios: number
    sobra: number
    custoEstimado: number
  } | null>(null)
  const [texturaSelecionada, setTexturaSelecionada] = useState<string>("")
  const [precoMetro, setPrecoMetro] = useState<string>("120")

  const texturas = [
    { id: "textura-1", nome: "Linho Premium", imagem: "/catalog-images/texturas-138.jpg", preco: 120 },
    { id: "textura-2", nome: "Mármore Bege", imagem: "/catalog-images/texturas-129.jpg", preco: 150 },
    { id: "textura-3", nome: "Concreto Desgastado", imagem: "/catalog-images/texturas-134.jpg", preco: 130 },
    { id: "textura-4", nome: "Metálico Perolado", imagem: "/catalog-images/texturas-140.jpg", preco: 180 },
    { id: "textura-5", nome: "Linho Colorido", imagem: "/catalog-images/texturas-139.jpg", preco: 140 },
    { id: "textura-6", nome: "Mármore com Veios Dourados", imagem: "/catalog-images/texturas-153.jpg", preco: 200 },
    { id: "textura-7", nome: "Linho Azul", imagem: "/catalog-images/texturas-157.jpg", preco: 150 },
    { id: "textura-8", nome: "Textura Minimalista", imagem: "/catalog-images/texturas-152.jpg", preco: 110 },
  ]

  const calcularMetragem = () => {
    // Converter para números
    const larguraNum = Number.parseFloat(largura)
    const alturaNum = Number.parseFloat(altura)
    const quantidadeParedesNum = Number.parseInt(quantidadeParedes)
    const descontoJanelasNum = Number.parseFloat(descontoJanelas) || 0
    const descontoPortasNum = Number.parseFloat(descontoPortas) || 0
    const precoMetroNum = Number.parseFloat(precoMetro)

    // Verificar se os valores são válidos
    if (isNaN(larguraNum) || isNaN(alturaNum) || larguraNum <= 0 || alturaNum <= 0) {
      alert("Por favor, insira valores válidos para largura e altura.")
      return
    }

    // Converter de centímetros para metros se necessário
    const larguraMetros = medidaParede === "centimetros" ? larguraNum / 100 : larguraNum
    const alturaMetros = medidaParede === "centimetros" ? alturaNum / 100 : alturaNum

    // Calcular área total
    const areaTotal = larguraMetros * alturaMetros * quantidadeParedesNum

    // Calcular área líquida (descontando janelas e portas)
    const areaLiquida = Math.max(0, areaTotal - descontoJanelasNum - descontoPortasNum)

    // Definir tamanho do rolo
    const tamanhoRolo = tipoRolo === "padrao" ? 5.3 : tipoRolo === "grande" ? 10 : 3

    // Calcular quantidade de rolos necessários (arredondando para cima)
    const rolosNecessarios = Math.ceil(areaLiquida / tamanhoRolo)

    // Calcular sobra
    const sobra = rolosNecessarios * tamanhoRolo - areaLiquida

    // Calcular custo estimado
    const custoEstimado = areaLiquida * precoMetroNum

    // Atualizar o resultado
    setResultado({
      areaTotal,
      areaLiquida,
      rolosNecessarios,
      sobra,
      custoEstimado,
    })
  }

  const handleTexturaSelecionada = (id: string) => {
    setTexturaSelecionada(id)
    const textura = texturas.find((t) => t.id === id)
    if (textura) {
      setPrecoMetro(textura.preco.toString())
    }
  }

  const formatarNumero = (numero: number) => {
    return numero.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  }

  const compartilharResultado = () => {
    if (!resultado) return

    const mensagem = `
*Cálculo de Papel de Parede - Art House*

Dimensões: ${largura}${medidaParede === "metros" ? "m" : "cm"} x ${altura}${medidaParede === "metros" ? "m" : "cm"}
Quantidade de paredes: ${quantidadeParedes}
Área total: ${formatarNumero(resultado.areaTotal)} m²
Área líquida (com descontos): ${formatarNumero(resultado.areaLiquida)} m²
Rolos necessários: ${resultado.rolosNecessarios}
Sobra estimada: ${formatarNumero(resultado.sobra)} m²
Custo estimado: R$ ${formatarNumero(resultado.custoEstimado)}

${texturaSelecionada ? `Textura selecionada: ${texturas.find((t) => t.id === texturaSelecionada)?.nome}` : ""}

Solicite seu orçamento personalizado!
`

    const whatsappUrl = `https://wa.me/5561986792057?text=${encodeURIComponent(mensagem)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50">
      <Header />

      <div className="pt-24">
        {/* Breadcrumb */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 text-gray-700 hover:text-gray-800 transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span className="font-medium">Voltar</span>
              </Link>
              <div className="h-6 w-px bg-gray-300" />
              <h1 className="text-2xl font-bold text-gray-900">Calculadora de Metragem</h1>
            </div>
          </div>
        </div>

        {/* Conteúdo Principal */}
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Coluna da Esquerda - Formulário */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Dimensões da Parede</h2>

                <div className="space-y-6">
                  <div>
                    <Label className="text-base">Unidade de medida</Label>
                    <RadioGroup
                      value={medidaParede}
                      onValueChange={(value) => setMedidaParede(value as "metros" | "centimetros")}
                      className="flex space-x-4 mt-2"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="metros" id="metros" />
                        <Label htmlFor="metros">Metros</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="centimetros" id="centimetros" />
                        <Label htmlFor="centimetros">Centímetros</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="largura">Largura</Label>
                      <div className="relative">
                        <Input
                          id="largura"
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder={medidaParede === "metros" ? "Ex: 3.5" : "Ex: 350"}
                          value={largura}
                          onChange={(e) => setLargura(e.target.value)}
                        />
                        <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-gray-500">
                          {medidaParede === "metros" ? "m" : "cm"}
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="altura">Altura</Label>
                      <div className="relative">
                        <Input
                          id="altura"
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder={medidaParede === "metros" ? "Ex: 2.7" : "Ex: 270"}
                          value={altura}
                          onChange={(e) => setAltura(e.target.value)}
                        />
                        <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-gray-500">
                          {medidaParede === "metros" ? "m" : "cm"}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="quantidade-paredes">Quantidade de paredes</Label>
                    <Select value={quantidadeParedes} onValueChange={setQuantidadeParedes}>
                      <SelectTrigger id="quantidade-paredes">
                        <SelectValue placeholder="Selecione a quantidade" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 parede</SelectItem>
                        <SelectItem value="2">2 paredes</SelectItem>
                        <SelectItem value="3">3 paredes</SelectItem>
                        <SelectItem value="4">4 paredes</SelectItem>
                        <SelectItem value="5">5 paredes</SelectItem>
                        <SelectItem value="6">6 paredes ou mais</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="desconto-janelas">Desconto para janelas (m²)</Label>
                      <div className="text-sm text-gray-500 flex items-center">
                        <Info className="w-4 h-4 mr-1" />
                        <span>Opcional</span>
                      </div>
                    </div>
                    <Input
                      id="desconto-janelas"
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="Ex: 2.4"
                      value={descontoJanelas}
                      onChange={(e) => setDescontoJanelas(e.target.value)}
                    />
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="desconto-portas">Desconto para portas (m²)</Label>
                      <div className="text-sm text-gray-500 flex items-center">
                        <Info className="w-4 h-4 mr-1" />
                        <span>Opcional</span>
                      </div>
                    </div>
                    <Input
                      id="desconto-portas"
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="Ex: 1.6"
                      value={descontoPortas}
                      onChange={(e) => setDescontoPortas(e.target.value)}
                    />
                  </div>

                  <div className="space-y-4">
                    <Label>Tipo de rolo</Label>
                    <RadioGroup
                      value={tipoRolo}
                      onValueChange={setTipoRolo}
                      className="grid grid-cols-1 md:grid-cols-3 gap-4"
                    >
                      <div className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-gray-50 cursor-pointer">
                        <RadioGroupItem value="pequeno" id="pequeno" />
                        <Label htmlFor="pequeno" className="cursor-pointer">
                          Pequeno (3m²)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-gray-50 cursor-pointer">
                        <RadioGroupItem value="padrao" id="padrao" />
                        <Label htmlFor="padrao" className="cursor-pointer">
                          Padrão (5.3m²)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 border rounded-lg p-3 hover:bg-gray-50 cursor-pointer">
                        <RadioGroupItem value="grande" id="grande" />
                        <Label htmlFor="grande" className="cursor-pointer">
                          Grande (10m²)
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="preco-metro">Preço por m² (R$)</Label>
                      <div className="text-sm text-gray-500 flex items-center">
                        <Info className="w-4 h-4 mr-1" />
                        <span>Estimativa</span>
                      </div>
                    </div>
                    <Input
                      id="preco-metro"
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="Ex: 120.00"
                      value={precoMetro}
                      onChange={(e) => setPrecoMetro(e.target.value)}
                    />
                  </div>

                  <Button onClick={calcularMetragem} className="w-full">
                    <Calculator className="w-4 h-4 mr-2" />
                    Calcular
                  </Button>
                </div>
              </div>

              {/* Seleção de Textura */}
              <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Selecione uma Textura (Opcional)</h2>
                <p className="text-gray-600 mb-4">
                  Escolha uma textura para obter uma estimativa de preço mais precisa.
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {texturas.map((textura) => (
                    <div
                      key={textura.id}
                      className={`relative rounded-lg overflow-hidden border cursor-pointer transition-all ${
                        texturaSelecionada === textura.id ? "ring-2 ring-green-500 border-green-500" : "hover:shadow-md"
                      }`}
                      onClick={() => handleTexturaSelecionada(textura.id)}
                    >
                      <Image
                        src={textura.imagem || "/placeholder.svg"}
                        alt={textura.nome}
                        width={120}
                        height={120}
                        className="w-full aspect-square object-cover"
                      />
                      {texturaSelecionada === textura.id && (
                        <div className="absolute top-2 right-2 bg-green-500 rounded-full p-1">
                          <Check className="w-4 h-4 text-white" />
                        </div>
                      )}
                      <div className="p-2 bg-white">
                        <p className="text-xs font-medium truncate">{textura.nome}</p>
                        <p className="text-xs text-gray-500">R$ {textura.preco}/m²</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-4 text-center">
                  <Link href="/catalogos/texturas">
                    <Button variant="outline" size="sm">
                      Ver Mais Texturas
                    </Button>
                  </Link>
                </div>
              </div>
            </div>

            {/* Coluna da Direita - Resultado e Informações */}
            <div className="lg:col-span-1">
              {resultado && (
                <Card className="mb-6">
                  <CardHeader className="bg-green-50">
                    <CardTitle>Resultado do Cálculo</CardTitle>
                    <CardDescription>Baseado nas medidas informadas</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-500">Área total</p>
                        <p className="text-lg font-semibold">{formatarNumero(resultado.areaTotal)} m²</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Área líquida (com descontos)</p>
                        <p className="text-lg font-semibold">{formatarNumero(resultado.areaLiquida)} m²</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Rolos necessários</p>
                        <p className="text-lg font-semibold">{resultado.rolosNecessarios}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Sobra estimada</p>
                        <p className="text-lg font-semibold">{formatarNumero(resultado.sobra)} m²</p>
                      </div>
                      <div className="pt-2 border-t">
                        <p className="text-sm text-gray-500">Custo estimado</p>
                        <p className="text-xl font-bold text-green-700">R$ {formatarNumero(resultado.custoEstimado)}</p>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col space-y-2">
                    <Button onClick={compartilharResultado} className="w-full bg-green-600 hover:bg-green-700">
                      <Share2 className="w-4 h-4 mr-2" />
                      Solicitar Orçamento
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Download className="w-4 h-4 mr-2" />
                      Salvar Resultado
                    </Button>
                  </CardFooter>
                </Card>
              )}

              <div className="bg-white rounded-lg shadow-sm border p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Informações Úteis</h2>

                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="item-1">
                    <AccordionTrigger>Como calcular a área?</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-gray-600 mb-2">
                        Para calcular a área de uma parede, multiplique a largura pela altura. Por exemplo, uma parede
                        de 3m x 2,7m tem uma área de 8,1m².
                      </p>
                      <p className="text-gray-600">
                        Para múltiplas paredes, calcule a área de cada uma e some os resultados.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-2">
                    <AccordionTrigger>Como calcular descontos?</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-gray-600 mb-2">
                        Para janelas e portas, calcule a área de cada uma e subtraia do total. Por exemplo:
                      </p>
                      <ul className="list-disc list-inside text-gray-600 space-y-1">
                        <li>Janela padrão: 1,2m x 1,0m = 1,2m²</li>
                        <li>Porta padrão: 0,8m x 2,1m = 1,68m²</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-3">
                    <AccordionTrigger>Tamanhos de rolos</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-gray-600 mb-2">Os tamanhos padrão de rolos são:</p>
                      <ul className="list-disc list-inside text-gray-600 space-y-1">
                        <li>Pequeno: 3m² (0,53m x 5,7m)</li>
                        <li>Padrão: 5,3m² (0,53m x 10m)</li>
                        <li>Grande: 10m² (1m x 10m)</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-4">
                    <AccordionTrigger>Dicas de instalação</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-gray-600 mb-2">Algumas dicas importantes:</p>
                      <ul className="list-disc list-inside text-gray-600 space-y-1">
                        <li>Adicione 10% extra para compensar erros e recortes</li>
                        <li>Verifique se as paredes estão niveladas e lisas</li>
                        <li>Remova tomadas e interruptores antes da aplicação</li>
                        <li>Utilize ferramentas adequadas para um acabamento perfeito</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>

                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-semibold text-blue-800 mb-2">Precisa de ajuda?</h3>
                  <p className="text-blue-700 text-sm mb-4">
                    Entre em contato com nossa equipe para um orçamento personalizado ou para tirar dúvidas sobre a
                    instalação.
                  </p>
                  <Button variant="outline" className="w-full border-blue-300 text-blue-700 hover:bg-blue-100">
                    Falar com um Especialista
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <WhatsAppFloat />
    </div>
  )
}
