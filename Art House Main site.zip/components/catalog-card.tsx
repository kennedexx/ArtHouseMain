import Link from "next/link"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface CatalogCardProps {
  title: string
  description: string
  image: string
  href: string
  className?: string
}

export function CatalogCard({ title, description, image, href, className }: CatalogCardProps) {
  return (
    <Link
      href={href}
      className={cn(
        "group relative flex h-[300px] w-full flex-col overflow-hidden rounded-lg transition-all hover:shadow-lg md:h-[350px]",
        className,
      )}
    >
      <div className="relative h-full w-full overflow-hidden">
        <Image
          src={image || "/placeholder.svg"}
          alt={title}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        {/* Removida a camada de overlay escuro */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 to-transparent">
          <h3 className="text-xl font-bold text-white">{title}</h3>
          <p className="mt-1 text-sm text-white/90">{description}</p>
        </div>
      </div>
    </Link>
  )
}
