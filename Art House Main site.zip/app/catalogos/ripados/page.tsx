"use client"
import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"

export default function CatalogoRipados() {
  const [selectedColor, setSelectedColor] = useState("Todas as Cores")
  const [selectedCategory, setSelectedCategory] = useState("Todas as Categorias")
  const [imageError, setImageError] = useState<{ [key: number]: boolean }>({})

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const produtos = [
    {
      id: 1,
      nome: "Ripado Vertical Bege Claro",
      codigo: "AD200801R",
      cor: "Bege",
      textura: "Vertical",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/ripados-1.jpg",
      descricao: "Ripado vertical em tons de bege claro, perfeito para criar ambientes aconchegantes e sofisticados.",
      modelos: [
        { codigo: "AD200801R", descricao: "Bege Claro Vertical", cor: "Bege Claro" },
        { codigo: "AD200801V", descricao: "Bege Claro Variação", cor: "Bege Natural" },
      ],
    },
    {
      id: 2,
      nome: "Ripado Vertical Creme",
      codigo: "AD200802R",
      cor: "Creme",
      textura: "Vertical",
      categoria: "Clean",
      imagem: "/catalog-images/ripados-1.jpg",
      descricao: "Ripado vertical em tons de creme, ideal para ampliar visualmente o ambiente com elegância.",
      modelos: [
        { codigo: "AD200802R", descricao: "Creme Vertical", cor: "Creme" },
        { codigo: "AD200802L", descricao: "Creme Liso", cor: "Creme Liso" },
      ],
    },
    {
      id: 3,
      nome: "Ripado Vertical Bege Médio",
      codigo: "AD200803R",
      cor: "Bege",
      textura: "Vertical",
      categoria: "Natural",
      imagem: "/catalog-images/ripados-1.jpg",
      descricao: "Ripado vertical em bege médio, trazendo naturalidade e conforto aos ambientes.",
      modelos: [
        { codigo: "AD200803R", descricao: "Bege Médio Vertical", cor: "Bege Médio" },
        { codigo: "AD200803T", descricao: "Bege Médio Texturizado", cor: "Bege Textura" },
      ],
    },
    {
      id: 4,
      nome: "Ripado Vertical Madeira Escura",
      codigo: "AD200804R",
      cor: "Marrom",
      textura: "Vertical",
      categoria: "Rústico",
      imagem: "/catalog-images/ripados-1.jpg",
      descricao: "Ripado vertical em tons de madeira escura, para ambientes com personalidade marcante.",
      modelos: [
        { codigo: "AD200804R", descricao: "Madeira Escura Vertical", cor: "Marrom Escuro" },
        { codigo: "AD200804N", descricao: "Madeira Natural", cor: "Marrom Natural" },
      ],
    },
    {
      id: 5,
      nome: "Ripado Vertical Cinza Escuro",
      codigo: "AD200805R",
      cor: "Cinza",
      textura: "Vertical",
      categoria: "Moderno",
      imagem: "/catalog-images/ripados-2.jpg",
      descricao: "Ripado vertical em cinza escuro, perfeito para ambientes modernos e sofisticados.",
      modelos: [
        { codigo: "AD200805R", descricao: "Cinza Escuro Vertical", cor: "Cinza Escuro" },
        { codigo: "AD200805M", descricao: "Cinza Escuro Mate", cor: "Cinza Mate" },
      ],
    },
    {
      id: 6,
      nome: "Ripado Vertical Cinza Médio",
      codigo: "AD200806R",
      cor: "Cinza",
      textura: "Vertical",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/ripados-2.jpg",
      descricao: "Ripado vertical em cinza médio, equilibrando modernidade e aconchego.",
      modelos: [
        { codigo: "AD200806R", descricao: "Cinza Médio Vertical", cor: "Cinza Médio" },
        { codigo: "AD200806S", descricao: "Cinza Médio Suave", cor: "Cinza Suave" },
      ],
    },
    {
      id: 7,
      nome: "Ripado Vertical Bege Premium",
      codigo: "AD200807R",
      cor: "Bege",
      textura: "Vertical",
      categoria: "Premium",
      imagem: "/catalog-images/ripados-2.jpg",
      descricao: "Ripado vertical premium em tons de bege, para ambientes de alto padrão.",
      modelos: [
        { codigo: "AD200807R", descricao: "Bege Premium Vertical", cor: "Bege Premium" },
        { codigo: "AD200807L", descricao: "Bege Premium Luxo", cor: "Bege Luxo" },
      ],
    },
    {
      id: 8,
      nome: "Ripado Vertical Dourado",
      codigo: "AD200808R",
      cor: "Dourado",
      textura: "Vertical",
      categoria: "Luxo",
      imagem: "/catalog-images/ripados-2.jpg",
      descricao: "Ripado vertical em tons dourados, trazendo sofisticação e elegância únicas.",
      modelos: [
        { codigo: "AD200808R", descricao: "Dourado Vertical", cor: "Dourado" },
        { codigo: "AD200808B", descricao: "Dourado Brilhante", cor: "Dourado Brilho" },
      ],
    },
  ]

  const cores = ["Todas as Cores", "Bege", "Creme", "Marrom", "Cinza", "Dourado"]

  const categorias = [
    "Todas as Categorias",
    "Contemporâneo",
    "Clean",
    "Natural",
    "Rústico",
    "Moderno",
    "Premium",
    "Luxo",
  ]

  const produtosFiltrados = produtos.filter((produto) => {
    const corMatch = selectedColor === "Todas as Cores" || produto.cor === selectedColor
    const categoriaMatch = selectedCategory === "Todas as Categorias" || produto.categoria === selectedCategory
    return corMatch && categoriaMatch
  })

  const handleImageError = (index: number) => {
    setImageError((prev) => ({ ...prev, [index]: true }))
  }

  const handleImageClick = (produto: any) => {
    const modelosHtml = produto.modelos
      .map(
        (modelo: any) =>
          `<p class="text-sm mb-1"><strong>${modelo.codigo}:</strong> ${modelo.descricao} (${modelo.cor})</p>`,
      )
      .join("")

    const modal = document.createElement("div")
    modal.className = "fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
    modal.innerHTML = `
      <div class="relative max-w-4xl max-h-full w-full">
        <div class="flex flex-col md:flex-row bg-white rounded-lg overflow-hidden max-h-[90vh]">
          <div class="md:w-2/3">
            <img src="${produto.imagem}" alt="${produto.nome}" class="w-full h-64 md:h-full object-cover" />
          </div>
          <div class="md:w-1/3 p-6 overflow-y-auto">
            <h3 class="font-bold text-xl mb-3 text-gray-800">${produto.nome}</h3>
            <p class="text-gray-600 mb-4">${produto.descricao}</p>
            <div class="space-y-2 mb-4">
              <p class="text-sm"><strong>Código:</strong> ${produto.codigo}</p>
              <p class="text-sm"><strong>Cor:</strong> ${produto.cor}</p>
              <p class="text-sm"><strong>Textura:</strong> ${produto.textura}</p>
              <p class="text-sm"><strong>Categoria:</strong> ${produto.categoria}</p>
            </div>
            <div class="border-t pt-4">
              <strong class="text-sm block mb-2">Modelos inclusos:</strong>
              ${modelosHtml}
            </div>
            <div class="mt-6">
              <a href="https://wa.me/5561986792057?text=Olá! Gostaria de saber mais sobre o ${produto.nome} (${produto.codigo})" 
                 target="_blank" 
                 class="block w-full bg-green-500 text-white text-center py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors">
                💬 Solicitar Orçamento
              </a>
            </div>
          </div>
        </div>
        <button class="absolute top-4 right-4 text-white bg-black bg-opacity-50 rounded-full w-10 h-10 flex items-center justify-center hover:bg-opacity-75 transition-colors" onclick="this.parentElement.parentElement.remove()">
          ✕
        </button>
      </div>
    `
    modal.onclick = (e) => {
      if (e.target === modal) modal.remove()
    }
    document.body.appendChild(modal)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-yellow-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-gray-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4">
              <Image src="/logo-art-house.png" alt="Art House Logo" width={120} height={60} className="h-12 w-auto" />
            </Link>
            <div className="flex items-center space-x-6">
              <a
                href="/#catalogos"
                className="hidden md:block text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium"
              >
                ← Voltar aos Catálogos
              </a>
              <a
                href="https://wa.me/5561986792057"
                target="_blank"
                className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-6 py-2 rounded-full font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                rel="noreferrer"
              >
                💬 WhatsApp
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-amber-400/10 to-yellow-400/10"></div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-amber-400 to-yellow-600 rounded-3xl mb-8 text-4xl">
              🪵
            </div>

            <h1 className="font-montserrat font-bold text-5xl md:text-6xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-6">
              Papéis Ripados
            </h1>

            <p className="text-xl text-gray-600 mb-6 max-w-3xl mx-auto leading-relaxed">
              Efeitos de madeira ripada que trazem aconchego e naturalidade aos seus ambientes. Texturas realistas que
              conectam você com a natureza.
            </p>

            <p className="text-gray-500 text-lg mb-8 max-w-3xl mx-auto">
              (Não encontrou o que procura? Entre em contato no nosso WhatsApp, possuímos mais catálogos fora do site,
              além disso, também podemos fazer personalizados.)
            </p>

            <div className="w-24 h-1 bg-gradient-to-r from-amber-400 to-yellow-400 mx-auto rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Cor</label>
                <select
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white"
                >
                  {cores.map((cor) => (
                    <option key={cor} value={cor}>
                      {cor}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Categoria</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent bg-white"
                >
                  {categorias.map((categoria) => (
                    <option key={categoria} value={categoria}>
                      {categoria}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="mt-4 text-center">
              <p className="text-gray-600">
                Mostrando <span className="font-semibold text-amber-600">{produtosFiltrados.length}</span> produtos
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {produtosFiltrados.map((produto, index) => (
              <div
                key={produto.id}
                className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 overflow-hidden border border-amber-100"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  {!imageError[index] ? (
                    <Image
                      src={produto.imagem || "/placeholder.svg"}
                      alt={produto.nome}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                      onError={() => handleImageError(index)}
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-amber-100 to-yellow-100 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-4xl mb-2">🪵</div>
                        <p className="text-gray-500 text-sm">{produto.nome}</p>
                      </div>
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-amber-500/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                  <div className="absolute bottom-4 left-4 right-4 transform translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                    <h3 className="text-white font-semibold text-lg mb-2">{produto.nome}</h3>
                    <button
                      className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-white/30 transition-colors w-full"
                      onClick={() => handleImageClick(produto)}
                    >
                      Ver Detalhes
                    </button>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="font-semibold text-lg text-gray-800 mb-2">{produto.nome}</h3>
                  <p className="text-gray-600 text-sm mb-3">{produto.descricao}</p>
                  <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
                    <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded-full">{produto.cor}</span>
                    <span className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full">{produto.categoria}</span>
                  </div>
                  <button
                    onClick={() => handleImageClick(produto)}
                    className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 text-white py-2 rounded-lg font-medium hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                  >
                    Ver Modelos
                  </button>
                </div>
              </div>
            ))}
          </div>

          {produtosFiltrados.length === 0 && (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-2xl font-semibold text-gray-700 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-500">Tente ajustar os filtros para encontrar o que procura.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-amber-400/10 to-yellow-400/10">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="font-montserrat font-bold text-3xl text-[#1B5E3A] mb-6">Gostou de algum modelo?</h2>
            <p className="text-gray-600 text-lg mb-8">
              Entre em contato conosco para solicitar orçamento, tirar dúvidas ou conhecer mais opções disponíveis.
            </p>
            <a
              href="https://wa.me/5561986792057"
              target="_blank"
              className="group inline-flex items-center gap-3 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-10 py-4 rounded-2xl font-montserrat font-semibold text-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 relative overflow-hidden"
              rel="noreferrer"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
              <span className="relative">💬 Falar no WhatsApp</span>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 to-black text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#1B5E3A]/10 to-transparent"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div className="animate-fade-in-up">
              <div className="flex items-center mb-6">
                <Image
                  src="/logo-art-house.png"
                  alt="Art House Logo"
                  width={150}
                  height={75}
                  className="h-16 w-auto filter brightness-0 invert"
                />
              </div>
              <h3 className="font-montserrat font-bold text-2xl text-white mb-4">
                Art House | 25 anos transformando ambientes em Brasília.
              </h3>
              <p className="text-gray-300 text-lg leading-relaxed">
                Especialistas em papel de parede com a qualidade e confiança que você merece.
              </p>
            </div>

            <div className="animate-fade-in-up animation-delay-200">
              <h4 className="font-montserrat font-bold text-xl text-white mb-6">Links Rápidos</h4>
              <div className="space-y-3">
                <a href="/#hero" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Home
                </a>
                <a href="/#produtos" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Produtos
                </a>
                <a href="/#catalogos" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Catálogos
                </a>
                <a href="/#vantagens" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Vantagens
                </a>
                <a href="/sobre" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Sobre
                </a>
                <a href="/contato" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Contato
                </a>
              </div>
            </div>

            <div className="animate-fade-in-up animation-delay-400">
              <h4 className="font-montserrat font-bold text-xl text-white mb-6">Contato</h4>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📍
                  </div>
                  <p className="text-gray-300 text-lg">CLS 311, Bloco C, Loja 29, Asa Sul, Brasília - DF</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📧
                  </div>
                  <a
                    href="mailto:contato@arthousepapeldeparede.com.br"
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                  >
                    contato@arthousepapeldeparede.com.br
                  </a>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📱
                  </div>
                  <a
                    href="https://wa.me/5561986792057"
                    target="_blank"
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                    rel="noreferrer"
                  >
                    (61) 9 8679-2057
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-400 text-lg">
              &copy; 2024 Art House. Todos os direitos reservados. | Desenvolvido com ❤️ para transformar ambientes.
            </p>
          </div>
        </div>
      </footer>

      {/* Floating Back Button - Mobile Only */}
      <a
        href="/#catalogos"
        className="fixed bottom-6 left-6 z-50 md:hidden bg-gradient-to-r from-gray-600 to-gray-700 text-white p-4 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 group"
      >
        <svg
          className="w-6 h-6 group-hover:scale-110 transition-transform duration-300"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold">
          📖
        </div>
      </a>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/5561986792057"
        target="_blank"
        className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-green-500 to-green-600 text-white p-5 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 animate-pulse-slow group"
        rel="noreferrer"
      >
        <svg
          className="w-8 h-8 group-hover:scale-110 transition-transform duration-300"
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488" />
        </svg>
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-xs font-bold animate-bounce">
          !
        </div>
      </a>
    </div>
  )
}
