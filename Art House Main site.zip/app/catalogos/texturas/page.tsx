"use client"
import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Share2, Search, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"
import ImageModal from "@/components/ImageModal"

// Import the full product catalog from a separate file to keep the component cleaner
import { produtos } from "@/data/texturas-produtos"

export default function CatalogoTexturas() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedColor, setSelectedColor] = useState("Todas as Cores")
  const [selectedTextura, setSelectedTextura] = useState("Todas as Texturas")
  const [selectedProduto, setSelectedProduto] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const cores = [
    "Todas as Cores",
    "Branco",
    "Cinza",
    "Bege",
    "Marrom",
    "Preto",
    "Azul",
    "Verde",
    "Vermelho",
    "Dourado",
    "Prata",
    "Natural",
    "Terracota",
    "Cobre",
    "Bronze",
    "Creme",
    "Amarelo",
    "Roxo",
    "Vinho",
    "Rosa",
    "Lilás",
    "Taupe",
    "Verde Oliva",
    "Off-White",
  ]

  const texturas = [
    "Todas as Texturas",
    "Linho",
    "Trançada",
    "Geométrica",
    "Premium",
    "Concreto",
    "Cimento",
    "Elegante",
    "Mista",
    "Variada",
    "Linear",
    "Folhagem",
    "Galhos",
    "Decorativa",
    "Colorida",
    "Suave",
    "Refinada",
    "Texturizada",
    "Minimalista",
    "Natural",
    "Floral",
    "Neutro",
    "Azul",
    "Artística",
    "Escura",
    "Completa",
    "Pastel",
    "Sofisticada",
    "Delicada",
    "Moderna",
    "Terroso",
    "Gradação",
    "Aquático",
    "Clássica",
    "Ultra Suave",
    "Vibrante",
    "Padrões",
    "Coordenada",
    "Rústica",
    "Dourada",
    "Contrastes",
    "Romântico",
    "Diagonal",
    "Vertical",
    "Envelhecido",
    "Orgânica",
    "Mármore",
    "Mega Série",
    "Desgastada",
    "Clássico",
    "Arquitetônico",
    "Vintage",
    "Pátina",
    "Trama",
    "Tecido",
    "Pedra",
    "Madeira",
    "Listrada",
    "Ornamental",
    "Industrial",
    "Mármore",
    "Chevron",
    "Tropical",
    "Moderna",
    "Terrazzo",
    "Metálica",
    "Granulada",
    "Especial",
    "Mosaico",
    "Escovada",
  ]

  const filteredProducts = produtos.filter((produto) => {
    const matchesSearch =
      produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      produto.cores.some((cor) => cor.toLowerCase().includes(searchTerm.toLowerCase())) ||
      produto.modelos.some((modelo) => modelo.codigo.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesColor = selectedColor === "Todas as Cores" || produto.cores.includes(selectedColor)
    const matchesTextura = selectedTextura === "Todas as Texturas" || produto.textura === selectedTextura

    return matchesSearch && matchesColor && matchesTextura
  })

  const openModal = (produto: any) => {
    setSelectedProduto(produto)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setSelectedProduto(null)
    setIsModalOpen(false)
  }

  const goToPrevious = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const previousIndex = currentIndex === 0 ? filteredProducts.length - 1 : currentIndex - 1
      setSelectedProduto(filteredProducts[previousIndex])
    }
  }

  const goToNext = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const nextIndex = currentIndex === filteredProducts.length - 1 ? 0 : currentIndex + 1
      setSelectedProduto(filteredProducts[nextIndex])
    }
  }

  const handlePedirOrcamento = (produto: any) => {
    const modelosTexto = produto.modelos
      .map((modelo: any) => `• ${modelo.codigo} - ${modelo.descricao} (${modelo.cor})`)
      .join("\n")

    const mensagem = `Olá! Gostaria de solicitar um orçamento para os papéis de parede:

*${produto.nome}*

Modelos inclusos:
${modelosTexto}

Aguardo retorno. Obrigado!`

    const whatsappUrl = `https://wa.me/5561986792057?text=${encodeURIComponent(mensagem)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-50">
      <Header />

      <div className="pt-24">
        {/* Breadcrumb */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 text-gray-700 hover:text-gray-800 transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span className="font-medium">Voltar</span>
              </Link>
              <div className="h-6 w-px bg-gray-300" />
              <h1 className="text-2xl font-bold text-gray-900">Catálogo Texturas</h1>
            </div>
          </div>
        </div>

        {/* Hero Section */}
        <div className="bg-gradient-to-r from-gray-600 to-gray-800 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Coleção Texturas</h2>
            <p className="text-xl md:text-2xl mb-6 text-gray-100">Profundidade e sofisticação em cada detalhe</p>
            <p className="text-lg text-gray-200 max-w-2xl mx-auto">
              Descubra nossa linha de papéis texturizados que adicionam dimensão e personalidade aos ambientes.
            </p>
          </div>
        </div>

        {/* Filters Section */}
        <section className="py-8 bg-white/50 backdrop-blur-sm">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Cor</label>
                  <select
                    value={selectedColor}
                    onChange={(e) => setSelectedColor(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent bg-white"
                  >
                    {cores.map((cor) => (
                      <option key={cor} value={cor}>
                        {cor}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Textura</label>
                  <select
                    value={selectedTextura}
                    onChange={(e) => setSelectedTextura(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent bg-white"
                  >
                    {texturas.map((textura) => (
                      <option key={textura} value={textura}>
                        {textura}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex items-end">
                  <div className="w-full">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Buscar</label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                      <input
                        type="text"
                        placeholder="Buscar por nome, cor ou código..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gray-500 focus:border-transparent bg-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-4 text-center">
                <p className="text-gray-600">
                  Mostrando <span className="font-semibold text-gray-600">{filteredProducts.length}</span> produtos
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Products Section */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            {/* Grid de Produtos */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((produto) => (
                <div
                  key={produto.id}
                  className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-all duration-300 overflow-hidden group"
                >
                  <div className="relative">
                    <Image
                      src={produto.imagem || "/placeholder.svg"}
                      alt={produto.nome}
                      width={450}
                      height={300}
                      className="w-full aspect-[3/2] object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                      onClick={() => openModal(produto)}
                    />
                    <div className="absolute top-3 right-3 flex gap-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        className="w-8 h-8 p-0 bg-white/90 hover:bg-white"
                        onClick={() => openModal(produto)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white">
                        <Heart className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white">
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="absolute bottom-3 left-3 flex gap-1">
                      {produto.cores.slice(0, 3).map((cor, index) => (
                        <div
                          key={index}
                          className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
                          style={{
                            backgroundColor:
                              cor === "Cinza"
                                ? "#6B7280"
                                : cor === "Bege"
                                  ? "#D2B48C"
                                  : cor === "Marrom"
                                    ? "#8B4513"
                                    : cor === "Branco"
                                      ? "#FFFFFF"
                                      : cor === "Preto"
                                        ? "#000000"
                                        : cor === "Azul"
                                          ? "#3B82F6"
                                          : cor === "Verde"
                                            ? "#10B981"
                                            : cor === "Vermelho"
                                              ? "#EF4444"
                                              : cor === "Dourado"
                                                ? "#DAA520"
                                                : cor === "Prata"
                                                  ? "#C0C0C0"
                                                  : cor === "Natural"
                                                    ? "#DEB887"
                                                    : cor === "Roxo"
                                                      ? "#8B5CF6"
                                                      : cor === "Verde Claro"
                                                        ? "#86EFAC"
                                                        : cor === "Cinza Claro"
                                                          ? "#D1D5DB"
                                                          : cor === "Taupe"
                                                            ? "#B8A99A"
                                                            : cor === "Verde Oliva"
                                                              ? "#708238"
                                                              : cor === "Off-White"
                                                                ? "#F5F5F5"
                                                                : "#9CA3AF",
                          }}
                        />
                      ))}
                      {produto.cores.length > 3 && (
                        <div className="w-4 h-4 rounded-full border-2 border-white shadow-sm bg-gray-400 flex items-center justify-center text-xs text-white font-bold">
                          +
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="p-4">
                    <h3 className="font-semibold text-lg text-gray-900 mb-2">{produto.nome}</h3>
                    <p className="text-sm text-gray-600 mb-2">{produto.modelos.length} modelos inclusos</p>
                    <p className="text-sm text-gray-600 mb-3">
                      Cores: {produto.cores.slice(0, 3).join(", ")}
                      {produto.cores.length > 3 && "..."}
                    </p>

                    <div className="flex items-center justify-center">
                      <Button
                        className="w-full bg-green-600 hover:bg-green-700 text-white"
                        onClick={() => handlePedirOrcamento(produto)}
                      >
                        💬 Pedir Orçamento
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-xl font-semibold text-gray-600 mb-2">Nenhum produto encontrado</h3>
                <p className="text-gray-500">Tente buscar por uma cor ou textura diferente</p>
              </div>
            )}

            {/* Informações Adicionais */}
            <div className="mt-12 bg-white rounded-lg shadow-sm border p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Por que escolher nossa Coleção Texturas?
              </h3>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">🏗️</span>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Profundidade Visual</h4>
                  <p className="text-gray-600">Texturas que criam dimensão e interesse visual nos ambientes.</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">✋</span>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Experiência Tátil</h4>
                  <p className="text-gray-600">Superfícies que convidam ao toque e proporcionam sensações únicas.</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">🎨</span>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">Versatilidade</h4>
                  <p className="text-gray-600">Texturas que se adaptam a diferentes estilos e ambientes.</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      <Footer />
      <WhatsAppFloat />
      <ImageModal
        isOpen={isModalOpen}
        onClose={closeModal}
        imageSrc={selectedProduto?.imagem || "/placeholder.svg"}
        imageAlt={selectedProduto?.nome || ""}
        imageTitle={selectedProduto?.nome || ""}
        description={selectedProduto?.descricao}
        modelosHtml={
          selectedProduto?.modelos
            ?.map(
              (modelo: any) =>
                `<p class="text-sm mb-1"><strong>${modelo.codigo}:</strong> ${modelo.descricao} (${modelo.cor})</p>`,
            )
            .join("") || ""
        }
        currentIndex={selectedProduto ? filteredProducts.findIndex((p) => p.id === selectedProduto.id) : 0}
        total={filteredProducts.length}
        onGoToPrevious={goToPrevious}
        onGoToNext={goToNext}
      />
    </div>
  )
}
