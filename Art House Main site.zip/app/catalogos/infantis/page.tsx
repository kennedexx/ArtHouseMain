"use client"
import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import ImageModal from "@/components/ImageModal"

export default function CatalogoInfantis() {
  const [imageError, setImageError] = useState<{ [key: number]: boolean }>({})
  const [selectedImage, setSelectedImage] = useState<{
    src: string
    alt: string
    title: string
  } | null>(null)
  const [searchTerm, setSearchTerm] = useState("")

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const catalogImages = [
    // Imagem 1 - Nuvens e Céu
    {
      id: 1,
      src: "/catalog-images/infantil-1.jpg",
      alt: "Papel de parede infantil - Nuvens e Céu",
      title: "Nuvens e Céu",
      color: "Azul/Cinza",
      description:
        "YY204002R (Nuvens Cinzas) e YY203701R (Céu Azul com Nuvens). Perfeito para criar um ambiente tranquilo e sonhador.",
      codes: ["YY204002R", "YY203701R"],
    },
    // Imagem 2 - Animais da Savana
    {
      id: 2,
      src: "/catalog-images/infantil-2.jpg",
      alt: "Papel de parede infantil - Animais da Savana",
      title: "Animais da Savana",
      color: "Bege",
      description:
        "YY203101R - Leão, tigre, hipopótamo e outros animais da savana em fundo neutro. Ideal para estimular a imaginação.",
      codes: ["YY203101R"],
    },
    // Imagem 3 - Flocos de Neve
    {
      id: 3,
      src: "/catalog-images/infantil-3.jpg",
      alt: "Papel de parede infantil - Flocos de Neve",
      title: "Flocos de Neve",
      color: "Rosa/Azul",
      description:
        "YY204402R (Rosa), YY204403R (Azul Claro) e YY204401R (Azul). Flocos delicados em tons pastéis para ambiente acolhedor.",
      codes: ["YY204402R", "YY204403R", "YY204401R"],
    },
    // Imagem 4 - Bailarinas
    {
      id: 4,
      src: "/catalog-images/infantil-4.jpg",
      alt: "Papel de parede infantil - Bailarinas",
      title: "Bailarinas Douradas",
      color: "Dourado",
      description:
        "YY203701R - Bailarinas elegantes com detalhes dourados e estrelas. Perfeito para quartos de meninas que sonham em dançar.",
      codes: ["YY203701R"],
    },
    // Imagem 5 - Aviões
    {
      id: 5,
      src: "/catalog-images/infantil-5.jpg",
      alt: "Papel de parede infantil - Aviões",
      title: "Aviões Air Force",
      color: "Cinza/Branco",
      description: "YY204202R (Cinza) e YY204201R (Branco). Aviões e elementos da força aérea para futuros pilotos.",
      codes: ["YY204202R", "YY204201R"],
    },
    // Imagem 6 - Estrelas
    {
      id: 6,
      src: "/catalog-images/infantil-6.jpg",
      alt: "Papel de parede infantil - Estrelas",
      title: "Estrelas Douradas",
      color: "Dourado",
      description: "YY204901R - Estrelas douradas em fundo azul noturno. Crie um céu estrelado no quarto do seu filho.",
      codes: ["YY204901R"],
    },
    // Imagem 7 - Unicórnios
    {
      id: 7,
      src: "/catalog-images/infantil-7.jpg",
      alt: "Papel de parede infantil - Unicórnios",
      title: "Unicórnios Mágicos",
      color: "Rosa/Roxo",
      description:
        "YY203202R (Roxo/Lilás) e YY203201R (Rosa). Unicórnios encantados com castelos e arco-íris para um mundo de fantasia.",
      codes: ["YY203202R", "YY203201R"],
    },
    // Imagem 8 - Elefantes
    {
      id: 8,
      src: "/catalog-images/infantil-8.jpg",
      alt: "Papel de parede infantil - Elefantes",
      title: "Elefantes Listrados",
      color: "Multicolor",
      description:
        "YY204701R (Rosa), YY204702R (Azul), YY204703R (Verde) e YY204704R (Cinza). Elefantes fofos em listras verticais.",
      codes: ["YY204701R", "YY204702R", "YY204703R", "YY204704R"],
    },
    // Imagem 9 - Bolinhas
    {
      id: 9,
      src: "/catalog-images/infantil-9.jpg",
      alt: "Papel de parede infantil - Bolinhas Coloridas",
      title: "Bolinhas Coloridas",
      color: "Multicolor",
      description:
        "YY203501R (Azul), YY203502R (Rosa) e YY203503R (Laranja). Bolinhas alegres em cores vibrantes para ambientes divertidos.",
      codes: ["YY203501R", "YY203502R", "YY203503R"],
    },
    // Imagem 10 - Caminhões
    {
      id: 10,
      src: "/catalog-images/infantil-10.jpg",
      alt: "Papel de parede infantil - Caminhões e Veículos",
      title: "Caminhões e Veículos",
      color: "Azul/Verde",
      description:
        "YY204301R (Cinza), YY204302R (Verde), YY204303R (Azul) e YY203701R (Azul Escuro). Veículos diversos para pequenos aventureiros.",
      codes: ["YY204301R", "YY204302R", "YY204303R", "YY203701R"],
    },
    // Imagem 11 - Arco-íris
    {
      id: 11,
      src: "/catalog-images/infantil-11.jpg",
      alt: "Papel de parede infantil - Arco-íris e Nuvens",
      title: "Arco-íris e Nuvens",
      color: "Multicolor",
      description:
        "YY203401R (Multicolor) e YY203402R (Rosa/Lilás). Arco-íris delicados com nuvens para um quarto cheio de cor e alegria.",
      codes: ["YY203401R", "YY203402R"],
    },
    // Imagem 12 - Folhagens
    {
      id: 12,
      src: "/catalog-images/infantil-12.jpg",
      alt: "Papel de parede infantil - Folhagens Delicadas",
      title: "Folhagens Delicadas",
      color: "Neutro",
      description:
        "YY205205R (Rosa), YY205204R (Cinza), YY205203R (Bege) e YY205201R (Verde). Folhagens suaves para um ambiente natural e tranquilo.",
      codes: ["YY205205R", "YY205204R", "YY205203R", "YY205201R"],
    },
    // Imagem 13 - Listras
    {
      id: 13,
      src: "/catalog-images/infantil-13.jpg",
      alt: "Papel de parede infantil - Listras Delicadas",
      title: "Listras Delicadas",
      color: "Pastel",
      description:
        "YY203803R (Azul), YY203802R (Cinza) e YY203801R (Rosa). Listras verticais suaves em tons pastéis para um visual clean.",
      codes: ["YY203803R", "YY203802R", "YY203801R"],
    },
    // Imagem 14 - Cervinhos
    {
      id: 14,
      src: "/catalog-images/infantil-14.jpg",
      alt: "Papel de parede infantil - Cervinhos",
      title: "Cervinhos Adoráveis",
      color: "Neutro",
      description:
        "YY205003R (Rosa), YY205002R (Azul) e YY205001R (Bege). Cervinhos fofos em tons suaves para um ambiente acolhedor.",
      codes: ["YY205003R", "YY205002R", "YY205001R"],
    },
    // Imagem 15 - Escamas
    {
      id: 15,
      src: "/catalog-images/infantil-15.jpg",
      alt: "Papel de parede infantil - Escamas com Passarinhos",
      title: "Escamas com Passarinhos",
      color: "Pastel",
      description:
        "YY204103R (Rosa), YY204102R (Bege) e YY204101R (Azul). Padrão de escamas delicado com passarinhos para um toque especial.",
      codes: ["YY204103R", "YY204102R", "YY204101R"],
    },
    // Imagem 16 - Estrelas Pequenas
    {
      id: 16,
      src: "/catalog-images/infantil-16.jpg",
      alt: "Papel de parede infantil - Estrelas Pequenas",
      title: "Estrelas Pequenas",
      color: "Neutro",
      description:
        "YY205104R (Cinza), YY205103R (Dourado), YY205102R (Rosa) e YY205101R (Azul). Estrelas delicadas para um céu suave.",
      codes: ["YY205104R", "YY205103R", "YY205102R", "YY205101R"],
    },
    // Imagem 17 - Ursinhos
    {
      id: 17,
      src: "/catalog-images/infantil-17.jpg",
      alt: "Papel de parede infantil - Ursinhos nas Nuvens",
      title: "Ursinhos nas Nuvens",
      color: "Pastel",
      description:
        "YY204804R (Azul), YY204803R (Bege), YY204802R (Azul Claro) e YY204801R (Rosa). Ursinhos fofos descansando nas nuvens.",
      codes: ["YY204804R", "YY204803R", "YY204802R", "YY204801R"],
    },
    // Imagem 18 - Mapa
    {
      id: 18,
      src: "/catalog-images/infantil-18.jpg",
      alt: "Papel de parede infantil - Mapa-múndi",
      title: "Mapa-múndi Educativo",
      color: "Neutro",
      description:
        "YY203901R (Azul), YY203902R (Cinza) e YY203903R (Bege). Mapa-múndi com animais para aprender geografia brincando.",
      codes: ["YY203901R", "YY203902R", "YY203903R"],
    },
    // Imagem 19 - Jardim
    {
      id: 19,
      src: "/catalog-images/infantil-19.jpg",
      alt: "Papel de parede infantil - Jardim com Flores",
      title: "Jardim com Flores",
      color: "Natural",
      description:
        "YY205301R (Colorido) e YY205302R (Neutro). Jardim encantado com flores e passarinhos para um ambiente natural.",
      codes: ["YY205301R", "YY205302R"],
    },
    // Imagem 20 - Listras Pastéis
    {
      id: 20,
      src: "/catalog-images/infantil-20.jpg",
      alt: "Papel de parede infantil - Listras Pastéis",
      title: "Listras Pastéis",
      color: "Pastel",
      description:
        "YY205403R (Azul Pastel), YY205401R (Cinza Pastel) e YY205402R (Rosa Pastel). Listras suaves em tons pastéis para um visual delicado.",
      codes: ["YY205403R", "YY205401R", "YY205402R"],
    },
  ]

  const filteredImages = catalogImages.filter(
    (image) =>
      image.color.toLowerCase().includes(searchTerm.toLowerCase()) ||
      image.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      image.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      image.codes.some((code) => code.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const handleImageError = (index: number) => {
    setImageError((prev) => ({ ...prev, [index]: true }))
  }

  const handleImageClick = (image: { src: string; alt: string; title: string }) => {
    setSelectedImage(image)
  }

  const closeModal = () => {
    setSelectedImage(null)
  }

  const handleQuoteRequest = (productTitle: string, codes: string[]) => {
    const codesText = codes.join(", ")
    const message = `Olá! Gostaria de solicitar um orçamento para o papel de parede infantil: ${productTitle} (Códigos: ${codesText}). Poderia me enviar mais informações sobre preço, disponibilidade e prazo de entrega?`
    const whatsappUrl = `https://wa.me/5561986792057?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  // Cores disponíveis para filtros
  const availableColors = [...new Set(catalogImages.map((img) => img.color))].sort()

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-100">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-gray-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4">
              <Image src="/logo-art-house.png" alt="Art House Logo" width={160} height={80} className="h-16 w-auto" />
            </Link>
            <div className="flex items-center justify-center flex-1 md:justify-end md:flex-initial space-x-6">
              <a
                href="/#catalogos"
                className="hidden md:block text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg"
              >
                ← Voltar aos Catálogos
              </a>
              <a
                href="https://wa.me/5561986792057"
                target="_blank"
                className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105 text-lg"
                rel="noreferrer"
              >
                💬 WhatsApp
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-pink-400/10 to-purple-400/10"></div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-green-200 to-green-400 rounded-3xl mb-8 text-4xl">
              🧸
            </div>

            <h1 className="font-montserrat font-bold text-5xl md:text-6xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-6">
              Papéis Infantis
            </h1>

            <p className="text-gray-500 text-lg mb-8 max-w-3xl mx-auto">
              Transforme o quarto do seu filho em um mundo mágico com nossos papéis de parede especiais. Cada design foi
              pensado para estimular a imaginação e criar ambientes únicos.
            </p>

            <div className="w-24 h-1 bg-gradient-to-r from-green-200 to-green-400 mx-auto rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Botões Catálogo Infantil */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            {/* Lado Esquerdo - Busca e Filtros */}
            <div className="space-y-6">
              <div className="text-center lg:text-left">
                <h2 className="font-montserrat font-bold text-2xl text-[#1B5E3A] mb-4">Buscar e Filtrar</h2>
                <p className="text-gray-600 mb-6">Encontre o papel perfeito para o quarto do seu filho</p>
              </div>

              {/* Search and Filters */}
              <div className="space-y-6">
                {/* Search Input */}
                <div className="max-w-md mx-auto lg:mx-0">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Buscar por código, cor ou tema..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full px-4 py-3 pl-12 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                    />
                    <svg
                      className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                      />
                    </svg>
                  </div>
                </div>

                {/* Color Filters */}
                <div className="flex flex-wrap justify-center lg:justify-start gap-3">
                  <button
                    onClick={() => setSearchTerm("")}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                      searchTerm === ""
                        ? "bg-green-500 text-white shadow-lg"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    Todos ({catalogImages.length})
                  </button>
                  {availableColors.map((color) => {
                    const count = catalogImages.filter((img) => img.color === color).length
                    return (
                      <button
                        key={color}
                        onClick={() => setSearchTerm(color)}
                        className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                          searchTerm.toLowerCase() === color.toLowerCase()
                            ? "bg-green-500 text-white shadow-lg"
                            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                        }`}
                      >
                        {color} ({count})
                      </button>
                    )
                  })}
                </div>
              </div>
            </div>

            {/* Lado Direito - Catálogos de Personalizados */}
            <div className="space-y-6">
              <div className="text-center lg:text-left">
                <h2 className="font-montserrat font-bold text-2xl text-[#1B5E3A] mb-4">Catálogo de Personalizados</h2>
                <p className="text-gray-600 mb-6">Acesse nossos catálogos completos por categoria</p>
              </div>

              <div className="flex flex-col gap-4">
                <a
                  href="https://drive.google.com/drive/folders/1LLXVwXfIVU89DFJo8EOBSNKaizY-gOuF"
                  target="_blank"
                  rel="noreferrer"
                  className="group bg-gradient-to-r from-blue-200 to-blue-300 hover:from-blue-300 hover:to-blue-400 text-blue-800 px-6 py-4 rounded-2xl font-montserrat font-semibold text-lg transition-all duration-300 transform hover:scale-105 hover:-translate-y-1 shadow-lg hover:shadow-xl text-center"
                >
                  👦 Catálogo Infantil Masculino
                </a>
                <a
                  href="https://drive.google.com/drive/folders/10otA0JpZXplWt8gW3rvB1lNTvDj5aREs"
                  target="_blank"
                  rel="noreferrer"
                  className="group bg-gradient-to-r from-pink-200 to-pink-300 hover:from-pink-300 hover:to-pink-400 text-pink-800 px-6 py-4 rounded-2xl font-montserrat font-semibold text-lg transition-all duration-300 transform hover:scale-105 hover:-translate-y-1 shadow-lg hover:shadow-xl text-center"
                >
                  👧 Catálogo Infantil Feminino
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Catalog Grid */}
      <section className="py-8 md:py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-montserrat font-bold text-3xl text-[#1B5E3A] mb-4">Nossa Coleção Infantil</h2>
            <p className="text-gray-600 mb-8">
              Explore nossa seleção completa de papéis especiais para quartos infantis - {catalogImages.length} designs
              únicos
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
            {filteredImages.map((image, index) => (
              <div
                key={image.id}
                className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 overflow-hidden border border-green-100"
              >
                <div className="relative aspect-[3/2] overflow-hidden">
                  {!imageError[index] ? (
                    <Image
                      src={image.src || "/placeholder.svg"}
                      alt={image.alt}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-110 cursor-pointer"
                      onError={() => handleImageError(index)}
                      onClick={() => handleImageClick(image)}
                    />
                  ) : (
                    <div
                      className="w-full h-full bg-gradient-to-br from-green-100 to-green-200 flex items-center justify-center cursor-pointer"
                      onClick={() => handleImageClick(image)}
                    >
                      <div className="text-center">
                        <div className="text-4xl mb-2">🧸</div>
                        <p className="text-gray-500 text-sm">{image.title}</p>
                      </div>
                    </div>
                  )}

                  {/* Overlay com ícone de ampliar */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <div className="bg-white/90 p-3 rounded-full transform scale-75 group-hover:scale-100 transition-transform duration-300">
                      <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                        />
                      </svg>
                    </div>
                  </div>

                  {/* Badge com número de códigos */}
                  <div className="absolute top-3 right-3 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                    {image.codes.length} {image.codes.length === 1 ? "código" : "códigos"}
                  </div>
                </div>

                <div className="p-4 md:p-6">
                  <h3 className="font-semibold text-lg text-gray-800 mb-2 line-clamp-1">{image.title}</h3>
                  <p className="text-gray-600 mb-2 text-sm">Cores: {image.color}</p>
                  <p className="text-gray-500 text-sm mb-4 line-clamp-3">{image.description}</p>
                  <button
                    onClick={() => handleQuoteRequest(image.title, image.codes)}
                    className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-3 px-4 rounded-xl font-semibold hover:from-green-600 hover:to-green-700 transition-all duration-300 transform hover:scale-105 text-sm md:text-base"
                  >
                    💬 Pedir Orçamento
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredImages.length === 0 && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-500">Tente buscar por uma cor, tema ou código diferente</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-green-200/20 to-green-400/20">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="font-montserrat font-bold text-3xl text-[#1B5E3A] mb-6">Gostou de algum modelo?</h2>
            <p className="text-gray-600 text-lg mb-8">
              Entre em contato conosco para solicitar orçamento, tirar dúvidas ou conhecer mais opções disponíveis.
            </p>
            <a
              href="https://wa.me/5561986792057"
              target="_blank"
              className="group inline-flex items-center gap-3 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-10 py-4 rounded-2xl font-montserrat font-semibold text-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 relative overflow-hidden"
              rel="noreferrer"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
              <span className="relative">💬 Falar no WhatsApp</span>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 to-black text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#1B5E3A]/10 to-transparent"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div className="animate-fade-in-up">
              <div className="flex items-center mb-6">
                <Image
                  src="/logo-art-house.png"
                  alt="Art House Logo"
                  width={150}
                  height={75}
                  className="h-16 w-auto filter brightness-0 invert"
                />
              </div>
              <h3 className="font-montserrat font-bold text-2xl text-white mb-4">
                Art House | 25 anos transformando ambientes em Brasília.
              </h3>
              <p className="text-gray-300 text-lg leading-relaxed">
                Especialistas em papel de parede com a qualidade e confiança que você merece.
              </p>
            </div>

            <div className="animate-fade-in-up animation-delay-200">
              <h4 className="font-montserrat font-bold text-xl text-white mb-6">Horário de Funcionamento</h4>
              <div className="space-y-3">
                <p className="text-gray-300 text-lg">Segunda a Sexta: 9h às 18h</p>
                <p className="text-gray-300 text-lg">Sábado: 9h às 14h</p>
                <p className="text-gray-300 text-lg">Domingo: Fechado</p>
              </div>
            </div>

            <div className="animate-fade-in-up animation-delay-400">
              <h4 className="font-montserrat font-bold text-xl text-white mb-6">Contato</h4>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📍
                  </div>
                  <p className="text-gray-300 text-lg">CLS 311, Bloco C, Loja 29, Asa Sul, Brasília - DF</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📱
                  </div>
                  <a
                    href="https://wa.me/5561986792057"
                    target="_blank"
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                    rel="noreferrer"
                  >
                    (61) 9 8679-2057
                  </a>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📷
                  </div>
                  <a
                    href="https://instagram.com/arthousepapel"
                    target="_blank"
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                    rel="noreferrer"
                  >
                    @arthousepapel
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-400 text-lg">
              &copy; 2024 Art House. Todos os direitos reservados. | Desenvolvido com ❤️ para transformar ambientes.
            </p>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/5561986792057"
        target="_blank"
        className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-green-500 to-green-600 text-white p-5 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 animate-pulse-slow group"
        rel="noreferrer"
      >
        <svg
          className="w-8 h-8 group-hover:scale-110 transition-transform duration-300"
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488" />
        </svg>
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-xs font-bold animate-bounce">
          !
        </div>
      </a>

      {/* Image Modal */}
      <ImageModal
        isOpen={!!selectedImage}
        onClose={closeModal}
        imageSrc={selectedImage?.src || ""}
        imageAlt={selectedImage?.alt || ""}
        imageTitle={selectedImage?.title || ""}
      />
    </div>
  )
}
