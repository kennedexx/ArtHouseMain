import Image from "next/image"
import Link from "next/link"

export default function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 to-black text-white py-16 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-[#1B5E3A]/10 to-transparent"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div className="animate-fade-in-up">
            <div className="flex items-center mb-6">
              <Image
                src="/logo-art-house.png"
                alt="Art House Logo"
                width={150}
                height={75}
                className="h-16 w-auto filter brightness-0 invert"
              />
            </div>
            <h3 className="font-montserrat font-bold text-2xl text-white mb-4">
              Art House | 25 anos transformando ambientes em Brasília.
            </h3>
            <p className="text-gray-300 text-lg leading-relaxed">
              Especialistas em papel de parede com a qualidade e confiança que você merece.
            </p>
          </div>

          <div className="animate-fade-in-up animation-delay-200">
            <h4 className="font-montserrat font-bold text-xl text-white mb-6">Links Rápidos</h4>
            <div className="space-y-3">
              <Link href="/" className="block text-gray-300 hover:text-white transition-colors text-lg">
                Home
              </Link>
              <a href="/#produtos" className="block text-gray-300 hover:text-white transition-colors text-lg">
                Produtos
              </a>
              <a href="/#catalogos" className="block text-gray-300 hover:text-white transition-colors text-lg">
                Catálogos
              </a>
              <a href="/#vantagens" className="block text-gray-300 hover:text-white transition-colors text-lg">
                Vantagens
              </a>
              <Link href="/sobre" className="block text-gray-300 hover:text-white transition-colors text-lg">
                Sobre
              </Link>
              <Link href="/contato" className="block text-gray-300 hover:text-white transition-colors text-lg">
                Contato
              </Link>
            </div>
          </div>

          <div className="animate-fade-in-up animation-delay-400">
            <h4 className="font-montserrat font-bold text-xl text-white mb-6">Contato</h4>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                  📍
                </div>
                <p className="text-gray-300 text-lg">CLS 311, Bloco C, Loja 29, Asa Sul, Brasília - DF</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                  📧
                </div>
                <a
                  href="mailto:contato@arthousepapeldeparede.com.br"
                  className="text-gray-300 hover:text-white transition-colors text-lg"
                >
                  contato@arthousepapeldeparede.com.br
                </a>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                  📱
                </div>
                <a
                  href="https://wa.me/5561986792057"
                  target="_blank"
                  className="text-gray-300 hover:text-white transition-colors text-lg"
                  rel="noreferrer"
                >
                  (61) 9 8679-2057
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center">
          <p className="text-gray-400 text-lg">
            &copy; 2024 Art House. Todos os direitos reservados. | Desenvolvido com ❤️ para transformar ambientes.
          </p>
        </div>
      </div>
    </footer>
  )
}
