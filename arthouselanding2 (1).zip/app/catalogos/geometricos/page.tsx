"use client"
import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"

export default function CatalogoGeometricos() {
  const [selectedColor, setSelectedColor] = useState("Todas as Cores")
  const [selectedCategory, setSelectedCategory] = useState("Todas as Categorias")
  const [imageError, setImageError] = useState<{ [key: number]: boolean }>({})

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const produtos = [
    // Série VR980 - Geométricos Clássicos
    {
      id: 1,
      nome: "Geométrico Texturizado com Destaque",
      codigo: "VR980207S",
      cor: "Bege",
      textura: "Texturizada",
      categoria: "Clássico",
      imagem: "/catalog-images/geometricos-1.jpg",
      descricao: "Textura sutil com destaque circular, perfeita para ambientes sofisticados.",
      modelos: [
        { codigo: "VR980207S", descricao: "Textura com Círculo", cor: "Bege Dourado" },
        { codigo: "VR980702T", descricao: "Folhagem Delicada", cor: "Creme" },
        { codigo: "VR980805R", descricao: "Liso Complementar", cor: "Creme Claro" },
      ],
    },
    {
      id: 2,
      nome: "Losango Diagonal Moderno",
      codigo: "MT300703R",
      cor: "Bege",
      textura: "Losango",
      categoria: "Moderno",
      imagem: "/catalog-images/geometricos-2.jpg",
      descricao: "Padrão diagonal em losangos, criando movimento e elegância.",
      modelos: [
        { codigo: "MT300703R", descricao: "Losango Diagonal", cor: "Bege" },
        { codigo: "MT300504R", descricao: "Textura Sutil", cor: "Bege Claro" },
        { codigo: "MT300503R", descricao: "Liso Harmonioso", cor: "Bege Suave" },
      ],
    },
    {
      id: 3,
      nome: "Coleção Geométrica Diversa",
      codigo: "VR980103R",
      cor: "Cinza",
      textura: "Mista",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/geometricos-3.jpg",
      descricao: "Combinação de padrões geométricos: diamantes, chevron e tribal.",
      modelos: [
        { codigo: "VR980103R", descricao: "Diamante Clássico", cor: "Cinza Claro" },
        { codigo: "VR980006R", descricao: "Chevron Moderno", cor: "Bege" },
        { codigo: "VR980205S", descricao: "Liso com Destaque", cor: "Cinza" },
        { codigo: "VR990402H", descricao: "Tribal Sofisticado", cor: "Cinza Escuro" },
      ],
    },
    {
      id: 4,
      nome: "Listras Diagonais Elegantes",
      codigo: "MT301601R",
      cor: "Bege",
      textura: "Listrada",
      categoria: "Minimalista",
      imagem: "/catalog-images/geometricos-4.jpg",
      descricao: "Listras diagonais sutis para ambientes minimalistas e elegantes.",
      modelos: [
        { codigo: "MT301601R", descricao: "Diagonal Texturizada", cor: "Bege" },
        { codigo: "MT301401R", descricao: "Lisa Complementar", cor: "Bege Claro" },
      ],
    },
    {
      id: 5,
      nome: "Série Diamante Premium PT4015",
      codigo: "PT401501R",
      cor: "Cinza",
      textura: "Diamante",
      categoria: "Premium",
      imagem: "/catalog-images/geometricos-5.jpg",
      descricao: "Coleção premium com padrões diamante em gradação de intensidade.",
      modelos: [
        { codigo: "PT401501R", descricao: "Diamante Sutil", cor: "Cinza Claro" },
        { codigo: "PT401502R", descricao: "Diamante Médio", cor: "Cinza" },
        { codigo: "PT401503R", descricao: "Diamante Intenso", cor: "Cinza Médio" },
        { codigo: "PT401504R", descricao: "Diamante Marcado", cor: "Cinza Escuro" },
      ],
    },
    {
      id: 6,
      nome: "Hexágono 3D e Mármore",
      codigo: "MT300802R",
      cor: "Bege",
      textura: "Hexagonal",
      categoria: "3D",
      imagem: "/catalog-images/geometricos-6.jpg",
      descricao: "Padrão hexagonal tridimensional combinado com textura mármore.",
      modelos: [
        { codigo: "MT300802R", descricao: "Hexágono 3D", cor: "Bege" },
        { codigo: "MT301703R", descricao: "Mármore Swirl", cor: "Bege Mármore" },
      ],
    },
    {
      id: 7,
      nome: "Coleção Geométrica NN59",
      codigo: "NN590102R",
      cor: "Azul",
      textura: "Mista",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/geometricos-7.jpg",
      descricao: "Série contemporânea com mármore, hexágonos e chevron em tons azulados.",
      modelos: [
        { codigo: "NN590102R", descricao: "Mármore Geométrico", cor: "Cinza Azulado" },
        { codigo: "NN590703R", descricao: "Liso Azul", cor: "Azul Acinzentado" },
        { codigo: "NN590303R", descricao: "Hexágono Moderno", cor: "Cinza" },
        { codigo: "NN590901R", descricao: "Chevron Elegante", cor: "Bege" },
      ],
    },
    {
      id: 8,
      nome: "Mix Geométrico MT300",
      codigo: "MT300803R",
      cor: "Bege",
      textura: "Variada",
      categoria: "Versátil",
      imagem: "/catalog-images/geometricos-8.jpg",
      descricao: "Combinação versátil de linhas verticais, mármore e losangos.",
      modelos: [
        { codigo: "MT300803R", descricao: "Linhas Verticais", cor: "Bege" },
        { codigo: "MT301705R", descricao: "Mármore Fluido", cor: "Bege Mármore" },
        { codigo: "MT300802R", descricao: "Liso Base", cor: "Bege Claro" },
        { codigo: "MT300704R", descricao: "Losango Clássico", cor: "Bege Dourado" },
      ],
    },
    {
      id: 9,
      nome: "Série Madeira Geométrica PT4005",
      codigo: "PT400501R",
      cor: "Madeira",
      textura: "Vertical",
      categoria: "Natural",
      imagem: "/catalog-images/geometricos-9.jpg",
      descricao: "Padrões verticais inspirados em madeira, do claro ao escuro.",
      modelos: [
        { codigo: "PT400501R", descricao: "Madeira Clara", cor: "Bege Claro" },
        { codigo: "PT400502R", descricao: "Madeira Natural", cor: "Bege" },
        { codigo: "PT400503R", descricao: "Madeira Média", cor: "Marrom Claro" },
        { codigo: "PT400504R", descricao: "Madeira Escura", cor: "Marrom" },
      ],
    },
    {
      id: 10,
      nome: "Série Crosshatch PT4001",
      codigo: "PT400104R",
      cor: "Bege",
      textura: "Crosshatch",
      categoria: "Artístico",
      imagem: "/catalog-images/geometricos-10.jpg",
      descricao: "Padrões entrecruzados em gradação de intensidade artística.",
      modelos: [
        { codigo: "PT400104R", descricao: "Crosshatch Intenso", cor: "Bege Escuro" },
        { codigo: "PT400103R", descricao: "Crosshatch Médio", cor: "Bege" },
        { codigo: "PT400102R", descricao: "Crosshatch Suave", cor: "Bege Claro" },
        { codigo: "PT400101R", descricao: "Crosshatch Sutil", cor: "Creme" },
      ],
    },
    // Produtos originais mantidos
    {
      id: 11,
      nome: "Geométrico Hexagonal Moderno",
      codigo: "GE301101R",
      cor: "Cinza",
      textura: "Hexagonal",
      categoria: "Moderno",
      imagem: "/catalog-images/1-dash-2-geometrico.jpg",
      descricao: "Design hexagonal moderno em tons de cinza, perfeito para ambientes contemporâneos.",
      modelos: [
        { codigo: "GE001", descricao: "Hexágono Pequeno", cor: "Cinza Claro" },
        { codigo: "GE002", descricao: "Hexágono Grande", cor: "Cinza Escuro" },
      ],
    },
    {
      id: 12,
      nome: "Geométrico Ambiente Dourado",
      codigo: "GE301102R",
      cor: "Dourado",
      textura: "Losango",
      categoria: "Luxo",
      imagem: "/catalog-images/9-1-2-geometrico.jpg",
      descricao: "Papel de parede luxuoso com design em losangos dourados, para ambientes sofisticados.",
      modelos: [
        { codigo: "GE003", descricao: "Losango Clássico", cor: "Dourado Brilhante" },
        { codigo: "GE004", descricao: "Losango Vintage", cor: "Dourado Envelhecido" },
      ],
    },
    // Continuando com os produtos originais...
    {
      id: 13,
      nome: "Geométrico Triangular",
      codigo: "GE301103R",
      cor: "Azul",
      textura: "Triangular",
      categoria: "Contemporâneo",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Triangular",
      descricao: "Padrão triangular contemporâneo em azul, criando movimento visual.",
      modelos: [
        { codigo: "GE005", descricao: "Triângulos Pequenos", cor: "Azul Claro" },
        { codigo: "GE006", descricao: "Triângulos Grandes", cor: "Azul Escuro" },
      ],
    },
    {
      id: 14,
      nome: "Geométrico Circular",
      codigo: "GE301104R",
      cor: "Verde",
      textura: "Circular",
      categoria: "Moderno",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Circular",
      descricao: "Design com círculos concêntricos em tons de verde, trazendo harmonia ao ambiente.",
      modelos: [
        { codigo: "GE007", descricao: "Círculos Pequenos", cor: "Verde Esmeralda" },
        { codigo: "GE008", descricao: "Círculos Grandes", cor: "Verde Oliva" },
      ],
    },
    {
      id: 15,
      nome: "Geométrico Ondulado",
      codigo: "GE301105R",
      cor: "Rosa",
      textura: "Ondulada",
      categoria: "Feminino",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Ondulado",
      descricao: "Suaves ondas geométricas em tons de rosa, perfeito para ambientes femininos.",
      modelos: [
        { codigo: "GE009", descricao: "Ondas Suaves", cor: "Rosa Claro" },
        { codigo: "GE010", descricao: "Ondas Marcadas", cor: "Rosa Escuro" },
      ],
    },
    {
      id: 16,
      nome: "Geométrico Xadrez",
      codigo: "GE301106R",
      cor: "Preto",
      textura: "Xadrez",
      categoria: "Clássico",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Xadrez",
      descricao: "Padrão xadrez clássico em preto e branco, atemporal e elegante.",
      modelos: [
        { codigo: "GE011", descricao: "Xadrez Pequeno", cor: "Preto e Branco" },
        { codigo: "GE012", descricao: "Xadrez Grande", cor: "Cinza e Branco" },
      ],
    },
    {
      id: 17,
      nome: "Geométrico Espiral",
      codigo: "GE301107R",
      cor: "Prata",
      textura: "Espiral",
      categoria: "Contemporâneo",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Espiral",
      descricao: "Design em espiral prateado, criando movimento e sofisticação.",
      modelos: [
        { codigo: "GE013", descricao: "Espiral Fina", cor: "Prata Aço" },
        { codigo: "GE014", descricao: "Espiral Larga", cor: "Prata Polido" },
      ],
    },
    {
      id: 18,
      nome: "Geométrico Mosaico",
      codigo: "GE301108R",
      cor: "Multicolor",
      textura: "Mosaico",
      categoria: "Artístico",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Mosaico",
      descricao: "Design em mosaico multicolorido, perfeito para criar pontos focais únicos.",
      modelos: [
        { codigo: "GE015", descricao: "Mosaico Vibrante", cor: "Multicolor Vibrante" },
        { codigo: "GE016", descricao: "Mosaico Suave", cor: "Multicolor Suave" },
      ],
    },
    {
      id: 19,
      nome: "Geométrico Linear",
      codigo: "GE301109R",
      cor: "Bege",
      textura: "Linear",
      categoria: "Minimalista",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Linear",
      descricao: "Linhas geométricas em tons neutros, ideal para ambientes minimalistas.",
      modelos: [
        { codigo: "GE017", descricao: "Linhas Horizontais", cor: "Bege Claro" },
        { codigo: "GE018", descricao: "Linhas Verticais", cor: "Bege Escuro" },
      ],
    },
    {
      id: 20,
      nome: "Geométrico Abstrato",
      codigo: "GE301110R",
      cor: "Branco",
      textura: "Abstrata",
      categoria: "Moderno",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Abstrato",
      descricao: "Formas geométricas abstratas em tons de branco, para ambientes modernos.",
      modelos: [
        { codigo: "GE019", descricao: "Abstrato Sutil", cor: "Branco Gelo" },
        { codigo: "GE020", descricao: "Abstrato Marcado", cor: "Branco Puro" },
      ],
    },
    {
      id: 21,
      nome: "Geométrico Quadriculado",
      codigo: "GE301111R",
      cor: "Creme",
      textura: "Quadriculada",
      categoria: "Clássico",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Quadriculado",
      descricao: "Padrão quadriculado clássico em tons de creme, versátil e elegante.",
      modelos: [
        { codigo: "GE021", descricao: "Quadrados Pequenos", cor: "Creme Claro" },
        { codigo: "GE022", descricao: "Quadrados Grandes", cor: "Creme Escuro" },
      ],
    },
    {
      id: 22,
      nome: "Geométrico Listrado",
      codigo: "GE301112R",
      cor: "Cinza",
      textura: "Listrada",
      categoria: "Moderno",
      imagem: "/placeholder.svg?height=300&width=450&text=Geometrico+Listrado",
      descricao: "Listras geométricas modernas em cinza, criando altura visual.",
      modelos: [
        { codigo: "GE023", descricao: "Listras Finas", cor: "Cinza Claro" },
        { codigo: "GE024", descricao: "Listras Largas", cor: "Cinza Escuro" },
      ],
    },
    // Novas coleções premium adicionadas
    {
      id: 23,
      nome: "Chevron Elegante com Ambiente",
      codigo: "VR980009R",
      cor: "Bege",
      textura: "Chevron",
      categoria: "Premium",
      imagem: "/catalog-images/geometricos-11.jpg",
      descricao: "Padrão chevron sofisticado em tons neutros, perfeito para ambientes modernos.",
      modelos: [{ codigo: "VR980009R", descricao: "Chevron Premium", cor: "Bege Claro" }],
    },
    {
      id: 24,
      nome: "Coleção Ornamental VR9813/VR9819",
      codigo: "VR981302T",
      cor: "Dourado",
      textura: "Ornamental",
      categoria: "Luxo",
      imagem: "/catalog-images/geometricos-12.jpg",
      descricao: "Combinação luxuosa de ornamentais dourados com texturas complementares.",
      modelos: [
        { codigo: "VR981302T", descricao: "Damasco Dourado", cor: "Dourado" },
        { codigo: "VR981402R", descricao: "Base Neutra", cor: "Bege" },
        { codigo: "VR981802R", descricao: "Textura Cinza", cor: "Cinza" },
        { codigo: "VR981903T", descricao: "Quatrefoil Geométrico", cor: "Bege Dourado" },
      ],
    },
    {
      id: 25,
      nome: "Série Grid Moderna AD2011",
      codigo: "AD201101R",
      cor: "Azul",
      textura: "Grid",
      categoria: "Moderno",
      imagem: "/catalog-images/geometricos-13.jpg",
      descricao: "Padrões grid modernos em tons neutros e azul, com aplicação em quarto.",
      modelos: [
        { codigo: "AD201101R", descricao: "Grid Neutro Claro", cor: "Bege Claro" },
        { codigo: "AD201102R", descricao: "Grid Neutro", cor: "Bege" },
        { codigo: "AD201103R", descricao: "Grid Neutro Escuro", cor: "Bege Escuro" },
        { codigo: "AD201104R", descricao: "Grid Azul", cor: "Azul" },
      ],
    },
    {
      id: 26,
      nome: "Diamante e Listras MT301",
      codigo: "MT301604R",
      cor: "Bege",
      textura: "Diamante",
      categoria: "Clássico",
      imagem: "/catalog-images/geometricos-14.jpg",
      descricao: "Padrão diamante elegante combinado com listras verticais sutis.",
      modelos: [
        { codigo: "MT301604R", descricao: "Diamante Lattice", cor: "Bege" },
        { codigo: "MT301407R", descricao: "Listras Verticais", cor: "Bege Claro" },
      ],
    },
    {
      id: 27,
      nome: "Mandala Geométrica VR9802",
      codigo: "VR980203S",
      cor: "Cinza",
      textura: "Mandala",
      categoria: "Artístico",
      imagem: "/catalog-images/geometricos-15.jpg",
      descricao: "Padrão mandala geométrico em duas intensidades, do escuro ao claro.",
      modelos: [
        { codigo: "VR980203S", descricao: "Mandala Escura", cor: "Cinza Escuro" },
        { codigo: "VR980202S", descricao: "Mandala Clara", cor: "Bege Claro" },
      ],
    },
    {
      id: 28,
      nome: "Série Diamante Colorida PT40111",
      codigo: "PT401101R",
      cor: "Multicolor",
      textura: "Diamante",
      categoria: "Premium",
      imagem: "/catalog-images/geometricos-16.jpg",
      descricao: "Coleção premium com diamantes em gradação e toques de azul e marrom.",
      modelos: [
        { codigo: "PT401101R", descricao: "Diamante Sutil", cor: "Bege Claro" },
        { codigo: "PT401102R", descricao: "Diamante Médio", cor: "Cinza" },
        { codigo: "PT401103R", descricao: "Diamante Base", cor: "Bege" },
        { codigo: "PT401104R", descricao: "Diamante Azul", cor: "Azul Acinzentado" },
        { codigo: "PT401105R", descricao: "Diamante Marrom", cor: "Marrom Claro" },
      ],
    },
    {
      id: 29,
      nome: "Mix Ornamental e Chain VR9813/VR9817",
      codigo: "VR981303T",
      cor: "Marrom",
      textura: "Mista",
      categoria: "Luxo",
      imagem: "/catalog-images/geometricos-17.jpg",
      descricao: "Combinação sofisticada de ornamentais dourados com padrão chain moderno.",
      modelos: [
        { codigo: "VR981303T", descricao: "Damasco Dourado", cor: "Dourado" },
        { codigo: "VR981403R", descricao: "Base Cinza", cor: "Cinza" },
        { codigo: "VR981806R", descricao: "Textura Marrom", cor: "Marrom" },
        { codigo: "VR981704R", descricao: "Chain Geométrico", cor: "Marrom Dourado" },
      ],
    },
    {
      id: 30,
      nome: "Coleção Diversa NN590 com Ambiente",
      codigo: "NN590305R",
      cor: "Azul",
      textura: "Variada",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/geometricos-18.jpg",
      descricao: "Série contemporânea com hexágonos, chevron e texturas, aplicada em sala moderna.",
      modelos: [
        { codigo: "NN590305R", descricao: "Hexágono Moderno", cor: "Cinza" },
        { codigo: "NN590501R", descricao: "Textura Azul Desgastada", cor: "Azul Desgastado" },
        { codigo: "NN590603R", descricao: "Grid Azul Claro", cor: "Azul Claro" },
        { codigo: "NN590902R", descricao: "Chevron Elegante", cor: "Cinza" },
        { codigo: "NN590604R", descricao: "Linhas Verticais", cor: "Bege" },
      ],
    },
    {
      id: 31,
      nome: "Série Chevron VR9821/VR9820",
      codigo: "VR982101T",
      cor: "Dourado",
      textura: "Chevron",
      categoria: "Elegante",
      imagem: "/catalog-images/geometricos-19.jpg",
      descricao: "Padrões chevron em tons dourados e neutros com texturas verticais.",
      modelos: [
        { codigo: "VR982101T", descricao: "Chevron Bege", cor: "Bege" },
        { codigo: "VR982001T", descricao: "Vertical Dourado", cor: "Creme Dourado" },
        { codigo: "VR981805R", descricao: "Base Cinza", cor: "Cinza" },
        { codigo: "VR982102T", descricao: "Chevron Creme", cor: "Creme" },
      ],
    },
    {
      id: 32,
      nome: "Coleção Geométrica Diversa WS1015",
      codigo: "WS101603R",
      cor: "Cinza",
      textura: "Variada",
      categoria: "Versátil",
      imagem: "/catalog-images/geometricos-20.jpg",
      descricao: "Série versátil com texturas pontilhadas, diagonais, grids e padrões angulares.",
      modelos: [
        { codigo: "WS101603R", descricao: "Textura Pontilhada", cor: "Cinza Claro" },
        { codigo: "WS101602R", descricao: "Textura Salpicada", cor: "Cinza" },
        { codigo: "WS101601R", descricao: "Diagonal Sutil", cor: "Bege" },
        { codigo: "WS101504R", descricao: "Grid Moderno", cor: "Cinza Médio" },
        { codigo: "WS101505R", descricao: "Linhas Diagonais", cor: "Cinza" },
        { codigo: "WS101501R", descricao: "Angular Branco", cor: "Branco" },
        { codigo: "WS101502R", descricao: "Angular Bege", cor: "Bege" },
      ],
    },
    // Novas coleções ultra premium adicionadas
    {
      id: 33,
      nome: "Chevron Clássico VR9800",
      codigo: "VR980007R",
      cor: "Bege",
      textura: "Chevron",
      categoria: "Clássico",
      imagem: "/catalog-images/geometricos-21.jpg",
      descricao: "Padrão chevron clássico em tons neutros com textura complementar lisa.",
      modelos: [
        { codigo: "VR980007R", descricao: "Chevron Clássico", cor: "Bege" },
        { codigo: "VR980501R", descricao: "Textura Lisa", cor: "Bege Claro" },
      ],
    },
    {
      id: 34,
      nome: "Art Deco Radiante NN590",
      codigo: "NN590204R",
      cor: "Verde",
      textura: "Art Deco",
      categoria: "Art Deco",
      imagem: "/catalog-images/geometricos-22.jpg",
      descricao: "Padrões Art Deco radiantes em tons de cinza e verde menta, aplicados em ambiente moderno.",
      modelos: [
        { codigo: "NN590204R", descricao: "Radiante Cinza", cor: "Cinza" },
        { codigo: "NN590202R", descricao: "Radiante Escuro", cor: "Cinza Escuro" },
        { codigo: "NN590203R", descricao: "Radiante Verde", cor: "Verde Menta" },
      ],
    },
    {
      id: 35,
      nome: "Hexágono Moderno MT301",
      codigo: "MT301301R",
      cor: "Cinza",
      textura: "Hexagonal",
      categoria: "Moderno",
      imagem: "/catalog-images/geometricos-23.jpg",
      descricao: "Padrões hexagonais modernos com aplicação em sala contemporânea sofisticada.",
      modelos: [
        { codigo: "MT301301R", descricao: "Losango Lattice", cor: "Cinza" },
        { codigo: "MT301203R", descricao: "Hexágono Honeycomb", cor: "Bege" },
      ],
    },
    {
      id: 36,
      nome: "Curvas Orgânicas GR4002",
      codigo: "GR400201R",
      cor: "Cinza",
      textura: "Curvas",
      categoria: "Orgânico",
      imagem: "/catalog-images/geometricos-24.jpg",
      descricao: "Padrões de curvas orgânicas fluidas, aplicados em quarto moderno elegante.",
      modelos: [
        { codigo: "GR400201R", descricao: "Curvas Suaves", cor: "Bege" },
        { codigo: "GR400204R", descricao: "Curvas Intensas", cor: "Cinza Escuro" },
        { codigo: "GR400203R", descricao: "Curvas Médias", cor: "Cinza" },
      ],
    },
    {
      id: 37,
      nome: "Losango Verde Sofisticado",
      codigo: "MT300705R",
      cor: "Verde",
      textura: "Losango",
      categoria: "Sofisticado",
      imagem: "/catalog-images/geometricos-25.jpg",
      descricao: "Padrão losango em verde sage, aplicado em ambiente sofisticado com móveis azul marinho.",
      modelos: [{ codigo: "MT300705R", descricao: "Losango Verde Sage", cor: "Verde Sage" }],
    },
    {
      id: 38,
      nome: "Mix Elegante VR9817/VR9813",
      codigo: "VR981705R",
      cor: "Dourado",
      textura: "Mista",
      categoria: "Elegante",
      imagem: "/catalog-images/geometricos-26.jpg",
      descricao: "Combinação elegante de losangos, texturas e ornamentais dourados.",
      modelos: [
        { codigo: "VR981705R", descricao: "Losango Elegante", cor: "Cinza" },
        { codigo: "VR981405R", descricao: "Base Neutra", cor: "Bege" },
        { codigo: "VR981804R", descricao: "Textura Cinza", cor: "Cinza" },
        { codigo: "VR981305T", descricao: "Ornamental Dourado", cor: "Dourado" },
      ],
    },
    {
      id: 39,
      nome: "Triângulos Coloridos GR4000",
      codigo: "GR400001R",
      cor: "Multicolor",
      textura: "Triangular",
      categoria: "Colorido",
      imagem: "/catalog-images/geometricos-27.jpg",
      descricao: "Grandes triângulos geométricos em cores vibrantes, aplicados em ambiente moderno.",
      modelos: [
        { codigo: "GR400001R", descricao: "Triângulos Amarelos", cor: "Amarelo" },
        { codigo: "GR400003R", descricao: "Triângulos Cinza", cor: "Cinza" },
        { codigo: "GR400002R", descricao: "Triângulos Azuis", cor: "Azul" },
      ],
    },
    {
      id: 40,
      nome: "Coleção Diversa VR9819/VR9820",
      codigo: "VR981905T",
      cor: "Cinza",
      textura: "Variada",
      categoria: "Versátil",
      imagem: "/catalog-images/geometricos-28.jpg",
      descricao: "Coleção versátil com padrões geométricos, linhas e texturas em ambiente moderno.",
      modelos: [
        { codigo: "VR981905T", descricao: "Geométrico Sutil", cor: "Bege" },
        { codigo: "VR982003T", descricao: "Linhas Verticais", cor: "Cinza" },
        { codigo: "VR981703R", descricao: "Losango Chain", cor: "Cinza Escuro" },
        { codigo: "VR981104R", descricao: "Textura Base", cor: "Cinza Claro" },
      ],
    },
    {
      id: 41,
      nome: "Hexágonos Modernos WS100",
      codigo: "WS100004R",
      cor: "Azul",
      textura: "Hexagonal",
      categoria: "Ultra Moderno",
      imagem: "/catalog-images/geometricos-29.jpg",
      descricao: "Padrões hexagonais ultra modernos em tons de cinza e azul, aplicados em quarto contemporâneo.",
      modelos: [
        { codigo: "WS100004R", descricao: "Linhas Geométricas", cor: "Branco" },
        { codigo: "WS100001R", descricao: "Hexágono Cinza", cor: "Cinza" },
        { codigo: "WS100002R", descricao: "Hexágono Neutro", cor: "Bege" },
        { codigo: "WS100003R", descricao: "Hexágono Azul", cor: "Azul" },
      ],
    },
    {
      id: 42,
      nome: "Ondas Fluidas MT301504R",
      codigo: "MT301504R",
      cor: "Cinza",
      textura: "Ondulada",
      categoria: "Fluido",
      imagem: "/catalog-images/geometricos-30.jpg",
      descricao: "Padrão de ondas fluidas modernas, aplicado em sala de estar contemporânea.",
      modelos: [{ codigo: "MT301504R", descricao: "Ondas Fluidas", cor: "Cinza Claro" }],
    },
    // Novas coleções ultra premium 3D e sofisticadas
    {
      id: 43,
      nome: "Pirâmides 3D Modernas MT300301R",
      codigo: "MT300301R",
      cor: "Cinza",
      textura: "3D Pirâmide",
      categoria: "3D Premium",
      imagem: "/catalog-images/geometricos-31.jpg",
      descricao: "Padrão 3D de pirâmides triangulares, aplicado em sala moderna com parede de TV.",
      modelos: [{ codigo: "MT300301R", descricao: "Pirâmides 3D", cor: "Cinza Neutro" }],
    },
    {
      id: 44,
      nome: "Losango Lattice Contemporâneo",
      codigo: "MT301603R",
      cor: "Bege",
      textura: "Losango Lattice",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/geometricos-32.jpg",
      descricao: "Padrão losango lattice em tons neutros, aplicado em sala contemporânea elegante.",
      modelos: [{ codigo: "MT301603R", descricao: "Losango Lattice", cor: "Bege Claro" }],
    },
    {
      id: 45,
      nome: "Chevron Texturizado Escuro",
      codigo: "NN590304R",
      cor: "Preto",
      textura: "Chevron Texturizado",
      categoria: "Sofisticado",
      imagem: "/catalog-images/geometricos-33.jpg",
      descricao: "Chevron texturizado em tons escuros, aplicado em escritório moderno com cadeira amarela.",
      modelos: [{ codigo: "NN590304R", descricao: "Chevron Escuro", cor: "Preto Texturizado" }],
    },
    {
      id: 46,
      nome: "Série Folhagem Geométrica PT4008",
      codigo: "PT400801R",
      cor: "Bege",
      textura: "Folhagem",
      categoria: "Orgânico Geométrico",
      imagem: "/catalog-images/geometricos-34.jpg",
      descricao: "Padrões de folhagem geométrica em 4 intensidades, do sutil ao marcante.",
      modelos: [
        { codigo: "PT400801R", descricao: "Folhagem Sutil", cor: "Bege Claro" },
        { codigo: "PT400802R", descricao: "Folhagem Dourada", cor: "Dourado Suave" },
        { codigo: "PT400803R", descricao: "Folhagem Cinza", cor: "Cinza" },
        { codigo: "PT400804R", descricao: "Folhagem Marcada", cor: "Bege Escuro" },
      ],
    },
    {
      id: 47,
      nome: "Série Chevron Minimalista EL5002",
      codigo: "EL500207R",
      cor: "Cinza",
      textura: "Chevron Minimalista",
      categoria: "Minimalista Premium",
      imagem: "/catalog-images/geometricos-35.jpg",
      descricao: "Chevron minimalista com texturas complementares, aplicado em ambiente clean.",
      modelos: [
        { codigo: "EL500207R", descricao: "Chevron Escuro", cor: "Preto" },
        { codigo: "EL500201R", descricao: "Chevron Médio", cor: "Cinza" },
        { codigo: "EL500202R", descricao: "Chevron Claro", cor: "Bege" },
        { codigo: "EL500203R", descricao: "Textura Lisa", cor: "Cinza Claro" },
      ],
    },
    {
      id: 48,
      nome: "Quatrefoil Luxuoso VR9811/VR9817",
      codigo: "VR981102R",
      cor: "Dourado",
      textura: "Quatrefoil",
      categoria: "Luxo Premium",
      imagem: "/catalog-images/geometricos-36.jpg",
      descricao: "Padrão quatrefoil luxuoso com mármores complementares, aplicado em ambiente sofisticado.",
      modelos: [
        { codigo: "VR981102R", descricao: "Quatrefoil Dourado", cor: "Dourado" },
        { codigo: "VR981202R", descricao: "Mármore Claro", cor: "Bege Mármore" },
        { codigo: "VR981702R", descricao: "Quatrefoil Bege", cor: "Bege Dourado" },
      ],
    },
    {
      id: 49,
      nome: "Hexágonos Modernos NN590/NN591",
      codigo: "NN590301R",
      cor: "Cinza",
      textura: "Hexagonal Moderno",
      categoria: "Ultra Moderno",
      imagem: "/catalog-images/geometricos-37.jpg",
      descricao: "Hexágonos modernos com texturas variadas, aplicados em workspace contemporâneo.",
      modelos: [
        { codigo: "NN590301R", descricao: "Hexágono Branco", cor: "Branco" },
        { codigo: "NN590401R", descricao: "Hexágono Bege", cor: "Bege" },
        { codigo: "NN591304R", descricao: "Textura Azul", cor: "Azul Acinzentado" },
        { codigo: "NN591302R", descricao: "Textura Escura", cor: "Cinza Escuro" },
        { codigo: "NN591301R", descricao: "Textura Clara", cor: "Cinza Claro" },
      ],
    },
    {
      id: 50,
      nome: "Contrastes Geométricos Dramáticos",
      codigo: "GEO-CONTRAST-01",
      cor: "Multicolor",
      textura: "Contrastante",
      categoria: "Dramático",
      imagem: "/catalog-images/geometricos-38.jpg",
      descricao: "Combinação dramática de padrões escuros e claros para ambientes contrastantes.",
      modelos: [
        { codigo: "DARK-GEO-01", descricao: "Geométrico Escuro", cor: "Preto" },
        { codigo: "LIGHT-CHEVRON-01", descricao: "Chevron Claro", cor: "Bege" },
        { codigo: "GRID-BLUE-01", descricao: "Grid Azul", cor: "Azul" },
      ],
    },
    {
      id: 51,
      nome: "Cubos 3D Dramáticos GR400901R",
      codigo: "GR400901R",
      cor: "Cinza",
      textura: "Cubos 3D",
      categoria: "3D Dramático",
      imagem: "/catalog-images/geometricos-39.jpg",
      descricao: "Efeito 3D de cubos criando profundidade dramática, aplicado com poltrona teal.",
      modelos: [{ codigo: "GR400901R", descricao: "Cubos 3D", cor: "Cinza Tridimensional" }],
    },
    {
      id: 52,
      nome: "Hexágonos Coloridos EL5006",
      codigo: "EL500603R",
      cor: "Azul",
      textura: "Hexagonal Colorido",
      categoria: "Colorido Premium",
      imagem: "/catalog-images/geometricos-40.jpg",
      descricao: "Hexágonos em múltiplas cores aplicados em sala moderna com TV integrada.",
      modelos: [
        { codigo: "EL500603R", descricao: "Hexágono Bege", cor: "Bege" },
        { codigo: "EL500604R", descricao: "Hexágono Azul Claro", cor: "Azul Claro" },
        { codigo: "EL500605R", descricao: "Hexágono Cinza", cor: "Cinza" },
        { codigo: "EL500606R", descricao: "Hexágono Azul", cor: "Azul" },
        { codigo: "EL500601R", descricao: "Hexágono Verde", cor: "Verde" },
        { codigo: "EL500602R", descricao: "Hexágono Escuro", cor: "Cinza Escuro" },
      ],
    },
    // New premium geometric products
    {
      id: 53,
      nome: "Série Chevron e Texturas VR9800",
      codigo: "VR980008R",
      cor: "Bege",
      textura: "Chevron e Textura",
      categoria: "Clássico",
      imagem: "/catalog-images/geometricos-41.jpg",
      descricao: "Padrão chevron clássico com texturas sutis.",
      modelos: [
        { codigo: "VR980008R", descricao: "Chevron Clássico", cor: "Bege" },
        { codigo: "VR980502R", descricao: "Textura Lisa", cor: "Bege Claro" },
      ],
    },
    {
      id: 54,
      nome: "Ondas Orgânicas MT3015",
      codigo: "MT301505R",
      cor: "Cinza",
      textura: "Ondulada",
      categoria: "Orgânico",
      imagem: "/catalog-images/geometricos-42.jpg",
      descricao: "Padrão de ondas orgânicas em tons de cinza.",
      modelos: [{ codigo: "MT301505R", descricao: "Ondas Suaves", cor: "Cinza Claro" }],
    },
    {
      id: 55,
      nome: "Lattice 3D Dramático MT300804R",
      codigo: "MT300804R",
      cor: "Bege",
      textura: "Lattice 3D",
      categoria: "3D Dramático",
      imagem: "/catalog-images/geometricos-43.jpg",
      descricao: "Padrão lattice 3D dramático em tons de bege.",
      modelos: [{ codigo: "MT300804R", descricao: "Lattice 3D", cor: "Bege" }],
    },
    {
      id: 56,
      nome: "Losangos Coloridos EL5008",
      codigo: "EL500801R",
      cor: "Multicolor",
      textura: "Losango",
      categoria: "Colorido",
      imagem: "/catalog-images/geometricos-44.jpg",
      descricao: "Padrão de losangos coloridos vibrantes.",
      modelos: [
        { codigo: "EL500801R", descricao: "Losango Vermelho", cor: "Vermelho" },
        { codigo: "EL500802R", descricao: "Losango Azul", cor: "Azul" },
        { codigo: "EL500803R", descricao: "Losango Amarelo", cor: "Amarelo" },
      ],
    },
    {
      id: 57,
      nome: "Hexágonos Metálicos WS1002",
      codigo: "WS100201R",
      cor: "Prata",
      textura: "Hexagonal Metálico",
      categoria: "Metálico",
      imagem: "/catalog-images/geometricos-45.jpg",
      descricao: "Padrão de hexágonos metálicos em tons de prata.",
      modelos: [{ codigo: "WS100201R", descricao: "Hexágono Prata", cor: "Prata" }],
    },
    {
      id: 58,
      nome: "Hexágonos Multicoloridos MT3001",
      codigo: "MT300101R",
      cor: "Multicolor",
      textura: "Hexagonal",
      categoria: "Multicolorido",
      imagem: "/catalog-images/geometricos-46.jpg",
      descricao: "Padrão de hexágonos multicoloridos.",
      modelos: [
        { codigo: "MT300101R", descricao: "Hexágono Colorido 1", cor: "Vermelho" },
        { codigo: "MT300102R", descricao: "Hexágono Colorido 2", cor: "Azul" },
        { codigo: "MT300103R", descricao: "Hexágono Colorido 3", cor: "Amarelo" },
      ],
    },
    {
      id: 59,
      nome: "Quatrefoil Delicado VR981906T",
      codigo: "VR981906T",
      cor: "Bege",
      textura: "Quatrefoil",
      categoria: "Delicado",
      imagem: "/catalog-images/geometricos-47.jpg",
      descricao: "Padrão quatrefoil delicado em tons de bege.",
      modelos: [{ codigo: "VR981906T", descricao: "Quatrefoil Bege", cor: "Bege" }],
    },
    {
      id: 60,
      nome: "Geométricos Complexos WS1003",
      codigo: "WS100301R",
      cor: "Cinza",
      textura: "Complexa",
      categoria: "Complexo",
      imagem: "/catalog-images/geometricos-48.jpg",
      descricao: "Padrão geométrico complexo em tons de cinza.",
      modelos: [{ codigo: "WS100301R", descricao: "Geométrico Complexo", cor: "Cinza" }],
    },
    {
      id: 61,
      nome: "Herringbone Clássico VR982103T",
      codigo: "VR982103T",
      cor: "Dourado",
      textura: "Herringbone",
      categoria: "Clássico",
      imagem: "/catalog-images/geometricos-49.jpg",
      descricao: "Padrão herringbone clássico em tons dourados.",
      modelos: [{ codigo: "VR982103T", descricao: "Herringbone Dourado", cor: "Dourado" }],
    },
    {
      id: 62,
      nome: "Linhas Geométricas Coloridas GR4004/GR4012",
      codigo: "GR400401R",
      cor: "Multicolor",
      textura: "Linear",
      categoria: "Linear",
      imagem: "/catalog-images/geometricos-50.jpg",
      descricao: "Padrão de linhas geométricas coloridas.",
      modelos: [
        { codigo: "GR400401R", descricao: "Linhas Coloridas 1", cor: "Vermelho" },
        { codigo: "GR401201R", descricao: "Linhas Coloridas 2", cor: "Azul" },
        { codigo: "GR400402R", descricao: "Linhas Coloridas 3", cor: "Amarelo" },
      ],
    },
    // Novas coleções finais ultra premium
    {
      id: 63,
      nome: "Hexágonos com Acentos Roxos MT3001",
      codigo: "MT300105R",
      cor: "Roxo",
      textura: "Hexagonal",
      categoria: "Colorido Premium",
      imagem: "/catalog-images/geometricos-51.jpg",
      descricao: "Hexágonos em tons neutros com acentos roxos sofisticados.",
      modelos: [
        { codigo: "MT300105R", descricao: "Hexágono Rosa", cor: "Rosa" },
        { codigo: "MT300102R", descricao: "Hexágono Neutro", cor: "Bege" },
        { codigo: "MT300103R", descricao: "Hexágono Roxo", cor: "Roxo" },
      ],
    },
    {
      id: 64,
      nome: "Padrões Angulares Modernos WS1014",
      codigo: "WS101404R",
      cor: "Cinza",
      textura: "Angular",
      categoria: "Ultra Moderno",
      imagem: "/catalog-images/geometricos-52.jpg",
      descricao: "Padrões angulares modernos aplicados em sala de jantar contemporânea.",
      modelos: [
        { codigo: "WS101404R", descricao: "Angular Complexo", cor: "Cinza" },
        { codigo: "WS101401R", descricao: "Angular Sutil", cor: "Bege" },
        { codigo: "WS101402R", descricao: "Angular Médio", cor: "Cinza Claro" },
        { codigo: "WS101403R", descricao: "Angular Intenso", cor: "Cinza Escuro" },
      ],
    },
    {
      id: 65,
      nome: "Chevrons Luxuosos NN590/NN591",
      codigo: "NN590304R",
      cor: "Bege",
      textura: "Chevron Luxuoso",
      categoria: "Luxo Premium",
      imagem: "/catalog-images/geometricos-53.jpg",
      descricao: "Chevrons luxuosos com aplicação em quarto master sofisticado.",
      modelos: [
        { codigo: "NN590304R", descricao: "Hexágono Bege", cor: "Bege" },
        { codigo: "NN591303R", descricao: "Chevron Dourado", cor: "Dourado" },
        { codigo: "NN590201R", descricao: "Chevron Claro", cor: "Bege Claro" },
        { codigo: "NN590302R", descricao: "Textura Azul", cor: "Azul Claro" },
      ],
    },
    {
      id: 66,
      nome: "Série Geométrica Sutil PT4006",
      codigo: "PT400601R",
      cor: "Bege",
      textura: "Geométrica Sutil",
      categoria: "Minimalista Premium",
      imagem: "/catalog-images/geometricos-54.jpg",
      descricao: "Padrões geométricos sutis com acentos metálicos dourados.",
      modelos: [
        { codigo: "PT400601R", descricao: "Geométrico Sutil", cor: "Bege Claro" },
        { codigo: "PT400602R", descricao: "Geométrico Neutro", cor: "Bege" },
        { codigo: "PT400603R", descricao: "Geométrico Azul", cor: "Azul Claro" },
        { codigo: "PT400604R", descricao: "Geométrico Dourado", cor: "Dourado" },
        { codigo: "PT400605R", descricao: "Geométrico Cinza", cor: "Cinza" },
      ],
    },
    {
      id: 67,
      nome: "Herringbone Madeira PT4013",
      codigo: "PT401301R",
      cor: "Madeira",
      textura: "Herringbone",
      categoria: "Natural Premium",
      imagem: "/catalog-images/geometricos-55.jpg",
      descricao: "Padrão herringbone inspirado em madeira natural em 3 tons.",
      modelos: [
        { codigo: "PT401301R", descricao: "Madeira Clara", cor: "Bege Claro" },
        { codigo: "PT401302R", descricao: "Madeira Natural", cor: "Marrom Claro" },
        { codigo: "PT401303R", descricao: "Madeira Escura", cor: "Marrom" },
      ],
    },
    {
      id: 68,
      nome: "Triângulos Artísticos GR4028",
      codigo: "GR402801",
      cor: "Multicolor",
      textura: "Triangular Artística",
      categoria: "Artístico Premium",
      imagem: "/catalog-images/geometricos-56.jpg",
      descricao: "Triângulos artísticos em estilo painterly com cores vibrantes.",
      modelos: [
        { codigo: "GR402801", descricao: "Triângulos Coloridos", cor: "Multicolor Vibrante" },
        { codigo: "GR402803", descricao: "Triângulos Azuis", cor: "Azul" },
        { codigo: "GR402802", descricao: "Triângulos Neutros", cor: "Cinza" },
        { codigo: "GR402804", descricao: "Triângulos Escuros", cor: "Preto" },
      ],
    },
    {
      id: 69,
      nome: "Texturas Madeira Vertical PT4006",
      codigo: "PT400601R",
      cor: "Madeira",
      textura: "Madeira Vertical",
      categoria: "Natural",
      imagem: "/catalog-images/geometricos-57.jpg",
      descricao: "Texturas de madeira vertical em 5 tons naturais.",
      modelos: [
        { codigo: "PT400601R", descricao: "Madeira Clara", cor: "Bege Claro" },
        { codigo: "PT400602R", descricao: "Madeira Azulada", cor: "Azul Acinzentado" },
        { codigo: "PT400603R", descricao: "Madeira Natural", cor: "Bege" },
        { codigo: "PT400604R", descricao: "Madeira Dourada", cor: "Dourado" },
        { codigo: "PT400605R", descricao: "Madeira Escura", cor: "Marrom" },
      ],
    },
    {
      id: 70,
      nome: "Mármores Orgânicos PT4004",
      codigo: "PT400401R",
      cor: "Bege",
      textura: "Mármore Orgânico",
      categoria: "Orgânico Premium",
      imagem: "/catalog-images/geometricos-58.jpg",
      descricao: "Padrões de mármore orgânico em 4 variações naturais.",
      modelos: [
        { codigo: "PT400401R", descricao: "Mármore Claro", cor: "Bege Claro" },
        { codigo: "PT400402R", descricao: "Mármore Cinza", cor: "Cinza" },
        { codigo: "PT400403R", descricao: "Mármore Dourado", cor: "Dourado" },
        { codigo: "PT400404R", descricao: "Mármore Natural", cor: "Bege" },
      ],
    },
    {
      id: 71,
      nome: "Crosshatch Diagonal PT4002",
      codigo: "PT400201R",
      cor: "Bege",
      textura: "Crosshatch Diagonal",
      categoria: "Artístico",
      imagem: "/catalog-images/geometricos-59.jpg",
      descricao: "Padrões crosshatch diagonais em 4 intensidades.",
      modelos: [
        { codigo: "PT400201R", descricao: "Crosshatch Sutil", cor: "Bege Claro" },
        { codigo: "PT400202R", descricao: "Crosshatch Médio", cor: "Bege" },
        { codigo: "PT400203R", descricao: "Crosshatch Intenso", cor: "Cinza" },
        { codigo: "PT400204R", descricao: "Crosshatch Dramático", cor: "Cinza Escuro" },
      ],
    },
    {
      id: 72,
      nome: "Losangos Clássicos MT3007",
      codigo: "MT300704R",
      cor: "Dourado",
      textura: "Losango Clássico",
      categoria: "Clássico Premium",
      imagem: "/catalog-images/geometricos-60.jpg",
      descricao: "Losangos clássicos aplicados em sala tradicional elegante.",
      modelos: [
        { codigo: "MT300704R", descricao: "Losango Dourado", cor: "Dourado" },
        { codigo: "MT300702R", descricao: "Losango Neutro", cor: "Bege" },
        { codigo: "MT300701R", descricao: "Losango Claro", cor: "Bege Claro" },
      ],
    },
    {
      id: 73,
      nome: "Texturas Lineares Sutis MT3016/MT3014",
      codigo: "MT301602R",
      cor: "Bege",
      textura: "Linear Sutil",
      categoria: "Minimalista Premium",
      imagem: "/catalog-images/geometricos-61.jpg",
      descricao: "Padrões lineares sutis em três variações de intensidade.",
      modelos: [
        { codigo: "MT301602R", descricao: "Linear Diagonal", cor: "Bege" },
        { codigo: "MT301403R", descricao: "Linear Vertical", cor: "Branco" },
        { codigo: "MT301402R", descricao: "Linear Horizontal", cor: "Cinza Claro" },
      ],
    },
    {
      id: 74,
      nome: "Ornamental Geométrico VR9805/VR9804",
      codigo: "VR980508R",
      cor: "Bege",
      textura: "Ornamental",
      categoria: "Étnico Luxuoso",
      imagem: "/catalog-images/geometricos-62.jpg",
      descricao: "Padrão ornamental geométrico com aplicação em ambiente étnico luxuoso.",
      modelos: [
        { codigo: "VR980508R", descricao: "Ornamental Geométrico", cor: "Bege" },
        { codigo: "VR980401H", descricao: "Textura Complementar", cor: "Bege Claro" },
      ],
    },
    {
      id: 75,
      nome: "Losangos Metálicos WS1001",
      codigo: "WS100101R",
      cor: "Cinza",
      textura: "Losango Metálico",
      categoria: "Contemporâneo Luxo",
      imagem: "/catalog-images/geometricos-63.jpg",
      descricao: "Losangos com acabamento metálico em gradação de tons, aplicados em sala de jantar moderna.",
      modelos: [
        { codigo: "WS100101R", descricao: "Losango Claro", cor: "Cinza Claro" },
        { codigo: "WS100104R", descricao: "Losango Médio", cor: "Cinza" },
        { codigo: "WS100103R", descricao: "Losango Escuro", cor: "Cinza Escuro" },
        { codigo: "WS100102R", descricao: "Losango Aplicado", cor: "Cinza Azulado" },
      ],
    },
    {
      id: 76,
      nome: "Coleção Geométrica Metalizada NN590",
      codigo: "NN590101R",
      cor: "Dourado",
      textura: "Mista Metalizada",
      categoria: "Luxo Metalizado",
      imagem: "/catalog-images/geometricos-64.jpg",
      descricao: "Coleção de padrões geométricos e marmorizados com acabamentos metalizados.",
      modelos: [
        { codigo: "NN590101R", descricao: "Geométrico Dourado", cor: "Dourado" },
        { codigo: "NN590402R", descricao: "Mármore Azulado", cor: "Azul Claro" },
        { codigo: "NN590704R", descricao: "Textura Neutra", cor: "Bege" },
        { codigo: "NN590105R", descricao: "Mármore Geométrico", cor: "Cinza" },
        { codigo: "NN590903R", descricao: "Chevron Metalizado", cor: "Cinza Escuro" },
      ],
    },
    {
      id: 77,
      nome: "Ondas 3D Orgânicas PT4012",
      codigo: "PT401201R",
      cor: "Bege",
      textura: "Ondas 3D",
      categoria: "Orgânico 3D",
      imagem: "/catalog-images/geometricos-65.jpg",
      descricao: "Padrões ondulados tridimensionais em dois tons complementares.",
      modelos: [
        { codigo: "PT401201R", descricao: "Ondas 3D Bege", cor: "Bege" },
        { codigo: "PT401202R", descricao: "Ondas 3D Cinza", cor: "Cinza Claro" },
      ],
    },
    {
      id: 78,
      nome: "Arcos Art Deco WS1004",
      codigo: "WS100403R",
      cor: "Cinza",
      textura: "Art Deco",
      categoria: "Art Deco Metalizado",
      imagem: "/catalog-images/geometricos-66.jpg",
      descricao: "Padrões Art Deco em arco com acabamento metálico, aplicados em ambiente moderno.",
      modelos: [
        { codigo: "WS100403R", descricao: "Arco Claro", cor: "Cinza Claro" },
        { codigo: "WS100402R", descricao: "Arco Médio", cor: "Cinza" },
        { codigo: "WS100401R", descricao: "Arco Escuro", cor: "Cinza Escuro" },
        { codigo: "WS100404R", descricao: "Arco Marrom", cor: "Marrom" },
      ],
    },
    {
      id: 79,
      nome: "Hexágonos Metálicos Modernos MT3012",
      codigo: "MT301201R",
      cor: "Bege",
      textura: "Hexagonal Metálica",
      categoria: "Contemporâneo Metalizado",
      imagem: "/catalog-images/geometricos-67.jpg",
      descricao: "Hexágonos com linhas metálicas aplicados em ambiente moderno minimalista.",
      modelos: [{ codigo: "MT301201R", descricao: "Hexágono Metálico", cor: "Bege" }],
    },
    {
      id: 80,
      nome: "Geométrico 3D Tridimensional GR4003",
      codigo: "GR400302R",
      cor: "Bege",
      textura: "3D Tridimensional",
      categoria: "3D Luxo",
      imagem: "/catalog-images/geometricos-68.jpg",
      descricao: "Padrões geométricos tridimensionais com aplicação em sala moderna.",
      modelos: [
        { codigo: "GR400302R", descricao: "Geométrico 3D Claro", cor: "Bege Claro" },
        { codigo: "GR400301R", descricao: "Geométrico 3D Escuro", cor: "Bege Escuro" },
      ],
    },
    {
      id: 81,
      nome: "Linhas Geométricas Gradientes WS1013",
      codigo: "WS101306R",
      cor: "Multicolor",
      textura: "Linear Gradiente",
      categoria: "Contemporâneo Premium",
      imagem: "/catalog-images/geometricos-69.jpg",
      descricao: "Linhas geométricas em gradação de tons, do dourado ao cinza escuro.",
      modelos: [
        { codigo: "WS101306R", descricao: "Linear Dourado", cor: "Dourado" },
        { codigo: "WS101301R", descricao: "Linear Branco", cor: "Branco" },
        { codigo: "WS101302R", descricao: "Linear Cinza Claro", cor: "Cinza Claro" },
        { codigo: "WS101303R", descricao: "Linear Cinza Médio", cor: "Cinza" },
        { codigo: "WS101304R", descricao: "Linear Cinza Escuro", cor: "Cinza Escuro" },
        { codigo: "WS101305R", descricao: "Linear Grafite", cor: "Preto" },
      ],
    },
    {
      id: 82,
      nome: "Coleção Geométrica Diversa WS1005-WS1008",
      codigo: "WS100802R",
      cor: "Multicolor",
      textura: "Diversa Premium",
      categoria: "Luxo Diversificado",
      imagem: "/catalog-images/geometricos-70.jpg",
      descricao: "Coleção diversificada com mármores, ondas e padrões geométricos metalizados.",
      modelos: [
        { codigo: "WS100802R", descricao: "Geométrico Dourado", cor: "Dourado" },
        { codigo: "WS100501R", descricao: "Geométrico Diamante", cor: "Bege" },
        { codigo: "WS100601R", descricao: "Ondas Azuis", cor: "Azul" },
        { codigo: "WS100602R", descricao: "Ondas Cinza", cor: "Cinza" },
        { codigo: "WS100701R", descricao: "Mármore Geométrico Claro", cor: "Branco" },
        { codigo: "WS100702R", descricao: "Mármore Geométrico Escuro", cor: "Cinza Escuro" },
        { codigo: "WS100703R", descricao: "Mármore Geométrico Médio", cor: "Cinza" },
        { codigo: "WS100801R", descricao: "Mármore Dourado", cor: "Dourado" },
      ],
    },
  ]

  const cores = [
    "Todas as Cores",
    "Cinza",
    "Dourado",
    "Azul",
    "Verde",
    "Rosa",
    "Preto",
    "Prata",
    "Multicolor",
    "Bege",
    "Branco",
    "Creme",
    "Madeira",
    "Marrom",
    "Amarelo",
    "Roxo",
    "Vermelho",
  ]

  const categorias = [
    "Todas as Categorias",
    "Moderno",
    "Luxo",
    "Contemporâneo",
    "Feminino",
    "Clássico",
    "Artístico",
    "Minimalista",
    "Premium",
    "3D",
    "Versátil",
    "Natural",
    "Elegante",
    "Art Deco",
    "Orgânico",
    "Sofisticado",
    "Colorido",
    "Ultra Moderno",
    "Fluido",
    "3D Premium",
    "Orgânico Geométrico",
    "Minimalista Premium",
    "Luxo Premium",
    "Dramático",
    "3D Dramático",
    "Colorido Premium",
    "Metálico",
    "Multicolorido",
    "Delicado",
    "Complexo",
    "Linear",
    "Natural Premium",
    "Artístico Premium",
    "Orgânico Premium",
    "Clássico Premium",
    "Étnico Luxuoso",
    "Contemporâneo Luxo",
    "Luxo Metalizado",
    "Orgânico 3D",
    "Art Deco Metalizado",
    "Contemporâneo Metalizado",
    "3D Luxo",
    "Contemporâneo Premium",
    "Luxo Diversificado",
  ]

  const produtosFiltrados = produtos.filter((produto) => {
    const corMatch = selectedColor === "Todas as Cores" || produto.cor === selectedColor
    const categoriaMatch = selectedCategory === "Todas as Categorias" || produto.categoria === selectedCategory
    return corMatch && categoriaMatch
  })

  const handleImageError = (index: number) => {
    setImageError((prev) => ({ ...prev, [index]: true }))
  }

  const handleImageClick = (produto: any) => {
    const modelosHtml = produto.modelos
      .map(
        (modelo: any) =>
          `<p class="text-sm mb-1"><strong>${modelo.codigo}:</strong> ${modelo.descricao} (${modelo.cor})</p>`,
      )
      .join("")

    const modal = document.createElement("div")
    modal.className = "fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
    modal.innerHTML = `
      <div class="relative max-w-4xl max-h-full w-full">
        <div class="flex flex-col md:flex-row bg-white rounded-lg overflow-hidden max-h-[90vh]">
          <div class="md:w-2/3">
            <img src="${produto.imagem}" alt="${produto.nome}" class="w-full h-64 md:h-full object-cover" />
          </div>
          <div class="md:w-1/3 p-6 overflow-y-auto">
            <h3 class="font-bold text-xl mb-3 text-gray-800">${produto.nome}</h3>
            <p class="text-gray-600 mb-4">${produto.descricao}</p>
            <div class="space-y-2 mb-4">
              <p class="text-sm"><strong>Código:</strong> ${produto.codigo}</p>
              <p class="text-sm"><strong>Cor:</strong> ${produto.cor}</p>
              <p class="text-sm"><strong>Textura:</strong> ${produto.textura}</p>
              <p class="text-sm"><strong>Categoria:</strong> ${produto.categoria}</p>
            </div>
            <div class="border-t pt-4">
              <strong class="text-sm block mb-2">Modelos inclusos:</strong>
              ${modelosHtml}
            </div>
            <div class="mt-6">
              <a href="https://wa.me/5561986792057?text=Olá! Gostaria de saber mais sobre o ${produto.nome} (${produto.codigo})" 
                 target="_blank" 
                 class="block w-full bg-green-500 text-white text-center py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors">
                💬 Solicitar Orçamento
              </a>
            </div>
          </div>
        </div>
        <button class="absolute top-4 right-4 text-white bg-black bg-opacity-50 rounded-full w-10 h-10 flex items-center justify-center hover:bg-opacity-75 transition-colors" onclick="this.parentElement.parentElement.remove()">
          ✕
        </button>
      </div>
    `
    modal.onclick = (e) => {
      if (e.target === modal) modal.remove()
    }
    document.body.appendChild(modal)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-gray-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4">
              <Image src="/logo-art-house.png" alt="Art House Logo" width={120} height={60} className="h-12 w-auto" />
            </Link>
            <div className="flex items-center space-x-6">
              <a
                href="/#catalogos"
                className="hidden md:block text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium"
              >
                ← Voltar aos Catálogos
              </a>
              <a
                href="https://wa.me/5561986792057"
                target="_blank"
                className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-6 py-2 rounded-full font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                rel="noreferrer"
              >
                💬 WhatsApp
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-400/10 to-indigo-400/10"></div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-purple-400 to-purple-600 rounded-3xl mb-8 text-4xl">
              📐
            </div>

            <h1 className="font-montserrat font-bold text-5xl md:text-6xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-6">
              Papéis Geométricos
            </h1>

            <p className="text-xl text-gray-600 mb-6 max-w-3xl mx-auto leading-relaxed">
              Designs geométricos modernos que trazem personalidade e estilo aos seus ambientes. Formas, linhas e
              padrões que criam impacto visual único.
            </p>

            <p className="text-gray-500 text-lg mb-8 max-w-3xl mx-auto">
              (Não encontrou o que procura? Entre em contato no nosso WhatsApp, possuímos mais catálogos fora do site,
              além disso, também podemos fazer personalizados.)
            </p>

            <div className="w-24 h-1 bg-gradient-to-r from-purple-400 to-indigo-400 mx-auto rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Cor</label>
                <select
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white"
                >
                  {cores.map((cor) => (
                    <option key={cor} value={cor}>
                      {cor}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Categoria</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent bg-white"
                >
                  {categorias.map((categoria) => (
                    <option key={categoria} value={categoria}>
                      {categoria}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="mt-4 text-center">
              <p className="text-gray-600">
                Mostrando <span className="font-semibold text-purple-600">{produtosFiltrados.length}</span> produtos
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {produtosFiltrados.map((produto, index) => (
              <div
                key={produto.id}
                className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 overflow-hidden border border-purple-100"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  {!imageError[index] ? (
                    <Image
                      src={produto.imagem || "/placeholder.svg"}
                      alt={produto.nome}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                      onError={() => handleImageError(index)}
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-purple-100 to-indigo-100 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-4xl mb-2">📐</div>
                        <p className="text-gray-500 text-sm">{produto.nome}</p>
                      </div>
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-purple-500/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                  <div className="absolute bottom-4 left-4 right-4 transform translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                    <h3 className="text-white font-semibold text-lg mb-2">{produto.nome}</h3>
                    <button
                      className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-white/30 transition-colors w-full"
                      onClick={() => handleImageClick(produto)}
                    >
                      Ver Detalhes
                    </button>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="font-semibold text-lg text-gray-800 mb-2">{produto.nome}</h3>
                  <p className="text-gray-600 text-sm mb-3">{produto.descricao}</p>
                  <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
                    <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full">{produto.cor}</span>
                    <span className="bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full">{produto.categoria}</span>
                  </div>
                  <button
                    onClick={() => handleImageClick(produto)}
                    className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 text-white py-2 rounded-lg font-medium hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                  >
                    Ver Modelos
                  </button>
                </div>
              </div>
            ))}
          </div>

          {produtosFiltrados.length === 0 && (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-2xl font-semibold text-gray-700 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-500">Tente ajustar os filtros para encontrar o que procura.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-purple-400/10 to-indigo-400/10">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="font-montserrat font-bold text-3xl text-[#1B5E3A] mb-6">Gostou de algum modelo?</h2>
            <p className="text-gray-600 text-lg mb-8">
              Entre em contato conosco para solicitar orçamento, tirar dúvidas ou conhecer mais opções disponíveis.
            </p>
            <a
              href="https://wa.me/5561986792057"
              target="_blank"
              className="group inline-flex items-center gap-3 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-10 py-4 rounded-2xl font-montserrat font-semibold text-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 relative overflow-hidden"
              rel="noreferrer"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
              <span className="relative">💬 Falar no WhatsApp</span>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 to-black text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#1B5E3A]/10 to-transparent"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div className="animate-fade-in-up">
              <div className="flex items-center mb-6">
                <Image
                  src="/logo-art-house.png"
                  alt="Art House Logo"
                  width={150}
                  height={75}
                  className="h-16 w-auto filter brightness-0 invert"
                />
              </div>
              <h3 className="font-montserrat font-bold text-2xl text-white mb-4">
                Art House | 25 anos transformando ambientes em Brasília.
              </h3>
              <p className="text-gray-300 text-lg leading-relaxed">
                Especialistas em papel de parede com a qualidade e confiança que você merece.
              </p>
            </div>

            <div className="animate-fade-in-up animation-delay-200">
              <h4 className="font-montserrat font-bold text-xl text-white mb-6">Links Rápidos</h4>
              <div className="space-y-3">
                <a href="/#hero" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Home
                </a>
                <a href="/#produtos" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Produtos
                </a>
                <a href="/#catalogos" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Catálogos
                </a>
                <a href="/#vantagens" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Vantagens
                </a>
                <a href="/sobre" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Sobre
                </a>
                <a href="/contato" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Contato
                </a>
              </div>
            </div>

            <div className="animate-fade-in-up animation-delay-400">
              <h4 className="font-montserrat font-bold text-xl text-white mb-6">Contato</h4>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📍
                  </div>
                  <p className="text-gray-300 text-lg">CLS 311, Bloco C, Loja 29, Asa Sul, Brasília - DF</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📧
                  </div>
                  <a
                    href="mailto:contato@arthousepapeldeparede.com.br"
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                  >
                    contato@arthousepapeldeparede.com.br
                  </a>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📱
                  </div>
                  <a
                    href="https://wa.me/5561986792057"
                    target="_blank"
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                    rel="noreferrer"
                  >
                    (61) 9 8679-2057
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-400 text-lg">
              &copy; 2024 Art House. Todos os direitos reservados. | Desenvolvido com ❤️ para transformar ambientes.
            </p>
          </div>
        </div>
      </footer>

      {/* Floating Back Button - Mobile Only */}
      <a
        href="/#catalogos"
        className="fixed bottom-6 left-6 z-50 md:hidden bg-gradient-to-r from-gray-600 to-gray-700 text-white p-4 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 group"
      >
        <svg
          className="w-6 h-6 group-hover:scale-110 transition-transform duration-300"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold">
          📖
        </div>
      </a>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/5561986792057"
        target="_blank"
        className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-green-500 to-green-600 text-white p-5 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 animate-pulse-slow group"
        rel="noreferrer"
      >
        <svg
          className="w-8 h-8 group-hover:scale-110 transition-transform duration-300"
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488" />
        </svg>
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-xs font-bold animate-bounce">
          !
        </div>
      </a>
    </div>
  )
}
