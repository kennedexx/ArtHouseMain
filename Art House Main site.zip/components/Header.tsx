"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-b border-gray-100 transition-all duration-300">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/" className="scroll-smooth">
            <Image src="/logo-art-house.png" alt="Art House Logo" width={160} height={80} className="h-16 w-auto" />
          </Link>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
            Home
          </Link>
          <a href="/#produtos" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
            Produtos
          </a>
          <a href="/#catalogos" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
            Catálogos
          </a>
          <a href="/#vantagens" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
            Vantagens
          </a>
          <Link href="/sobre" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
            Sobre
          </Link>
          <Link href="/contato" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
            Contato
          </Link>
          <a
            href="https://wa.me/5561986792057"
            target="_blank"
            className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-8 py-3 text-lg rounded-full font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
            rel="noreferrer"
          >
            💬 WhatsApp
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          aria-label="Menu"
        >
          <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {isMobileMenuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100">
          <div className="px-4 py-2 space-y-1">
            <Link
              href="/"
              className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </Link>
            <a
              href="/#produtos"
              className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Produtos
            </a>
            <a
              href="/#catalogos"
              className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Catálogos
            </a>
            <a
              href="/#vantagens"
              className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Vantagens
            </a>
            <Link
              href="/sobre"
              className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Sobre
            </Link>
            <Link
              href="/contato"
              className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contato
            </Link>
            <a
              href="https://wa.me/5561986792057"
              target="_blank"
              className="block mx-3 my-2 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-4 py-2 rounded-lg font-semibold text-center"
              rel="noreferrer"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              💬 WhatsApp
            </a>
          </div>
        </div>
      )}
    </nav>
  )
}
