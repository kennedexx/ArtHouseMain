"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Share2, Search, Filter, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"
import ImageModal from "@/components/ImageModal"
import { useState } from "react"

export default function CatalogoMica() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedColor, setSelectedColor] = useState("Todas as Cores")
  const [selectedProduto, setSelectedProduto] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const produtos = [
    {
      id: 1,
      nome: "Mica Grafite Natural",
      codigo: "4M563109R",
      cor: "Grafite",
      textura: "Natural",
      categoria: "Moderno",
      imagem: "/catalog-images/mica-1.jpg",
      modelos: [
        { codigo: "4M563109R", cor: "Grafite", descricao: "Mica Grafite Natural" },
        { codigo: "4M563110R", cor: "Grafite Claro", descricao: "Mica Grafite Claro" },
        { codigo: "4M563111R", cor: "Grafite Escuro", descricao: "Mica Grafite Escuro" },
      ],
      cores: ["Grafite"],
      descricao: "Mica grafite natural com partículas brilhantes que criam reflexos únicos em tons acinzentados.",
    },
    {
      id: 2,
      nome: "Mica Dourada Premium",
      codigo: "4M563508R",
      cor: "Dourado",
      textura: "Natural",
      categoria: "Premium",
      imagem: "/catalog-images/mica-2.jpg",
      modelos: [
        { codigo: "4M563508R", cor: "Dourado Claro", descricao: "Mica Dourada Clara" },
        { codigo: "4M563509R", cor: "Dourado Rosé", descricao: "Mica Dourada Rosé" },
        { codigo: "4M5635010R", cor: "Dourado Bronze", descricao: "Mica Dourada Bronze" },
      ],
      cores: ["Dourado"],
      descricao: "Mica dourada premium com tons quentes e brilho natural autêntico.",
    },
    {
      id: 3,
      nome: "Mica Bronze Elegante",
      codigo: "4M563514R",
      cor: "Bronze",
      textura: "Natural",
      categoria: "Elegante",
      imagem: "/catalog-images/mica-3.jpg",
      modelos: [
        { codigo: "4M563514R", cor: "Bronze Escuro", descricao: "Mica Bronze Escuro" },
        { codigo: "4M563515R", cor: "Bronze Dourado", descricao: "Mica Bronze Dourado" },
        { codigo: "4M5635016R", cor: "Bronze Claro", descricao: "Mica Bronze Claro" },
      ],
      cores: ["Bronze"],
      descricao: "Mica bronze elegante com reflexos metálicos sofisticados.",
    },
    {
      id: 4,
      nome: "Mica Pérola Delicada",
      codigo: "4M563517R",
      cor: "Pérola",
      textura: "Natural",
      categoria: "Delicado",
      imagem: "/catalog-images/mica-4.jpg",
      modelos: [
        { codigo: "4M563517R", cor: "Pérola", descricao: "Mica Pérola Natural" },
        { codigo: "4M563518R", cor: "Pérola Rosé", descricao: "Mica Pérola Rosé" },
        { codigo: "4M561703R", cor: "Pérola Cinza", descricao: "Mica Pérola Cinza" },
      ],
      cores: ["Pérola"],
      descricao: "Mica pérola delicada com tons suaves e brilho nacarado.",
    },
    {
      id: 5,
      nome: "Mica Natural Bege",
      codigo: "4M563511R",
      cor: "Bege",
      textura: "Natural",
      categoria: "Natural",
      imagem: "/catalog-images/mica-5.jpg",
      modelos: [
        { codigo: "4M563511R", cor: "Bege Natural", descricao: "Mica Bege Natural" },
        { codigo: "4M563512R", cor: "Bege Claro", descricao: "Mica Bege Claro" },
        { codigo: "4M5635013R", cor: "Bege Neutro", descricao: "Mica Bege Neutro" },
      ],
      cores: ["Bege"],
      descricao: "Mica natural bege com propriedades naturais preservadas e tons terrosos.",
    },
    {
      id: 6,
      nome: "Mica Cobre Rústica",
      codigo: "4M563501R",
      cor: "Cobre",
      textura: "Natural",
      categoria: "Rústico",
      imagem: "/catalog-images/mica-6.jpg",
      modelos: [
        { codigo: "4M563501R", cor: "Cobre Claro", descricao: "Mica Cobre Claro" },
        { codigo: "4M563502R", cor: "Cobre Bronze", descricao: "Mica Cobre Bronze" },
        { codigo: "4M563503R", cor: "Cobre Escuro", descricao: "Mica Cobre Escuro" },
      ],
      cores: ["Cobre"],
      descricao: "Mica cobre rústica com textura natural e reflexos únicos em tons metálicos.",
    },
    {
      id: 7,
      nome: "Mica Champagne Luxo",
      codigo: "4M563302R",
      cor: "Champagne",
      textura: "Natural",
      categoria: "Luxo",
      imagem: "/catalog-images/mica-7.jpg",
      modelos: [
        { codigo: "4M563302R", cor: "Champagne", descricao: "Mica Champagne Natural" },
        { codigo: "4M563306R", cor: "Champagne Claro", descricao: "Mica Champagne Claro" },
        { codigo: "4M563307R", cor: "Champagne Rosé", descricao: "Mica Champagne Rosé" },
      ],
      cores: ["Champagne"],
      descricao: "Mica champagne luxo com brilho sutil e elegante em tons claros.",
    },
    {
      id: 8,
      nome: "Mica Antracite Moderna",
      codigo: "4M563308R",
      cor: "Antracite",
      textura: "Natural",
      categoria: "Moderno",
      imagem: "/catalog-images/mica-8.jpg",
      modelos: [
        { codigo: "4M563308R", cor: "Antracite Natural", descricao: "Mica Antracite Natural" },
        { codigo: "4M563315R", cor: "Antracite Escuro", descricao: "Mica Antracite Escuro" },
        { codigo: "4M563701R", cor: "Antracite Dourado", descricao: "Mica Antracite Dourado" },
      ],
      cores: ["Antracite"],
      descricao: "Mica antracite moderna com acabamento contemporâneo e reflexos metálicos.",
    },
    {
      id: 9,
      nome: "Mica Cinza Industrial",
      codigo: "4M563702R",
      cor: "Cinza",
      textura: "Natural",
      categoria: "Industrial",
      imagem: "/catalog-images/mica-9.jpg",
      modelos: [
        { codigo: "4M563702R", cor: "Cinza Industrial", descricao: "Mica Cinza Industrial" },
        { codigo: "4M563703R", cor: "Cinza Cobre", descricao: "Mica Cinza Cobre" },
        { codigo: "4M563704R", cor: "Cinza Claro", descricao: "Mica Cinza Claro" },
      ],
      cores: ["Cinza"],
      descricao: "Mica cinza industrial com textura robusta e acabamento moderno.",
    },
    {
      id: 10,
      nome: "Mica Rosé Sofisticada",
      codigo: "4M563504R",
      cor: "Rosé",
      textura: "Natural",
      categoria: "Sofisticado",
      imagem: "/catalog-images/mica-10.jpg",
      modelos: [
        { codigo: "4M563504R", cor: "Rosé Bege", descricao: "Mica Rosé Bege" },
        { codigo: "4M563505R", cor: "Rosé Natural", descricao: "Mica Rosé Natural" },
        { codigo: "4M563507R", cor: "Rosé Escuro", descricao: "Mica Rosé Escuro" },
      ],
      cores: ["Rosé"],
      descricao: "Mica rosé sofisticada com tons femininos e brilho delicado.",
    },
    {
      id: 11,
      nome: "Mica Prata Elegante",
      codigo: "4M563601R",
      cor: "Prata",
      textura: "Natural",
      categoria: "Elegante",
      imagem: "/catalog-images/mica-11.jpg",
      modelos: [
        { codigo: "4M563601R", cor: "Prata Claro", descricao: "Mica Prata Clara" },
        { codigo: "4M563602R", cor: "Prata Natural", descricao: "Mica Prata Natural" },
        { codigo: "4M563603R", cor: "Prata Bege", descricao: "Mica Prata Bege" },
      ],
      cores: ["Prata"],
      descricao: "Mica prata elegante com textura suave e brilho metálico refinado.",
    },
    {
      id: 12,
      nome: "Mica Listrada Premium",
      codigo: "4M563711R",
      cor: "Cinza",
      textura: "Listrada",
      categoria: "Premium",
      imagem: "/catalog-images/mica-12.jpg",
      modelos: [
        { codigo: "4M563711R", cor: "Cinza Rústico", descricao: "Mica Cinza Rústica" },
        { codigo: "4M563206R", cor: "Cinza Pontilhado", descricao: "Mica Cinza Pontilhada" },
        { codigo: "4M563209R", cor: "Cinza Listrado", descricao: "Mica Cinza Listrada" },
      ],
      cores: ["Cinza"],
      descricao: "Mica cinza premium com padrões listrados e pontilhados únicos.",
    },
    {
      id: 13,
      nome: "Mica Dourada Rústica",
      codigo: "4M563708R",
      cor: "Dourado",
      textura: "Rústica",
      categoria: "Rústico",
      imagem: "/catalog-images/mica-13.jpg",
      modelos: [
        { codigo: "4M563708R", cor: "Dourado Rústico", descricao: "Mica Dourada Rústica" },
        { codigo: "4M563709R", cor: "Dourado Rosé", descricao: "Mica Dourada Rosé" },
        { codigo: "4M563710R", cor: "Dourado Bege", descricao: "Mica Dourada Bege" },
      ],
      cores: ["Dourado"],
      descricao: "Mica dourada rústica com detalhes azuis e textura natural autêntica.",
    },
    {
      id: 14,
      nome: "Mica Industrial Moderna",
      codigo: "4M563705R",
      cor: "Cinza",
      textura: "Industrial",
      categoria: "Industrial",
      imagem: "/catalog-images/mica-14.jpg",
      modelos: [
        { codigo: "4M563705R", cor: "Cinza Industrial", descricao: "Mica Cinza Industrial" },
        { codigo: "4M563706R", cor: "Cinza Dourado", descricao: "Mica Cinza Dourado" },
        { codigo: "4M563707R", cor: "Cinza Cobre", descricao: "Mica Cinza Cobre" },
      ],
      cores: ["Cinza"],
      descricao: "Mica cinza industrial moderna com detalhes dourados e acabamento contemporâneo.",
    },
  ]

  const cores = [
    "Todas as Cores",
    "Grafite",
    "Dourado",
    "Bronze",
    "Pérola",
    "Bege",
    "Cobre",
    "Champagne",
    "Antracite",
    "Cinza",
    "Rosé",
    "Prata",
  ]

  const filteredProducts = produtos.filter((produto) => {
    const matchesSearch =
      produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      produto.codigo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      produto.cor.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesColor = selectedColor === "Todas as Cores" || produto.cor === selectedColor
    return matchesSearch && matchesColor
  })

  const openModal = (produto: any) => {
    setSelectedProduto(produto)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setSelectedProduto(null)
    setIsModalOpen(false)
  }

  const goToPrevious = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const previousIndex = currentIndex === 0 ? filteredProducts.length - 1 : currentIndex - 1
      setSelectedProduto(filteredProducts[previousIndex])
    }
  }

  const goToNext = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const nextIndex = currentIndex === filteredProducts.length - 1 ? 0 : currentIndex + 1
      setSelectedProduto(filteredProducts[nextIndex])
    }
  }

  const handlePedirOrcamento = (produto: any) => {
    const mensagem = `Olá! Gostaria de solicitar um orçamento para o papel de parede:

*${produto.nome}*
Código: ${produto.codigo}
Cor: ${produto.cor}

Aguardo retorno. Obrigado!`

    const whatsappUrl = `https://wa.me/5561986792057?text=${encodeURIComponent(mensagem)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-orange-50">
      <Header />

      <div className="pt-20 sm:pt-24">
        {/* Breadcrumb */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-3 sm:py-4">
            <div className="flex items-center gap-2 sm:gap-4">
              <Link href="/" className="flex items-center gap-2 text-amber-700 hover:text-amber-800 transition-colors">
                <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
                <span className="font-medium text-sm sm:text-base">Voltar</span>
              </Link>
              <div className="h-4 sm:h-6 w-px bg-gray-300" />
              <h1 className="text-lg sm:text-2xl font-bold text-gray-900">Catálogo Mica</h1>
            </div>
          </div>
        </div>

        {/* Hero Section */}
        <div className="bg-gradient-to-r from-amber-600 to-orange-600 text-white py-8 sm:py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-bold mb-2 sm:mb-4">Coleção Mica</h2>
            <p className="text-lg sm:text-xl md:text-2xl mb-3 sm:mb-6 text-amber-100">
              Brilho natural autêntico extraído da rocha
            </p>
            <p className="text-sm sm:text-lg text-amber-200 max-w-2xl mx-auto px-4">
              Papéis de parede com mica natural compressada, oferecendo reflexos únicos impossíveis de replicar
              artificialmente.
            </p>
          </div>
        </div>

        {/* Filtros e Busca */}
        <div className="container mx-auto px-4 py-4 sm:py-8">
          <div className="bg-white rounded-lg shadow-sm border p-4 sm:p-6 mb-6 sm:mb-8">
            <div className="flex flex-col gap-4">
              <div className="w-full">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar por nome, código ou cor..."
                    className="pl-10 h-12 sm:h-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600 font-medium">Filtrar por cor:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {cores.map((cor) => (
                    <Badge
                      key={cor}
                      variant={cor === selectedColor ? "default" : "outline"}
                      className="cursor-pointer hover:bg-amber-100 text-xs sm:text-sm px-2 sm:px-3 py-1 sm:py-1.5 min-h-[32px] sm:min-h-[36px]"
                      onClick={() => setSelectedColor(cor)}
                    >
                      {cor}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Grid de Produtos */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
            {filteredProducts.map((produto) => (
              <div
                key={produto.id}
                className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-all duration-300 overflow-hidden group"
              >
                <div className="relative">
                  <Image
                    src={produto.imagem || "/placeholder.svg"}
                    alt={produto.nome}
                    width={225}
                    height={400}
                    className="w-full aspect-[9/16] object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                    onClick={() => openModal(produto)}
                  />
                  <div className="absolute top-2 sm:top-3 right-2 sm:right-3 flex gap-1 sm:gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="w-8 h-8 sm:w-9 sm:h-9 p-0 bg-white/90 hover:bg-white"
                      onClick={() => openModal(produto)}
                    >
                      <Eye className="w-3 h-3 sm:w-4 sm:h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="w-8 h-8 sm:w-9 sm:h-9 p-0 bg-white/90 hover:bg-white"
                    >
                      <Heart className="w-3 h-3 sm:w-4 sm:h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="w-8 h-8 sm:w-9 sm:h-9 p-0 bg-white/90 hover:bg-white"
                    >
                      <Share2 className="w-3 h-3 sm:w-4 sm:h-4" />
                    </Button>
                  </div>
                  <div className="absolute bottom-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                    {produto.categoria}
                  </div>
                </div>

                <div className="p-3 sm:p-4">
                  <h3 className="font-semibold text-base sm:text-lg text-gray-900 mb-2 line-clamp-2">{produto.nome}</h3>
                  <p className="text-xs sm:text-sm text-gray-600 mb-1">Código: {produto.codigo}</p>
                  <p className="text-xs sm:text-sm text-gray-600 mb-1">Cor: {produto.cor}</p>
                  <p className="text-xs sm:text-sm text-gray-500 mb-3 line-clamp-2">{produto.descricao}</p>

                  <Button
                    className="w-full bg-green-600 hover:bg-green-700 text-white h-10 sm:h-11 text-sm sm:text-base"
                    onClick={() => handlePedirOrcamento(produto)}
                  >
                    💬 Pedir Orçamento
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-8 sm:py-12">
              <div className="text-4xl sm:text-6xl mb-4">🔍</div>
              <h3 className="text-lg sm:text-xl font-semibold text-gray-600 mb-2">Nenhum produto encontrado</h3>
              <p className="text-sm sm:text-base text-gray-500">Tente buscar por uma cor ou termo diferente</p>
            </div>
          )}

          {/* Informações Adicionais */}
          <div className="mt-8 sm:mt-12 bg-white rounded-lg shadow-sm border p-6 sm:p-8">
            <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 text-center">
              Por que escolher nossa Coleção Mica?
            </h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              <div className="text-center">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                  <span className="text-xl sm:text-2xl">⛰️</span>
                </div>
                <h4 className="font-semibold text-base sm:text-lg mb-2">Produto Natural</h4>
                <p className="text-sm sm:text-base text-gray-600">
                  Mica extraída diretamente da rocha, preservando suas propriedades naturais.
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                  <span className="text-xl sm:text-2xl">✨</span>
                </div>
                <h4 className="font-semibold text-base sm:text-lg mb-2">Brilho Autêntico</h4>
                <p className="text-sm sm:text-base text-gray-600">
                  Reflexos naturais únicos que não podem ser replicados artificialmente.
                </p>
              </div>
              <div className="text-center sm:col-span-2 lg:col-span-1">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                  <span className="text-xl sm:text-2xl">🔨</span>
                </div>
                <h4 className="font-semibold text-base sm:text-lg mb-2">Processo Artesanal</h4>
                <p className="text-sm sm:text-base text-gray-600">
                  Mica compressada no papel através de processo especializado.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <WhatsAppFloat />

      {/* Image Modal */}
      <ImageModal
        isOpen={isModalOpen}
        onClose={closeModal}
        imageSrc={selectedProduto?.imagem || ""}
        imageAlt={selectedProduto?.nome || ""}
        imageTitle={selectedProduto?.nome || ""}
        description={selectedProduto?.descricao}
        modelosHtml={
          selectedProduto?.modelos
            ?.map(
              (modelo: any) =>
                `<p class="text-sm mb-1"><strong>${modelo.codigo}:</strong> ${modelo.descricao} (${modelo.cor})</p>`,
            )
            .join("") || ""
        }
        currentIndex={selectedProduto ? filteredProducts.findIndex((p) => p.id === selectedProduto.id) : 0}
        totalItems={filteredProducts.length}
        onNext={goToNext}
        onPrev={goToPrevious}
      />
    </div>
  )
}
