"use client"

import type React from "react"
import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"

export default function ArtHouseLanding() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [currentTestimonial, setCurrentTestimonial] = useState(0)
  const [countdown, setCountdown] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 })
  const [showStickyCTA, setShowStickyCTA] = useState(false)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [bannerClosed, setBannerClosed] = useState(false)

  // Mouse tracking for parallax effects
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 100,
        y: (e.clientY / window.innerHeight) * 100,
      })
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  // Countdown timer
  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date().getTime()
      const nextSunday = new Date()
      nextSunday.setDate(nextSunday.getDate() + (7 - nextSunday.getDay()))
      nextSunday.setHours(23, 59, 59, 999)

      const distance = nextSunday.getTime() - now

      const days = Math.floor(distance / (1000 * 60 * 60 * 24))
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((distance % (1000 * 60)) / 1000)

      setCountdown({ days, hours, minutes, seconds })
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)
    return () => clearInterval(interval)
  }, [])

  // Carousel auto-advance
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % carouselImages.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [])

  // Testimonials auto-advance
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % 5)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  // Sticky CTA on scroll
  useEffect(() => {
    const handleScroll = () => {
      setShowStickyCTA(window.scrollY > window.innerHeight * 0.5)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const formElement = e.currentTarget
      const formData = new FormData(formElement)
      const data = {
        nome: formData.get("nome") as string,
        email: formData.get("email") as string,
        whatsapp: formData.get("whatsapp") as string,
        interesse: formData.get("interesse") as string,
      }

      const response = await fetch("/api/send-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        alert(
          "🎉 Obrigado! Seus dados foram enviados com sucesso!\n\n✅ Você receberá um email de confirmação em breve\n🎁 Seu desconto de 5% está garantido!\n📱 Nossa equipe entrará em contato via WhatsApp",
        )
        const form = document.getElementById("contactForm") as HTMLFormElement
        if (form) {
          form.reset()
        }
      } else {
        const errorData = await response.json()
        alert(`❌ Erro ao enviar: ${errorData.error || "Tente novamente"}`)
      }
    } catch (error) {
      console.error("Erro:", error)
      alert("❌ Erro de conexão. Tente novamente ou entre em contato via WhatsApp.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const carouselImages = [
    { src: "/carousel-1-estampados.jpeg", alt: "Papéis estampados com padrões geométricos em madeira" },
    { src: "/carousel-2-estampados.jpeg", alt: "Papéis com textura rústica de tijolo vintage" },
    { src: "/carousel-3-textura.jpeg", alt: "Papéis com textura sutil tipo concreto" },
    { src: "/carousel-4-lisos.jpeg", alt: "Papéis lisos em tons neutros e suaves" },
    { src: "/carousel-5-personalizados.jpeg", alt: "Papel personalizado tema floresta e safari" },
    { src: "/carousel-6-personalizados.jpeg", alt: "Papel personalizado nuvens rosa e flores" },
    { src: "/carousel-7-personalizados.jpeg", alt: "Papel personalizado mapa-múndi e espaço" },
  ]

  const testimonials = [
    {
      text: "Recomendo demais! Consegui montar o projeto do meu papel de parede personalizado de forma muito fácil devido a disponibilidade e compromisso dos profissionais. A entrega também foi dentro do prazo, o que fez muita diferença pra mim. Podem ir sem medo!",
      author: "Gabriel Ribeiro",
      photo: "/depoimentos/gabriel-ribeiro.png",
    },
    {
      text: "Há mais de cinco anos tenho papel de parede nas salas, quartos e corredores, estão perfeitos. Recentemente aplicação no teto, para correção de imperfeições do gesso, ficou sensacional. Recomendo.",
      author: "Lucia Helena",
      photo: "/depoimentos/lucia-helena.png",
    },
    {
      text: "Somente elogios, já comprei 3 vezes nos últimos 6 anos e todos os atendimentos foram incríveis, desde a escolha do papel de parede, até a instalação. Recomendo muito.",
      author: "Camila Silva",
      photo: "/depoimentos/camila-silva.png",
    },
    {
      text: "Foi muito satisfatória. Atendimento vip, entregou no prazo, equipe instaladora profissional e eficiente. Recomendo.",
      author: "Marlene S. Alexandre",
      photo: "/depoimentos/marlene-alexandre.png",
    },
    {
      text: "A Art House tem um atendimento eficiente em local de fácil acesso, Alice a proprietária é muito amável e comprometida com a qualidade e a variedade de seus produtos, inclusive oferece uma coleção de belíssimas padronagens. Fiquei muito contente com o serviço prestado, parabéns! Obrigada!",
      author: "Rita Cazalles",
      photo: "/depoimentos/rita-cazalles.png",
    },
  ]

  const catalogos = [
    {
      nome: "Lisos",
      cor: "from-blue-400 to-blue-600",
      link: "/catalogos/lisos",
      imagem: "/catalog-covers/lisos-cover.png",
      descricao: "Elegância minimalista em cores neutras",
    },
    {
      nome: "Texturas",
      cor: "from-gray-400 to-gray-600",
      link: "/catalogos/texturas",
      imagem: "/catalog-covers/texturas-cover.png",
      descricao: "Superfícies táteis e modernas",
    },
    {
      nome: "Infantis",
      cor: "from-green-200 to-green-400",
      link: "/catalogos/infantis",
      imagem: "/catalog-covers/infantis-cover.png",
      descricao: "Diversão e cor para os pequenos",
    },
    {
      nome: "Personalizados",
      cor: "from-red-400 to-red-600",
      link: "/catalogos/personalizados",
      imagem: "/catalog-covers/personalizados-cover.png",
      descricao: "Criações exclusivas para você",
    },
    {
      nome: "Linho",
      cor: "from-amber-400 to-yellow-500",
      link: "/catalogos/linho",
      imagem: "/catalog-covers/linho-cover.png",
      descricao: "Texturas elegantes e sofisticadas",
    },
    {
      nome: "Geométricos",
      cor: "from-purple-400 to-purple-600",
      link: "/catalogos/geometricos",
      imagem: "/catalog-covers/geometricos-cover.png",
      descricao: "Padrões modernos e sofisticados",
    },
    {
      nome: "3D",
      cor: "from-indigo-400 to-indigo-600",
      link: "/catalogos/3d",
      imagem: "/catalog-covers/3d-cover.png",
      descricao: "Efeitos dimensionais impressionantes",
    },
    {
      nome: "Folhagens",
      cor: "from-green-400 to-green-600",
      link: "/catalogos/folhagens",
      imagem: "/catalog-covers/folhagens-cover.png",
      descricao: "Natureza e frescor em casa",
    },
    {
      nome: "Ripados",
      cor: "from-stone-400 to-stone-600",
      link: "/catalogos/ripados",
      imagem: "/catalog-covers/ripados-cover.jpg",
      descricao: "Madeira natural e aconchego",
    },
    {
      nome: "Mica",
      cor: "from-amber-400 to-yellow-600",
      link: "/catalogos/mica",
      imagem: "/catalog-covers/mica-cover.png",
      descricao: "Brilho e sofisticação premium",
    },
    {
      nome: "Clássicos",
      cor: "from-slate-400 to-gray-600",
      link: "/catalogos/classicos",
      imagem: "/catalog-covers/classicos-cover.png",
      descricao: "Tradição e elegância atemporal",
    },
  ]

  return (
    <div className="font-roboto bg-white overflow-hidden">
      {/* Floating Elements Background */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div
          className="absolute w-96 h-96 bg-gradient-to-r from-emerald-400/10 to-blue-400/10 rounded-full blur-3xl animate-float"
          style={{
            transform: `translate(${mousePosition.x * 0.02}px, ${mousePosition.y * 0.02}px)`,
            top: "10%",
            left: "10%",
          }}
        />
        <div
          className="absolute w-80 h-80 bg-gradient-to-r from-purple-400/10 to-pink-400/10 rounded-full blur-3xl animate-float-delayed"
          style={{
            transform: `translate(${mousePosition.x * -0.01}px, ${mousePosition.y * -0.01}px)`,
            top: "60%",
            right: "10%",
          }}
        />
        <div
          className="absolute w-64 h-64 bg-gradient-to-r from-yellow-400/10 to-orange-400/10 rounded-full blur-3xl animate-float-slow"
          style={{
            transform: `translate(${mousePosition.x * 0.015}px, ${mousePosition.y * 0.015}px)`,
            bottom: "20%",
            left: "20%",
          }}
        />
      </div>

      {/* Navigation Header */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-b border-gray-100 transition-all duration-300">
        <div className="container mx-auto px-4 py-2 md:py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <a href="#hero" className="scroll-smooth">
              <Image
                src="/logo-art-house.png"
                alt="Art House Logo"
                width={140}
                height={70}
                className="h-12 md:h-16 w-auto"
              />
            </a>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-6">
            <a href="#hero" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
              Home
            </a>
            <a href="#produtos" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
              Produtos
            </a>
            <a href="#catalogos" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
              Catálogos
            </a>
            <a href="#vantagens" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
              Vantagens
            </a>
            <Link href="/sobre" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
              Sobre
            </Link>
            <Link href="/contato" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium text-lg">
              Contato
            </Link>
            <a
              href="https://wa.me/5561986792057"
              target="_blank"
              className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-8 py-3 text-lg rounded-full font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
              rel="noreferrer"
            >
              💬 WhatsApp
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            aria-label="Menu"
          >
            <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100">
            <div className="px-4 py-2 space-y-1">
              <a
                href="#hero"
                className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Home
              </a>
              <a
                href="#produtos"
                className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Produtos
              </a>
              <a
                href="#catalogos"
                className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Catálogos
              </a>
              <a
                href="#vantagens"
                className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Vantagens
              </a>
              <Link
                href="/sobre"
                className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Sobre
              </Link>
              <Link
                href="/contato"
                className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors text-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contato
              </Link>
              <a
                href="https://wa.me/5561986792057"
                target="_blank"
                className="block mx-3 my-2 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-4 py-2 rounded-lg font-semibold text-center"
                rel="noreferrer"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                💬 WhatsApp
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 z-0">
          <video autoPlay loop muted playsInline className="w-full h-full object-cover">
            <source src="/hero-video.mp4" type="video/mp4" />
            {/* Fallback para navegadores que não suportam vídeo */}
            <Image
              src="/hero-cover.jpeg"
              alt="Revestimento vinílico de alta qualidade"
              fill
              className="object-cover"
              priority
            />
          </video>
          <div className="absolute inset-0 bg-black/60"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
        </div>

        {/* Floating Particles */}
        <div className="absolute inset-0 z-10">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-white/20 rounded-full animate-float-particle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${3 + Math.random() * 4}s`,
              }}
            />
          ))}
        </div>

        <div className="relative z-20 container mx-auto px-4 text-white text-center max-w-5xl pt-16 md:pt-20 pb-16">
          <div className="animate-fade-in-up">
            <h1 className="font-montserrat font-bold text-2xl md:text-5xl lg:text-6xl leading-tight mb-4 md:mb-8 bg-gradient-to-r from-white via-gray-100 to-white bg-clip-text text-transparent hero-title mt-10 md:mt-0">
              Papéis de Parede Vinílicos:
              <br />
              3x mais durável que pintura.
            </h1>

            <h2 className="font-roboto font-light text-lg md:text-2xl leading-relaxed mb-6 md:mb-12 text-gray-200 animate-fade-in-up animation-delay-200">
              Paredes sempre impecáveis: revestimento lavável de alta durabilidade, instalação rápida sem bagunça, com a
              qualidade de quem tem 25 anos de experiência.
            </h2>

            <div className="flex flex-col md:flex-row gap-4 md:gap-6 justify-center items-center animate-fade-in-up animation-delay-400">
              <a
                href="#catalogos"
                className="group bg-white/10 backdrop-blur-sm text-white px-8 py-4 md:px-10 md:py-5 rounded-2xl font-montserrat font-semibold text-base md:text-lg border-2 border-white/30 hover:bg-white hover:text-gray-800 transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 w-full md:w-auto"
              >
                📖 Ver Catálogos
              </a>
              <a
                href="#formulario"
                className="group bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-8 py-4 md:px-10 md:py-5 rounded-2xl font-montserrat font-semibold text-base md:text-lg inline-flex items-center justify-center gap-3 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 relative overflow-hidden w-full md:w-auto"
                rel="noreferrer"
              >
                <span className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
                <span className="relative">💬 Orçamento Gratuito</span>
              </a>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20 hidden md:block">
          <div className="animate-bounce">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </div>
      </section>

      {/* Produtos Section */}
      <section
        id="produtos"
        className="py-16 md:py-24 bg-gradient-to-br from-[#F5F5F5] via-white to-[#F5F5F5] relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#1B5E3A]/5 to-transparent"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12 md:mb-16 animate-fade-in-up">
            <h2 className="font-montserrat font-bold text-3xl md:text-5xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-4 md:mb-6 leading-tight">
              Mais do que lisos: decorativos e personalizados que expressam seu estilo.
            </h2>
            <p className="text-lg md:text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
              Descubra nossa coleção completa: desde padrões sofisticados até projetos únicos criados especialmente para
              você
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-12 md:mb-16">
            {[
              {
                icon: "🎨",
                gradient: "from-purple-500 to-pink-500",
                title: "Padrões Exclusivos",
                subtitle: "Designs únicos e sofisticados",
                description:
                  "Madeira natural, tijolinho rústico, mármore elegante, geométricos modernos e texturas premium que transformam qualquer ambiente.",
              },
              {
                icon: "✨",
                gradient: "from-blue-500 to-cyan-500",
                title: "Projetos Personalizados",
                subtitle: "Criações únicas para você",
                description:
                  "Desenvolvemos papéis de parede únicos em vinil adesivo ou papel texturizado. Perfeito para quartos infantis temáticos, logotipos empresariais, murais fotográficos e projetos especiais.",
              },
              {
                icon: "🏆",
                gradient: "from-green-500 to-emerald-500",
                title: "Qualidade Premium",
                subtitle: "25 anos de experiência",
                description:
                  "Materiais de alta qualidade, impressão em alta resolução e acabamento impecável. Cada projeto é tratado com o cuidado e atenção aos detalhes que você merece.",
              },
            ].map((product, index) => (
              <div
                key={index}
                className="group p-6 md:p-8 bg-white rounded-3xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-500 hover:-translate-y-2"
              >
                {/* Icon - Centered */}
                <div className="flex justify-center mb-4 md:mb-6">
                  <div
                    className={`w-14 h-14 md:w-16 md:h-16 bg-gradient-to-r ${product.gradient} rounded-2xl flex items-center justify-center text-2xl md:text-3xl transform group-hover:scale-110 transition-transform duration-300`}
                  >
                    {product.icon}
                  </div>
                </div>

                {/* Title */}
                <h3 className="font-montserrat font-bold text-xl md:text-2xl text-[#1B5E3A] text-center mb-2">
                  {product.title}
                </h3>

                {/* Subtitle */}
                <p className="text-gray-600 text-center mb-4 md:mb-6 text-sm md:text-base">{product.subtitle}</p>

                {/* Description */}
                <p className="font-roboto text-base md:text-lg text-gray-700 leading-relaxed text-center">
                  {product.description}
                </p>
              </div>
            ))}
          </div>

          <div className="animate-fade-in-up relative">
            <div className="relative overflow-hidden rounded-3xl shadow-2xl">
              <div className="relative w-full aspect-[3/2] md:aspect-[3/2]">
                {carouselImages.map((image, index) => (
                  <div
                    key={index}
                    className={`absolute inset-0 transition-all duration-1000 transform ${
                      currentSlide === index ? "opacity-100 scale-100" : "opacity-0 scale-110"
                    }`}
                  >
                    <Image src={image.src || "/placeholder.svg"} alt={image.alt} fill className="object-cover" />
                  </div>
                ))}
              </div>

              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>

              {/* Image Counter */}
              <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-medium">
                {currentSlide + 1} / {carouselImages.length}
              </div>

              {/* Navigation Arrows - Desktop Only */}
              <button
                onClick={() => setCurrentSlide((prev) => (prev === 0 ? carouselImages.length - 1 : prev - 1))}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white w-12 h-12 rounded-full flex items-center justify-center backdrop-blur-sm transition-all duration-300 hidden md:flex"
                aria-label="Slide anterior"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>

              <button
                onClick={() => setCurrentSlide((prev) => (prev === carouselImages.length - 1 ? 0 : prev + 1))}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white w-12 h-12 rounded-full flex items-center justify-center backdrop-blur-sm transition-all duration-300 hidden md:flex"
                aria-label="Próximo slide"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>

            <div className="flex justify-center mt-6 md:mt-8 gap-3">
              {carouselImages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-3 h-3 md:w-4 md:h-4 rounded-full transition-all duration-300 ${
                    currentSlide === index ? "bg-[#1B5E3A] scale-125" : "bg-gray-300 hover:bg-gray-400"
                  }`}
                  aria-label={`Ir para slide ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Catálogos Section */}
      <section id="catalogos" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-white via-gray-50 to-white"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-20 animate-fade-in-up">
            <h2 className="font-montserrat font-bold text-4xl md:text-5xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-6">
              Nossos Catálogos
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore nossa ampla variedade de papéis de parede. Clique em cada categoria para ver o catálogo completo
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {catalogos.map((catalogo, index) => (
              <Link
                key={index}
                href={catalogo.link}
                className="group animate-fade-in-up cursor-pointer"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-4 border border-gray-100 overflow-hidden h-full">
                  {/* Image Header */}
                  <div className="relative h-48 overflow-hidden">
                    <Image
                      src={catalogo.imagem || "/placeholder.svg"}
                      alt={`Catálogo ${catalogo.nome}`}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="font-montserrat font-bold text-2xl text-white mb-1">{catalogo.nome}</h3>
                      <p className="text-white/90 text-sm">{catalogo.descricao}</p>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <div className="w-full bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white py-3 rounded-xl font-semibold text-center transition-all duration-300 group-hover:shadow-lg">
                      📖 Ver Catálogo Completo
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-16 animate-fade-in-up">
            <p className="text-lg text-gray-600 mb-8">
              Não encontrou o que procura? Criamos projetos personalizados sob medida!
            </p>
            <a
              href="https://wa.me/5561986792057"
              target="_blank"
              className="group bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-10 py-4 rounded-2xl font-montserrat font-semibold text-lg inline-flex items-center gap-3 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 relative overflow-hidden"
              rel="noreferrer"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
              <span className="relative">💬 Solicitar Projeto Personalizado</span>
            </a>
          </div>
        </div>
      </section>

      {/* Vantagens Section */}
      <section
        id="vantagens"
        className="py-16 md:py-24 bg-gradient-to-br from-[#F5F5F5] via-white to-[#F5F5F5] relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#1B5E3A]/5 to-transparent"></div>

        <div className="container mx-auto px-4 relative z-10">
          {/* Benefícios */}
          <div className="mb-16 md:mb-24">
            <div className="text-center mb-12 md:mb-20 animate-fade-in-up">
              <h2 className="font-montserrat font-bold text-3xl md:text-5xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-4 md:mb-6">
                Por que escolher nosso papel de parede?
              </h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                Descubra as vantagens que fazem toda a diferença na sua decoração
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {[
                {
                  icon: "✓",
                  title: "Durabilidade 3X",
                  desc: "Até 10 anos de vida útil sem retoques.",
                  gradient: "from-green-400 to-emerald-600",
                },
                {
                  icon: "🧽",
                  title: "Lavável",
                  desc: "Limpeza fácil com pano úmido.",
                  gradient: "from-blue-400 to-cyan-600",
                },
                {
                  icon: "⚡",
                  title: "Instalação Sem Bagunça",
                  desc: "Ambiente pronto em horas, sem cheiro de tinta.",
                  gradient: "from-yellow-400 to-orange-600",
                },
                {
                  icon: "🏠",
                  title: "Conforto Imediato",
                  desc: "Use o espaço no mesmo dia.",
                  gradient: "from-purple-400 to-pink-600",
                },
                {
                  icon: "👥",
                  title: "Equipe Própria",
                  desc: "Instaladores profissionais com garantia.",
                  gradient: "from-indigo-400 to-blue-600",
                },
                {
                  icon: "⭐",
                  title: "25 Anos de Excelência",
                  desc: "Nota 5.0 no Google.",
                  gradient: "from-red-400 to-pink-600",
                },
              ].map((benefit, index) => (
                <div key={index} className="group animate-fade-in-up" style={{ animationDelay: `${index * 100}ms` }}>
                  <div className="text-center p-6 md:p-8 rounded-3xl bg-white shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-4 border border-gray-100 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-white opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                    <div
                      className={`w-16 h-16 md:w-20 md:h-20 bg-gradient-to-r ${benefit.gradient} rounded-2xl flex items-center justify-center mx-auto mb-4 md:mb-6 text-white text-2xl md:text-3xl shadow-lg transform transition-all duration-500 group-hover:scale-110 group-hover:rotate-12 relative z-10`}
                    >
                      {benefit.icon}
                    </div>

                    <h3 className="font-montserrat font-bold text-xl md:text-2xl text-[#1B5E3A] mb-3 md:mb-4 relative z-10">
                      {benefit.title}
                    </h3>
                    <p className="text-gray-600 text-base md:text-lg leading-relaxed relative z-10">{benefit.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Comparativo */}
          <div>
            <div className="text-center mb-12 md:mb-20 animate-fade-in-up">
              <h2 className="font-montserrat font-bold text-3xl md:text-5xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-4 md:mb-6">
                Comparativo: Pintura vs Papel de Parede
              </h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                Veja por que o papel de parede é a melhor escolha
              </p>
            </div>

            {/* Desktop Table - Redesigned */}
            <div className="hidden lg:block animate-fade-in-up animation-delay-200">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                {[
                  {
                    aspect: "Durabilidade",
                    traditional: "~3-5 anos antes de precisar repintar.",
                    vinyl: "Até 10 anos sem perder a qualidade.",
                    icon: "⏰",
                    color: "from-red-500 to-pink-500",
                  },
                  {
                    aspect: "Manutenção",
                    traditional: "Dificulta limpeza; manchas e retoques frequentes.",
                    vinyl: "Superfície lavável: pano úmido basta.",
                    icon: "🧽",
                    color: "from-blue-500 to-cyan-500",
                  },
                  {
                    aspect: "Instalação",
                    traditional: "Obra demorada, sujeira e cheiro forte.",
                    vinyl: "Aplicação rápida, limpa e sem cheiro.",
                    icon: "🔨",
                    color: "from-yellow-500 to-orange-500",
                  },
                  {
                    aspect: "Variedade",
                    traditional: "Cores limitadas.",
                    vinyl: "Design ilimitado e texturas premium.",
                    icon: "🎨",
                    color: "from-purple-500 to-indigo-500",
                  },
                  {
                    aspect: "Conforto",
                    traditional: "Interrompe rotina.",
                    vinyl: "Use o ambiente no mesmo dia.",
                    icon: "🏠",
                    color: "from-green-500 to-emerald-500",
                  },
                  {
                    aspect: "Custo-benefício",
                    traditional: "Mais barata só no início.",
                    vinyl: "Economia no longo prazo.",
                    icon: "💰",
                    color: "from-amber-500 to-yellow-500",
                  },
                ].map((row, index) => (
                  <div key={index} className="group">
                    <div className="bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 border border-gray-100 overflow-hidden">
                      {/* Header */}
                      <div className={`bg-gradient-to-r ${row.color} p-6 text-white`}>
                        <div className="flex items-center gap-4">
                          <div className="text-3xl">{row.icon}</div>
                          <h3 className="font-montserrat font-bold text-xl">{row.aspect}</h3>
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-6 space-y-6">
                        {/* Pintura Tradicional */}
                        <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded-r-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-red-600 font-bold">❌</span>
                            <h4 className="font-semibold text-red-800">Pintura Tradicional</h4>
                          </div>
                          <p className="text-red-700 text-sm">{row.traditional}</p>
                        </div>

                        {/* Papel de Parede */}
                        <div className="bg-green-50 border-l-4 border-green-400 p-4 rounded-r-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-green-600 font-bold">✅</span>
                            <h4 className="font-semibold text-green-800">Papel de Parede</h4>
                          </div>
                          <p className="text-green-700 font-medium text-sm">{row.vinyl}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Summary Card */}
              <div className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-3xl p-8 text-white text-center">
                <h3 className="font-montserrat font-bold text-2xl mb-4">🏆 Resultado Final</h3>
                <p className="text-xl mb-6">
                  Papel de parede vence em TODOS os aspectos! Mais durável, prático e econômico no longo prazo.
                </p>
                <a
                  href="https://wa.me/5561986792057"
                  target="_blank"
                  className="inline-flex items-center gap-2 bg-white text-[#1B5E3A] px-8 py-3 rounded-full font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                  rel="noreferrer"
                >
                  💬 Fazer Orçamento Agora
                </a>
              </div>
            </div>

            {/* Mobile Cards */}
            <div className="lg:hidden space-y-4 md:space-y-6 animate-fade-in-up animation-delay-200">
              {[
                {
                  aspect: "Durabilidade",
                  traditional: "~3-5 anos antes de precisar repintar.",
                  vinyl: "Até 10 anos sem perder a qualidade.",
                  icon: "⏰",
                },
                {
                  aspect: "Manutenção",
                  traditional: "Dificulta limpeza; manchas e retoques frequentes.",
                  vinyl: "Superfície lavável: pano úmido basta.",
                  icon: "🧽",
                },
                {
                  aspect: "Instalação",
                  traditional: "Obra demorada, sujeira e cheiro forte.",
                  vinyl: "Aplicação rápida, limpa e sem cheiro.",
                  icon: "🔨",
                },
                {
                  aspect: "Variedade",
                  traditional: "Cores limitadas.",
                  vinyl: "Design ilimitado e texturas premium.",
                  icon: "🎨",
                },
                {
                  aspect: "Conforto",
                  traditional: "Interrompe rotina.",
                  vinyl: "Use o ambiente no mesmo dia.",
                  icon: "🏠",
                },
                {
                  aspect: "Custo-benefício",
                  traditional: "Mais barata só no início.",
                  vinyl: "Economia no longo prazo.",
                  icon: "💰",
                },
              ].map((row, index) => (
                <div key={index} className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
                  <div className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] p-4">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{row.icon}</span>
                      <h3 className="font-montserrat font-bold text-lg md:text-xl text-white">{row.aspect}</h3>
                    </div>
                  </div>

                  <div className="p-4 md:p-6 space-y-3 md:space-y-4">
                    <div className="bg-red-50 border-l-4 border-red-400 p-3 md:p-4 rounded-r-lg">
                      <h4 className="font-semibold text-red-800 mb-1 md:mb-2 text-sm md:text-base">
                        ❌ Pintura Tradicional
                      </h4>
                      <p className="text-red-700 text-sm md:text-base">{row.traditional}</p>
                    </div>

                    <div className="bg-green-50 border-l-4 border-green-400 p-3 md:p-4 rounded-r-lg">
                      <h4 className="font-semibold text-green-800 mb-1 md:mb-2 text-sm md:text-base">
                        ✅ Papel de Parede
                      </h4>
                      <p className="text-green-700 font-medium text-sm md:text-base">{row.vinyl}</p>
                    </div>
                  </div>
                </div>
              ))}

              {/* Mobile Summary Card */}
              <div className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-3xl p-6 md:p-8 text-white text-center mt-6">
                <h3 className="font-montserrat font-bold text-xl md:text-2xl mb-3 md:mb-4">🏆 Resultado Final</h3>
                <p className="text-lg md:text-xl mb-4 md:mb-6">
                  Papel de parede vence em TODOS os aspectos! Mais durável, prático e econômico no longo prazo.
                </p>
                <a
                  href="https://wa.me/5561986792057"
                  target="_blank"
                  className="inline-flex items-center gap-2 bg-white text-[#1B5E3A] px-6 md:px-8 py-3 rounded-full font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105 text-sm md:text-base"
                  rel="noreferrer"
                >
                  💬 Fazer Orçamento Agora
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section id="depoimentos" className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-white via-gray-50 to-white"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-20 animate-fade-in-up">
            <h2 className="font-montserrat font-bold text-4xl md:text-5xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-6">
              O que nossos clientes dizem
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Mais de 100 clientes satisfeitos com nota 5.0 no Google
            </p>
          </div>

          <div className="max-w-4xl mx-auto animate-fade-in-up animation-delay-200">
            <div className="relative">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className={`transition-all duration-1000 ${
                    currentTestimonial === index
                      ? "opacity-100 transform translate-x-0"
                      : "opacity-0 transform translate-x-full absolute inset-0"
                  }`}
                >
                  <div className="bg-white p-6 md:p-12 rounded-3xl shadow-2xl border border-gray-100 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-[#1B5E3A]/5 to-transparent opacity-50"></div>

                    <div className="flex justify-center mb-4 md:mb-6 relative z-10">
                      <div className="flex text-yellow-400 text-2xl md:text-3xl">
                        <span>⭐⭐⭐⭐⭐</span>
                      </div>
                    </div>

                    <p className="text-lg md:text-2xl text-gray-700 mb-6 md:mb-8 italic leading-relaxed font-light relative z-10 text-center px-2">
                      "{testimonial.text}"
                    </p>

                    {/* Author with Photo */}
                    <div className="flex items-center justify-center gap-3 md:gap-4 relative z-10">
                      <div className="relative">
                        <Image
                          src={testimonial.photo || "/placeholder.svg"}
                          alt={`Foto de ${testimonial.author}`}
                          width={60}
                          height={60}
                          className="md:w-20 md:h-20 rounded-full border-4 border-[#1B5E3A]/20 shadow-lg"
                        />
                        <div className="absolute -bottom-1 -right-1 bg-green-500 text-white rounded-full p-1">
                          <svg className="w-3 h-3 md:w-4 md:h-4" fill="currentColor" viewBox="0 0 20 20">
                            <path
                              fillRule="evenodd"
                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </div>
                      </div>
                      <div className="text-center">
                        <p className="font-montserrat font-bold text-lg md:text-xl text-[#1B5E3A]">
                          {testimonial.author}
                        </p>
                        <p className="text-xs md:text-sm text-gray-500 flex items-center gap-1">
                          <span className="text-green-500">✓</span>
                          Cliente verificado
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-center mt-8 md:mt-12 gap-3 md:gap-4">
              {[0, 1, 2, 3, 4].map((index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 md:w-4 md:h-4 rounded-full transition-all duration-300 ${
                    currentTestimonial === index ? "bg-[#1B5E3A] scale-125" : "bg-gray-300 hover:bg-gray-400"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Formulário de Contato */}
      <section
        id="formulario"
        className="py-16 md:py-24 bg-gradient-to-br from-[#F5F5F5] via-white to-[#F5F5F5] relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#1B5E3A]/5 to-transparent"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-start max-w-7xl mx-auto">
            <div className="animate-fade-in-up order-2 lg:order-1">
              <div className="bg-white p-6 md:p-10 rounded-3xl shadow-2xl border border-gray-100 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-[#1B5E3A]/5 to-transparent opacity-50"></div>

                <h2 className="font-montserrat font-bold text-3xl md:text-4xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-6 md:mb-8 relative z-10">
                  Fale Conosco & Ganhe 5% OFF
                </h2>

                <form id="contactForm" onSubmit={handleFormSubmit} className="space-y-4 md:space-y-6 relative z-10">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                    <div>
                      <label htmlFor="nome" className="block text-sm font-semibold text-gray-700 mb-2 md:mb-3">
                        Nome Completo
                      </label>
                      <input
                        type="text"
                        id="nome"
                        name="nome"
                        required
                        disabled={isSubmitting}
                        className="w-full px-4 py-3 md:px-6 md:py-4 border-2 border-gray-200 rounded-2xl focus:ring-2 focus:ring-[#1B5E3A] focus:border-transparent transition-all duration-300 text-base md:text-lg disabled:opacity-50"
                        placeholder="Seu nome completo"
                      />
                    </div>

                    <div>
                      <label htmlFor="whatsapp" className="block text-sm font-semibold text-gray-700 mb-2 md:mb-3">
                        WhatsApp
                      </label>
                      <input
                        type="tel"
                        id="whatsapp"
                        name="whatsapp"
                        required
                        disabled={isSubmitting}
                        className="w-full px-4 py-3 md:px-6 md:py-4 border-2 border-gray-200 rounded-2xl focus:ring-2 focus:ring-[#1B5E3A] focus:border-transparent transition-all duration-300 text-base md:text-lg disabled:opacity-50"
                        placeholder="(61) 99999-9999"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2 md:mb-3">
                      E-mail
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      disabled={isSubmitting}
                      className="w-full px-4 py-3 md:px-6 md:py-4 border-2 border-gray-200 rounded-2xl focus:ring-2 focus:ring-[#1B5E3A] focus:border-transparent transition-all duration-300 text-base md:text-lg disabled:opacity-50"
                      placeholder="seu@email.com"
                    />
                  </div>

                  <div>
                    <label htmlFor="interesse" className="block text-sm font-semibold text-gray-700 mb-2 md:mb-3">
                      O que mais te atrai em papel de parede? (Opcional)
                    </label>
                    <textarea
                      id="interesse"
                      name="interesse"
                      rows={4}
                      disabled={isSubmitting}
                      className="w-full px-4 py-3 md:px-6 md:py-4 border-2 border-gray-200 rounded-2xl focus:ring-2 focus:ring-[#1B5E3A] focus:border-transparent transition-all duration-300 text-base md:text-lg resize-none disabled:opacity-50"
                      placeholder="Conte-nos sobre seu projeto..."
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white py-4 md:py-6 rounded-2xl font-montserrat font-semibold text-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-xl"
                  >
                    {isSubmitting ? "Enviando..." : "Solicitar Orçamento Gratuito"}
                  </button>
                </form>
              </div>
            </div>

            <div className="animate-fade-in-up order-1 lg:order-2">
              <div className="text-center lg:text-left">
                <h2 className="font-montserrat font-bold text-3xl md:text-4xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-6 md:mb-8">
                  Transforme seu espaço com a Art House
                </h2>
                <p className="text-lg md:text-xl text-gray-600 mb-8 md:mb-12">
                  Está pronto para dar vida nova às suas paredes? Nossa equipe está à disposição para entender suas
                  necessidades e oferecer a melhor solução em papéis de parede.
                </p>

                <div className="space-y-4 md:space-y-6">
                  <div className="flex items-center gap-4 md:gap-6">
                    <div className="w-12 h-12 md:w-14 md:h-14 bg-[#1B5E3A]/10 rounded-2xl flex items-center justify-center text-[#1B5E3A] text-2xl md:text-3xl">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-7 w-7 md:h-8 md:w-8"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.892a2 2 0 01-2.284 3.425l-1.337-1.245a.25.25 0 00-.178-.085H5a2 2 0 01-2-2v-2zM3 14a2 2 0 012-2h5.632a1 1 0 01.948.684l1.498 4.892a2 2 0 01-2.284 3.425l-1.337-1.245a.25.25 0 00-.178-.085H5a2 2 0 01-2-2v-2z"
                        />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-montserrat font-bold text-xl md:text-2xl text-[#1B5E3A] mb-1">
                        Atendimento Personalizado
                      </h3>
                      <p className="text-gray-600 text-base md:text-lg">
                        Entendemos suas necessidades e oferecemos soluções sob medida.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 md:gap-6">
                    <div className="w-12 h-12 md:w-14 md:h-14 bg-[#1B5E3A]/10 rounded-2xl flex items-center justify-center text-[#1B5E3A] text-2xl md:text-3xl">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-7 w-7 md:h-8 md:w-8"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"
                        />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-montserrat font-bold text-xl md:text-2xl text-[#1B5E3A] mb-1">
                        Instalação Profissional
                      </h3>
                      <p className="text-gray-600 text-base md:text-lg">
                        Nossa equipe garante um acabamento impecável e duradouro.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 md:gap-6">
                    <div className="w-12 h-12 md:w-14 md:h-14 bg-[#1B5E3A]/10 rounded-2xl flex items-center justify-center text-[#1B5E3A] text-2xl md:text-3xl">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-7 w-7 md:h-8 md:w-8"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8m0 0l-8 5m8-5v13a2 2 0 01-2 2H5a2 2 0 01-2-2V3m2 5l8-5"
                        />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-montserrat font-bold text-xl md:text-2xl text-[#1B5E3A] mb-1">
                        Suporte Contínuo
                      </h3>
                      <p className="text-gray-600 text-base md:text-lg">
                        Estamos sempre à disposição para tirar suas dúvidas e oferecer assistência.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 md:py-16 border-t border-gray-100">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Logo & Description */}
            <div className="md:col-span-1">
              <div className="flex items-center mb-4">
                <Image
                  src="/logo-art-house.png"
                  alt="Art House Logo"
                  width={140}
                  height={70}
                  className="h-12 md:h-16 w-auto"
                />
              </div>
              <p className="text-gray-600 text-base md:text-lg leading-relaxed">
                Art House - Papéis de Parede Vinílicos. Transforme seu espaço com qualidade e design inovador.
              </p>
            </div>

            {/* Quick Links */}
            <div className="md:col-span-1">
              <h4 className="font-montserrat font-bold text-xl text-[#1B5E3A] mb-4">Links Rápidos</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#hero" className="text-gray-600 hover:text-[#1B5E3A] transition-colors">
                    Home
                  </a>
                </li>
                <li>
                  <a href="#produtos" className="text-gray-600 hover:text-[#1B5E3A] transition-colors">
                    Produtos
                  </a>
                </li>
                <li>
                  <a href="#catalogos" className="text-gray-600 hover:text-[#1B5E3A] transition-colors">
                    Catálogos
                  </a>
                </li>
                <li>
                  <a href="#vantagens" className="text-gray-600 hover:text-[#1B5E3A] transition-colors">
                    Vantagens
                  </a>
                </li>
                <li>
                  <Link href="/sobre" className="text-gray-600 hover:text-[#1B5E3A] transition-colors">
                    Sobre Nós
                  </Link>
                </li>
                <li>
                  <Link href="/contato" className="text-gray-600 hover:text-[#1B5E3A] transition-colors">
                    Contato
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact Information */}
            <div className="md:col-span-1">
              <h4 className="font-montserrat font-bold text-xl text-[#1B5E3A] mb-4">Contato</h4>
              <p className="text-gray-600 text-base md:text-lg">
                <span className="font-semibold">Telefone:</span> (61) 98679-2057
              </p>
              <p className="text-gray-600 text-base md:text-lg">
                <span className="font-semibold">Email:</span> contato@arthouse.com.br
              </p>
              <p className="text-gray-600 text-base md:text-lg">
                <span className="font-semibold">Endereço:</span> SIA Centro Empresarial
              </p>
            </div>
          </div>

          {/* Copyright */}
          <div className="mt-12 pt-8 border-t border-gray-100 text-center">
            <p className="text-gray-500 text-sm">
              &copy; {new Date().getFullYear()} Art House. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>

      {/* Sticky WhatsApp Button */}
      <a
        href="https://wa.me/5561986792057"
        target="_blank"
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg transition-all duration-300 transform hover:scale-110 z-50"
        rel="noreferrer"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor">
          <path
            fillRule="evenodd"
            d="M18 5.753a8.247 8.247 0 00-14.835-3.14l-.584.972a.5.5 0 01-.743.24l-1.145-.687a.5.5 0 01-.146-.668l.972-.584A8.247 8.247 0 002 14.247a8.247 8.247 0 0014.835 3.14l.584-.972a.5.5 0 01.743-.24l1.145.687a.5.5 0 01.146.668l-.972.584A8.247 8.247 0 0018 5.753zM8.5 14.5a.5.5 0 00.5-.5v-3a.5.5 0 00-.5-.5H6a.5.5 0 00-.5.5v3a.5.5 0 00.5.5h2.5zm5 0a.5.5 0 00.5-.5v-3a.5.5 0 00-.5-.5h-2.5a.5.5 0 00-.5.5v3a.5.5 0 00.5.5h2.5z"
            clipRule="evenodd"
          />
        </svg>
      </a>
    </div>
  )
}
