"use client"
import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight, X, Menu } from "lucide-react"

export default function CatalogoPersonalizados() {
  const [imageError, setImageError] = useState<{ [key: number]: boolean }>({})
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const catalogImages = [
    {
      id: 1,
      src: "/catalog-images/personalizados-1.png",
      alt: "Papel de parede personalizado tema aviação para home office",
      title: "Tema Aviação",
      subtitle: "Home Office",
      description:
        "Papel de parede personalizado simulando janelas de avião com vista aérea. Perfeito para escritórios e ambientes de trabalho.",
      category: "Profissional",
      ambiente: "Escritório",
    },
    {
      id: 2,
      src: "/catalog-images/personalizados-2.png",
      alt: "Papel de parede personalizado com galhos e flores delicadas",
      title: "Galhos Florais",
      subtitle: "Design Delicado",
      description:
        "Design suave com galhos pendentes, folhas verdes e flores rosa. Ideal para quartos e ambientes relaxantes.",
      category: "Floral",
      ambiente: "Quarto",
    },
    {
      id: 3,
      src: "/catalog-images/personalizados-3.png",
      alt: "Papel de parede personalizado tropical com tucanos e palmeiras",
      title: "Tropical Vibrante",
      subtitle: "Tucanos e Palmeiras",
      description:
        "Papel de parede tropical com tucanos, palmeiras e flores exóticas em cores vivas. Perfeito para salas de jantar.",
      category: "Tropical",
      ambiente: "Sala de Jantar",
    },
    {
      id: 4,
      src: "/catalog-images/personalizados-4.png",
      alt: "Papel de parede personalizado jungle com palmeiras",
      title: "Jungle Elegante",
      subtitle: "Folhagens Naturais",
      description:
        "Design tropical sofisticado com palmeiras e folhagens em tons naturais. Ideal para ambientes sociais.",
      category: "Tropical",
      ambiente: "Sala de Jantar",
    },
    {
      id: 5,
      src: "/catalog-images/personalizados-5.png",
      alt: "Papel de parede personalizado infantil com cerejeira e borboletas",
      title: "Cerejeira Infantil",
      subtitle: "Tema Feminino",
      description:
        "Tema delicado com galhos de cerejeira, flores rosa, borboletas e casinha de passarinho. Perfeito para quartos infantis femininos.",
      category: "Infantil",
      ambiente: "Quarto Infantil",
    },
    {
      id: 6,
      src: "/catalog-images/personalizados-6.png",
      alt: "Papel de parede personalizado tema espacial com foguetes",
      title: "Aventura Espacial",
      subtitle: "Tema Masculino",
      description:
        "Tema espacial com foguetes, astronauta, estrelas e planetas. Ideal para quartos infantis masculinos.",
      category: "Infantil",
      ambiente: "Quarto Infantil",
    },
    {
      id: 7,
      src: "/catalog-images/personalizados-7.png",
      alt: "Papel de parede personalizado com montanhas em degradê",
      title: "Montanhas Serenas",
      subtitle: "Paisagem Tranquila",
      description: "Paisagem de montanhas em degradê azul e cinza, criando ambiente tranquilo e contemplativo.",
      category: "Paisagem",
      ambiente: "Quarto",
    },
    {
      id: 8,
      src: "/catalog-images/personalizados-8.png",
      alt: "Papel de parede personalizado floral vertical elegante",
      title: "Floral Vertical",
      subtitle: "Elegância Clássica",
      description:
        "Padrão floral vertical com flores em tons coral e laranja. Perfeito para quartos adultos sofisticados.",
      category: "Floral",
      ambiente: "Quarto",
    },
    {
      id: 9,
      src: "/catalog-images/personalizados-9.png",
      alt: "Papel de parede personalizado espacial colorido com arco-íris",
      title: "Espaço Colorido",
      subtitle: "Tema Lúdico",
      description:
        "Tema espacial vibrante com planetas sorridentes, foguetes e arco-íris. Ideal para quartos infantis alegres.",
      category: "Infantil",
      ambiente: "Quarto Infantil",
    },
    {
      id: 10,
      src: "/catalog-images/personalizados-10.png",
      alt: "Papel de parede personalizado mapa-múndi educativo infantil",
      title: "Mapa-Múndi Educativo",
      subtitle: "Aprendizado Divertido",
      description:
        "Mapa-múndi educativo com animais, balões e aviões vintage. Perfeito para estimular a curiosidade infantil.",
      category: "Educativo",
      ambiente: "Quarto Infantil",
    },
    {
      id: 11,
      src: "/catalog-images/personalizados-11.png",
      alt: "Papel de parede personalizado aventura na natureza com ursinhos",
      title: "Aventura na Natureza",
      subtitle: "Ursinhos e Floresta",
      description: "Tema aventura com ursinhos, árvores, nuvens e cabana. Design suave em tons neutros e verdes.",
      category: "Infantil",
      ambiente: "Quarto Infantil",
    },
    {
      id: 12,
      src: "/catalog-images/personalizados-12.png",
      alt: "Papel de parede personalizado floresta brasileira com animais",
      title: "Floresta Brasileira",
      subtitle: "Fauna Nacional",
      description:
        "Tema educativo com animais da fauna brasileira: araras, tucanos, tamanduá, onça e vegetação tropical.",
      category: "Educativo",
      ambiente: "Quarto Infantil",
    },
    {
      id: 13,
      src: "/catalog-images/personalizados-13.png",
      alt: "Papel de parede personalizado floral bebê com borboletas",
      title: "Jardim do Bebê",
      subtitle: "Flores e Borboletas",
      description:
        "Design delicado com flores laranja, rosa e borboletas em tons pastéis. Perfeito para quartos de bebê.",
      category: "Bebê",
      ambiente: "Quarto Bebê",
    },
  ]

  const handleImageError = (index: number) => {
    setImageError((prev) => ({ ...prev, [index]: true }))
  }

  const openModal = (index: number) => {
    setSelectedImageIndex(index)
    document.body.style.overflow = "hidden"
  }

  const closeModal = () => {
    setSelectedImageIndex(null)
    document.body.style.overflow = "auto"
  }

  const nextImage = () => {
    if (selectedImageIndex !== null) {
      setSelectedImageIndex((selectedImageIndex + 1) % catalogImages.length)
    }
  }

  const prevImage = () => {
    if (selectedImageIndex !== null) {
      setSelectedImageIndex(selectedImageIndex === 0 ? catalogImages.length - 1 : selectedImageIndex - 1)
    }
  }

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (selectedImageIndex !== null) {
        if (e.key === "Escape") closeModal()
        if (e.key === "ArrowRight") nextImage()
        if (e.key === "ArrowLeft") prevImage()
      }
    }

    window.addEventListener("keydown", handleKeyPress)
    return () => window.removeEventListener("keydown", handleKeyPress)
  }, [selectedImageIndex])

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-gray-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4">
              <Image
                src="/logo-art-house.png"
                alt="Art House Logo"
                width={120}
                height={60}
                className="h-10 md:h-12 w-auto"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-6">
              <a href="/#catalogos" className="text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium">
                ← Voltar aos Catálogos
              </a>
              <a
                href="https://wa.me/5561986792057"
                target="_blank"
                className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-6 py-2 rounded-full font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                rel="noreferrer"
              >
                💬 WhatsApp
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
              aria-label="Menu"
            >
              <Menu className="w-6 h-6 text-gray-700" />
            </button>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden bg-white border-t border-gray-100 mt-3 pt-3">
              <div className="space-y-2">
                <a
                  href="/#catalogos"
                  className="block px-3 py-2 text-gray-700 hover:text-[#1B5E3A] hover:bg-gray-50 rounded-lg transition-colors"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  ← Voltar aos Catálogos
                </a>
                <a
                  href="https://wa.me/5561986792057"
                  target="_blank"
                  className="block mx-3 my-2 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-4 py-2 rounded-lg font-semibold text-center"
                  rel="noreferrer"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  💬 WhatsApp
                </a>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-8 md:py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-400/10 to-orange-400/10"></div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-16 h-16 md:w-20 md:h-20 bg-gradient-to-r from-red-400 to-red-600 rounded-3xl mb-6 md:mb-8 text-3xl md:text-4xl">
              🎨
            </div>

            <h1 className="font-montserrat font-bold text-3xl md:text-5xl lg:text-6xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-4 md:mb-6">
              Papéis Personalizados
            </h1>

            <p className="text-gray-500 text-base md:text-lg mb-6 md:mb-8 max-w-3xl mx-auto leading-relaxed">
              Não encontrou o que procura? Entre em contato no nosso WhatsApp, possuímos mais catálogos fora do site,
              além disso, também podemos fazer personalizados.
            </p>

            <div className="w-16 md:w-24 h-1 bg-gradient-to-r from-red-400 to-orange-400 mx-auto rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Special Info Section */}
      <section className="py-8 md:py-12 bg-gradient-to-r from-red-400/5 to-orange-400/5">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="font-montserrat font-bold text-2xl md:text-3xl text-[#1B5E3A] mb-4 md:mb-6">
              Crie Seu Projeto Único
            </h2>
            <p className="text-gray-600 text-base md:text-lg leading-relaxed mb-4 md:mb-6">
              Nossos papéis personalizados são criados especialmente para você! Desde quartos infantis temáticos até
              logotipos empresariais, murais fotográficos e projetos especiais.
            </p>
            <p className="text-gray-600 text-sm md:text-lg leading-relaxed mb-6 md:mb-8 bg-gradient-to-r from-red-50 to-orange-50 p-4 md:p-6 rounded-2xl border-l-4 border-red-400">
              <strong className="text-red-700">💡 Materiais disponíveis:</strong> Vinil adesivado (liso) ou papel de
              parede (textura). Ambos vinílicos e laváveis.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 text-center">
              <div className="p-4 md:p-6">
                <div className="text-3xl md:text-4xl mb-3 md:mb-4">🏢</div>
                <h3 className="font-semibold text-base md:text-lg mb-2">Empresarial</h3>
                <p className="text-gray-600 text-sm md:text-base">Logotipos e identidade visual</p>
              </div>
              <div className="p-4 md:p-6">
                <div className="text-3xl md:text-4xl mb-3 md:mb-4">🎭</div>
                <h3 className="font-semibold text-base md:text-lg mb-2">Temático</h3>
                <p className="text-gray-600 text-sm md:text-base">Quartos infantis e ambientes especiais</p>
              </div>
              <div className="p-4 md:p-6">
                <div className="text-3xl md:text-4xl mb-3 md:mb-4">📸</div>
                <h3 className="font-semibold text-base md:text-lg mb-2">Fotográfico</h3>
                <p className="text-gray-600 text-sm md:text-base">Murais e paisagens personalizadas</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Botões Catálogo Infantil */}
      <section className="py-8 md:py-12 bg-gradient-to-r from-red-400/5 to-orange-400/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-6 md:mb-8">
            <h3 className="font-montserrat font-bold text-xl md:text-2xl text-[#1B5E3A] mb-3 md:mb-4">
              Catálogos Infantis Especializados
            </h3>
            <p className="text-gray-600 text-sm md:text-base mb-4 md:mb-6">
              Confira nossos catálogos específicos para quartos infantis
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center items-center">
            <a
              href="https://drive.google.com/drive/folders/1LLXVwXfIVU89DFJo8EOBSNKaizY-gOuF"
              target="_blank"
              rel="noreferrer"
              className="w-full sm:w-auto group bg-gradient-to-r from-blue-200 to-blue-300 hover:from-blue-300 hover:to-blue-400 text-blue-800 px-6 md:px-8 py-3 md:py-4 rounded-2xl font-montserrat font-semibold text-base md:text-lg transition-all duration-300 transform hover:scale-105 hover:-translate-y-2 shadow-lg hover:shadow-xl text-center"
            >
              👦 Catálogo Infantil Masculino
            </a>
            <a
              href="https://drive.google.com/drive/folders/10otA0JpZXplWt8gW3rvB1lNTvDj5aREs"
              target="_blank"
              rel="noreferrer"
              className="w-full sm:w-auto group bg-gradient-to-r from-pink-200 to-pink-300 hover:from-pink-300 hover:to-pink-400 text-pink-800 px-6 md:px-8 py-3 md:py-4 rounded-2xl font-montserrat font-semibold text-base md:text-lg transition-all duration-300 transform hover:scale-105 hover:-translate-y-2 shadow-lg hover:shadow-xl text-center"
            >
              👧 Catálogo Infantil Feminino
            </a>
          </div>
        </div>
      </section>

      {/* Catalog Grid */}
      <section className="py-8 md:py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8 md:mb-12">
            <h2 className="font-montserrat font-bold text-2xl md:text-3xl text-[#1B5E3A] mb-3 md:mb-4">
              Exemplos de Projetos Realizados
            </h2>
            <p className="text-gray-600 text-sm md:text-base">
              Confira alguns dos projetos personalizados que já desenvolvemos
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-8">
            {catalogImages.map((image, index) => (
              <div
                key={image.id}
                className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 overflow-hidden border border-red-100 cursor-pointer"
                onClick={() => openModal(index)}
              >
                <div className="relative aspect-[16/9] overflow-hidden">
                  {!imageError[index] ? (
                    <Image
                      src={image.src || "/placeholder.svg"}
                      alt={image.alt}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                      onError={() => handleImageError(index)}
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-red-100 to-orange-100 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-3xl md:text-4xl mb-2">🎨</div>
                        <p className="text-gray-500 text-sm">{image.title}</p>
                      </div>
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-red-500/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                  <div className="absolute bottom-3 md:bottom-4 left-3 md:left-4 right-3 md:right-4 transform translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                    <h3 className="text-white font-semibold text-base md:text-lg mb-1 md:mb-2">{image.title}</h3>
                    <p className="text-white/90 text-xs md:text-sm mb-2">{image.subtitle}</p>
                    <button className="bg-white/20 backdrop-blur-sm text-white px-3 md:px-4 py-1.5 md:py-2 rounded-lg text-xs md:text-sm font-medium hover:bg-white/30 transition-colors">
                      Ver Detalhes
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Image Modal */}
      {selectedImageIndex !== null && (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-2 md:p-4">
          <div className="relative w-full h-full max-w-6xl flex flex-col">
            {/* Close Button */}
            <button
              onClick={closeModal}
              className="absolute top-2 md:top-4 right-2 md:right-4 z-10 text-white bg-black bg-opacity-50 hover:bg-opacity-75 rounded-full w-10 h-10 md:w-12 md:h-12 flex items-center justify-center transition-all duration-200 hover:scale-110"
            >
              <X className="w-5 h-5 md:w-6 md:h-6" />
            </button>

            {/* Navigation Arrows */}
            <button
              onClick={prevImage}
              className="absolute left-2 md:left-4 top-1/2 transform -translate-y-1/2 z-10 text-white bg-black bg-opacity-50 hover:bg-opacity-75 rounded-full w-10 h-10 md:w-12 md:h-12 flex items-center justify-center transition-all duration-200 hover:scale-110"
            >
              <ChevronLeft className="w-5 h-5 md:w-6 md:h-6" />
            </button>

            <button
              onClick={nextImage}
              className="absolute right-2 md:right-4 top-1/2 transform -translate-y-1/2 z-10 text-white bg-black bg-opacity-50 hover:bg-opacity-75 rounded-full w-10 h-10 md:w-12 md:h-12 flex items-center justify-center transition-all duration-200 hover:scale-110"
            >
              <ChevronRight className="w-5 h-5 md:w-6 md:h-6" />
            </button>

            {/* Image Container */}
            <div className="flex-1 flex items-center justify-center mb-4">
              <Image
                src={catalogImages[selectedImageIndex].src || "/placeholder.svg"}
                alt={catalogImages[selectedImageIndex].alt}
                width={1200}
                height={800}
                className="max-w-full max-h-[60vh] md:max-h-[70vh] object-contain rounded-lg"
                priority
              />
            </div>

            {/* Image Info */}
            <div className="bg-black bg-opacity-75 text-white p-4 md:p-6 rounded-lg mx-2 md:mx-0">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-3">
                <h3 className="font-bold text-lg md:text-xl mb-1 md:mb-0">{catalogImages[selectedImageIndex].title}</h3>
                <span className="text-sm md:text-base text-gray-300">
                  {selectedImageIndex + 1} / {catalogImages.length}
                </span>
              </div>
              <p className="text-sm md:text-base text-gray-200 mb-2">{catalogImages[selectedImageIndex].subtitle}</p>
              <p className="text-xs md:text-sm text-gray-300 mb-3">{catalogImages[selectedImageIndex].description}</p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-red-500/20 text-red-300 px-2 py-1 rounded text-xs">
                  {catalogImages[selectedImageIndex].category}
                </span>
                <span className="bg-blue-500/20 text-blue-300 px-2 py-1 rounded text-xs">
                  {catalogImages[selectedImageIndex].ambiente}
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-3">
                Use as setas ou toque nas laterais para navegar • ESC para fechar
              </p>
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <section className="py-8 md:py-16 bg-gradient-to-r from-red-400/10 to-orange-400/10">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="font-montserrat font-bold text-2xl md:text-3xl text-[#1B5E3A] mb-4 md:mb-6">
              Pronto para criar seu projeto único?
            </h2>
            <p className="text-gray-600 text-base md:text-lg mb-6 md:mb-8 leading-relaxed">
              Entre em contato conosco para discutir sua ideia e receber um orçamento personalizado. Nossa equipe está
              pronta para transformar sua visão em realidade!
            </p>
            <a
              href="https://wa.me/5561986792057"
              target="_blank"
              className="group inline-flex items-center gap-3 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-8 md:px-10 py-3 md:py-4 rounded-2xl font-montserrat font-semibold text-base md:text-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 relative overflow-hidden"
              rel="noreferrer"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
              <span className="relative">💬 Solicitar Orçamento Personalizado</span>
            </a>
          </div>
        </div>
      </section>

      {/* Floating Back Button - Mobile Only */}
      <a
        href="/#catalogos"
        className="fixed bottom-6 left-6 z-40 md:hidden bg-gradient-to-r from-gray-600 to-gray-700 text-white p-3 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 group"
      >
        <ChevronLeft className="w-5 h-5 group-hover:scale-110 transition-transform duration-300" />
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold">
          📖
        </div>
      </a>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/5561986792057"
        target="_blank"
        className="fixed bottom-6 right-6 z-40 bg-gradient-to-r from-green-500 to-green-600 text-white p-4 md:p-5 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 animate-pulse-slow group"
        rel="noreferrer"
      >
        <svg
          className="w-6 h-6 md:w-8 md:h-8 group-hover:scale-110 transition-transform duration-300"
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488" />
        </svg>
        <div className="absolute -top-2 -right-2 w-5 h-5 md:w-6 md:h-6 bg-red-500 rounded-full flex items-center justify-center text-xs font-bold animate-bounce">
          !
        </div>
      </a>
    </div>
  )
}
