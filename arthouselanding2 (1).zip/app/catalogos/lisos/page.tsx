"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Share2, Search, Filter, Eye, X, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import Header from "@/components/Header"
import { useState } from "react"

export default function CatalogoLisos() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedColor, setSelectedColor] = useState("Todas as Cores")
  const [selectedProduto, setSelectedProduto] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const produtos = [
    {
      id: 1,
      nome: "Liso Cinza Moderno CR333030R",
      modelos: [
        {
          codigo: "CR333030R",
          cor: "Cinza",
          descricao: "Liso cinza com textura sutil, perfeito para ambientes modernos e sofisticados",
        },
      ],
      cores: ["Cinza"],
      textura: "Lisa",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-1.jpg",
      descricao:
        "Papel de parede liso em tom cinza moderno, ideal para criar ambientes clean e contemporâneos. Textura suave que combina perfeitamente com móveis modernos.",
    },
    {
      id: 2,
      nome: "Liso Bege Natural CR333118R",
      modelos: [
        {
          codigo: "CR333118R",
          cor: "Bege",
          descricao: "Liso bege natural com acabamento premium, ideal para ambientes acolhedores",
        },
      ],
      cores: ["Bege"],
      textura: "Lisa",
      categoria: "Natural",
      imagem: "/catalog-images/lisos-2.jpg",
      descricao:
        "Papel de parede liso em tom bege natural, perfeito para criar ambientes aconchegantes e relaxantes. Combina harmoniosamente com decoração neutra.",
    },
    {
      id: 3,
      nome: "Coleção Lisos Tons Quentes",
      modelos: [
        { codigo: "CR333415R", cor: "Bege", descricao: "Liso bege claro suave" },
        { codigo: "CR333417R", cor: "Rosa", descricao: "Liso rosa claro delicado" },
        { codigo: "CR333418R", cor: "Vermelho", descricao: "Liso vermelho tijolo" },
        { codigo: "CR333414", cor: "Azul", descricao: "Liso azul acinzentado" },
      ],
      cores: ["Bege", "Rosa", "Vermelho", "Azul"],
      textura: "Lisa",
      categoria: "Colorido",
      imagem: "/catalog-images/lisos-3.jpg",
      descricao:
        "Coleção de papéis lisos em tons quentes e vibrantes. Inclui bege suave, rosa delicado, vermelho tijolo e azul acinzentado para ambientes modernos e acolhedores.",
    },
    {
      id: 4,
      nome: "Série SE050 - Texturas Naturais",
      modelos: [
        { codigo: "SE050601", cor: "Verde", descricao: "Textura natural verde musgo" },
        { codigo: "SE050604", cor: "Cinza", descricao: "Textura natural cinza pedra" },
        { codigo: "SE050612", cor: "Bege", descricao: "Textura natural bege areia" },
        { codigo: "SE050101", cor: "Cinza", descricao: "Textura lisa cinza claro" },
        { codigo: "SE050105", cor: "Bege", descricao: "Textura lisa bege natural" },
        { codigo: "SE050104", cor: "Cinza", descricao: "Textura lisa cinza médio" },
      ],
      cores: ["Verde", "Cinza", "Bege"],
      textura: "Texturizada",
      categoria: "Natural",
      imagem: "/catalog-images/lisos-4.jpg",
      descricao:
        "Série com texturas naturais que variam do verde musgo ao bege areia, passando por tons de cinza. Perfeita para ambientes que buscam conexão com a natureza.",
    },
    {
      id: 5,
      nome: "Linha SE050 - Tons Modernos",
      modelos: [
        { codigo: "SE050504", cor: "Azul", descricao: "Textura moderna azul marinho" },
        { codigo: "SE051203", cor: "Cinza", descricao: "Textura moderna cinza escuro" },
        { codigo: "SE051204", cor: "Bege", descricao: "Textura moderna bege claro" },
      ],
      cores: ["Azul", "Cinza", "Bege"],
      textura: "Moderna",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/lisos-5.jpg",
      descricao:
        "Linha moderna com texturas contemporâneas em azul marinho, cinza escuro e bege claro. Ideal para ambientes urbanos e sofisticados.",
    },
    {
      id: 6,
      nome: "Série GA097 - Tons Neutros Premium",
      modelos: [
        { codigo: "GA0973001R", cor: "Bege", descricao: "Premium bege claro" },
        { codigo: "GA0973002R", cor: "Cinza", descricao: "Premium cinza médio" },
        { codigo: "GA0973003R", cor: "Cinza", descricao: "Premium cinza escuro" },
      ],
      cores: ["Bege", "Cinza"],
      textura: "Premium",
      categoria: "Luxo",
      imagem: "/catalog-images/lisos-6.jpg",
      descricao:
        "Série premium com acabamento de alta qualidade em tons neutros. Do bege claro ao cinza escuro, perfeita para ambientes elegantes e minimalistas.",
    },
    {
      id: 7,
      nome: "Coleção GR401 - Gradação Cinza",
      modelos: [
        { codigo: "GR401703R", cor: "Cinza", descricao: "Cinza claro suave" },
        { codigo: "GR401702R", cor: "Cinza", descricao: "Cinza claro médio" },
        { codigo: "GR401701R", cor: "Cinza", descricao: "Cinza médio" },
        { codigo: "GR401803", cor: "Cinza", descricao: "Cinza médio escuro" },
        { codigo: "GR401802", cor: "Cinza", descricao: "Cinza escuro" },
        { codigo: "GR401708", cor: "Azul", descricao: "Azul acinzentado" },
        { codigo: "GR401707R", cor: "Azul", descricao: "Azul claro acinzentado" },
        { codigo: "GR401706R", cor: "Azul", descricao: "Azul médio acinzentado" },
        { codigo: "GR401704R", cor: "Azul", descricao: "Azul escuro acinzentado" },
        { codigo: "GR401705R", cor: "Azul", descricao: "Azul intenso acinzentado" },
      ],
      cores: ["Cinza", "Azul"],
      textura: "Lisa",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-7.jpg",
      descricao:
        "Coleção completa com gradação perfeita do cinza claro ao escuro, incluindo tons azuis acinzentados. Ideal para criar efeitos de profundidade e sofisticação.",
    },
    {
      id: 8,
      nome: "Série CR333 - Tons Azul-Verde",
      modelos: [
        { codigo: "CR333025R", cor: "Azul", descricao: "Azul acinzentado claro" },
        { codigo: "CR333026R", cor: "Azul", descricao: "Azul claro suave" },
        { codigo: "CR333027R", cor: "Verde", descricao: "Verde claro mint" },
        { codigo: "CR333028R", cor: "Verde", descricao: "Verde médio natural" },
        { codigo: "CR333029R", cor: "Verde", descricao: "Verde escuro intenso" },
      ],
      cores: ["Azul", "Verde"],
      textura: "Lisa",
      categoria: "Natureza",
      imagem: "/catalog-images/lisos-8.jpg",
      descricao:
        "Série inspirada na natureza com tons que vão do azul acinzentado ao verde intenso, passando pelo verde mint. Perfeita para ambientes relaxantes e naturais.",
    },
    {
      id: 9,
      nome: "Linha SE050 - Texturas Variadas",
      modelos: [
        { codigo: "SE050106", cor: "Bege", descricao: "Textura mosaico bege" },
        { codigo: "SE050102", cor: "Verde", descricao: "Textura lisa verde" },
        { codigo: "SE050110", cor: "Verde", descricao: "Textura linear verde escuro" },
        { codigo: "SE050105", cor: "Cinza", descricao: "Textura lisa cinza" },
        { codigo: "SE050107", cor: "Cinza", descricao: "Textura sutil cinza" },
      ],
      cores: ["Bege", "Verde", "Cinza"],
      textura: "Variada",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-9.jpg",
      descricao:
        "Linha com diferentes texturas incluindo mosaico, lisa e linear. Combina bege, verde e cinza em acabamentos únicos para ambientes diferenciados.",
    },
    {
      id: 10,
      nome: "Série SE050 - Tons Suaves",
      modelos: [
        { codigo: "SE050103", cor: "Bege", descricao: "Bege claro suave" },
        { codigo: "SE050102", cor: "Cinza", descricao: "Cinza claro delicado" },
        { codigo: "SE050408", cor: "Rosa", descricao: "Rosa claro texturizado" },
      ],
      cores: ["Bege", "Cinza", "Rosa"],
      textura: "Suave",
      categoria: "Delicado",
      imagem: "/catalog-images/lisos-10.jpg",
      descricao:
        "Série com tons suaves e delicados em bege, cinza e rosa claro. Texturas sutis que criam ambientes tranquilos e acolhedores.",
    },
    {
      id: 11,
      nome: "Série YY203 - Tons Pastéis",
      modelos: [
        { codigo: "YY203301R", cor: "Cinza", descricao: "Cinza claro pastel suave" },
        { codigo: "YY203302R", cor: "Cinza", descricao: "Cinza médio pastel" },
        { codigo: "YY203601R", cor: "Azul", descricao: "Azul claro pastel delicado" },
        { codigo: "YY203602R", cor: "Rosa", descricao: "Rosa claro pastel suave" },
      ],
      cores: ["Cinza", "Azul", "Rosa"],
      textura: "Lisa",
      categoria: "Pastel",
      imagem: "/catalog-images/lisos-11.jpg",
      descricao:
        "Série em tons pastéis suaves, perfeita para ambientes delicados e relaxantes. Inclui cinza claro, cinza médio, azul claro e rosa claro em acabamento liso premium.",
    },
    {
      id: 12,
      nome: "Coleção BR211 - Texturas Lineares",
      modelos: [
        { codigo: "BR211005R", cor: "Cinza", descricao: "Textura linear cinza escuro" },
        { codigo: "BR211004R", cor: "Bege", descricao: "Textura linear bege claro" },
        { codigo: "BR211003R", cor: "Cinza", descricao: "Textura linear cinza claro" },
        { codigo: "BR211002R", cor: "Cinza", descricao: "Textura linear cinza médio" },
        { codigo: "BR211001R", cor: "Bege", descricao: "Textura linear bege natural" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Linear",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-12.jpg",
      descricao:
        "Coleção com texturas lineares sutis em tons neutros. Combina diferentes tonalidades de cinza e bege com acabamento texturizado que adiciona profundidade aos ambientes.",
    },
    {
      id: 13,
      nome: "Série SE051 - Ambiente Moderno",
      modelos: [
        { codigo: "SE051303", cor: "Cinza", descricao: "Cinza claro moderno para ambientes" },
        { codigo: "SE051102", cor: "Cinza", descricao: "Cinza escuro elegante" },
      ],
      cores: ["Cinza"],
      textura: "Lisa",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-13.jpg",
      descricao:
        "Série moderna em tons de cinza, ideal para ambientes contemporâneos. Inclui aplicação em ambiente real mostrando a elegância e versatilidade dos tons neutros.",
    },
    {
      id: 14,
      nome: "CR333021R - Dourado Luxo",
      modelos: [{ codigo: "CR333021R", cor: "Dourado", descricao: "Dourado luxuoso com textura sutil" }],
      cores: ["Dourado", "Amarelo"],
      textura: "Texturizada",
      categoria: "Luxo",
      imagem: "/catalog-images/lisos-14.jpg",
      descricao:
        "Papel de parede dourado luxuoso com textura sutil que adiciona sofisticação e elegância aos ambientes. Perfeito para criar pontos focais e ambientes requintados.",
    },
    {
      id: 15,
      nome: "Série 6A096 - Ambiente Moderno",
      modelos: [
        { codigo: "6A096901R", cor: "Cinza", descricao: "Cinza claro texturizado moderno" },
        { codigo: "6A096806R", cor: "Cinza", descricao: "Cinza médio com textura sutil" },
        { codigo: "6A096807R", cor: "Verde", descricao: "Verde claro suave" },
      ],
      cores: ["Cinza", "Verde"],
      textura: "Texturizada",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-15.jpg",
      descricao:
        "Série moderna com texturas sutis em tons neutros. Inclui aplicação em ambiente real mostrando a elegância dos tons cinza e verde claro em decoração contemporânea.",
    },
    {
      id: 16,
      nome: "Coleção WS1101 - Texturas Lineares",
      modelos: [
        { codigo: "WS1101901R", cor: "Cinza", descricao: "Cinza claro com textura linear vertical" },
        { codigo: "WS1101902R", cor: "Cinza", descricao: "Cinza azulado com textura linear" },
        { codigo: "WS1101801R", cor: "Branco", descricao: "Branco com textura linear sutil" },
        { codigo: "WS1101802R", cor: "Cinza", descricao: "Cinza médio com textura linear" },
        { codigo: "WS1101803R", cor: "Cinza", descricao: "Cinza escuro com textura linear" },
      ],
      cores: ["Cinza", "Branco"],
      textura: "Linear",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-16.jpg",
      descricao:
        "Coleção com texturas lineares verticais em tons neutros. Perfeita para criar efeitos de altura e sofisticação em ambientes modernos.",
    },
    {
      id: 17,
      nome: "Série CR333 - Gradação Completa",
      modelos: [
        { codigo: "CR333408R", cor: "Cinza", descricao: "Cinza claro suave" },
        { codigo: "CR333409R", cor: "Bege", descricao: "Bege claro natural" },
        { codigo: "CR333410R", cor: "Verde", descricao: "Verde claro mint" },
        { codigo: "CR333411", cor: "Verde", descricao: "Verde médio natural" },
        { codigo: "CR333412", cor: "Cinza", descricao: "Cinza médio" },
        { codigo: "CR333407R", cor: "Cinza", descricao: "Cinza escuro elegante" },
      ],
      cores: ["Cinza", "Bege", "Verde"],
      textura: "Lisa",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-17.jpg",
      descricao:
        "Série completa com gradação perfeita de tons neutros, incluindo verde mint. Ideal para criar harmonia e continuidade visual em projetos arquitetônicos.",
    },
    {
      id: 18,
      nome: "CR333401R - Escuro Elegante",
      modelos: [
        { codigo: "CR333401R", cor: "Preto", descricao: "Preto texturizado elegante para ambientes sofisticados" },
      ],
      cores: ["Preto", "Cinza"],
      textura: "Texturizada",
      categoria: "Elegante",
      imagem: "/catalog-images/lisos-18.jpg",
      descricao:
        "Papel de parede escuro com textura sofisticada, perfeito para criar ambientes elegantes e dramáticos. Inclui aplicação em quarto moderno.",
    },
    {
      id: 19,
      nome: "Série SE050 - Tons Naturais",
      modelos: [
        { codigo: "SE050201", cor: "Bege", descricao: "Bege claro natural" },
        { codigo: "SE050203", cor: "Bege", descricao: "Bege médio com textura" },
        { codigo: "SE051403", cor: "Cinza", descricao: "Cinza com textura sutil" },
        { codigo: "SE050202", cor: "Cinza", descricao: "Cinza claro suave" },
      ],
      cores: ["Bege", "Cinza"],
      textura: "Natural",
      categoria: "Natural",
      imagem: "/catalog-images/lisos-19.jpg",
      descricao:
        "Série com tons naturais em bege e cinza, com texturas sutis que remetem a materiais orgânicos. Perfeita para ambientes aconchegantes e naturais.",
    },
    {
      id: 20,
      nome: "Série MT301 - Texturas Diagonais",
      modelos: [
        { codigo: "MT301601R", cor: "Bege", descricao: "Textura diagonal sutil em bege natural" },
        { codigo: "MT301401R", cor: "Bege", descricao: "Textura linear vertical em bege claro" },
      ],
      cores: ["Bege"],
      textura: "Diagonal",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-20.jpg",
      descricao:
        "Série com texturas diagonais e lineares em tons bege. Perfeita para adicionar movimento e dinamismo aos ambientes com sutileza.",
    },
    {
      id: 21,
      nome: "Coleção GR402 - Tons Neutros",
      modelos: [
        { codigo: "GR402602", cor: "Bege", descricao: "Bege claro com textura sutil" },
        { codigo: "GR402601", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "GR402501", cor: "Branco", descricao: "Branco com textura delicada" },
        { codigo: "GR402603", cor: "Cinza", descricao: "Cinza escuro elegante" },
      ],
      cores: ["Bege", "Cinza", "Branco"],
      textura: "Sutil",
      categoria: "Neutro",
      imagem: "/catalog-images/lisos-21.jpg",
      descricao:
        "Coleção em tons neutros com texturas sutis. Combina bege, cinza e branco para criar ambientes harmoniosos e elegantes.",
    },
    {
      id: 22,
      nome: "Série PT401 - Texturas Variadas",
      modelos: [
        { codigo: "PT401401R", cor: "Cinza", descricao: "Cinza claro com textura linear" },
        { codigo: "PT401402R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "PT401403R", cor: "Rosa", descricao: "Rosa dourado com brilho sutil" },
        { codigo: "PT401404R", cor: "Cinza", descricao: "Cinza com textura marcante" },
        { codigo: "PT401405R", cor: "Cinza", descricao: "Cinza escuro texturizado" },
      ],
      cores: ["Cinza", "Rosa", "Dourado"],
      textura: "Variada",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-22.jpg",
      descricao:
        "Série com texturas variadas incluindo um destaque em rosa dourado. Perfeita para criar contrastes elegantes em projetos sofisticados.",
    },
    {
      id: 23,
      nome: "Série MT300 - Padrões Sutis",
      modelos: [
        { codigo: "MT300401R", cor: "Cinza", descricao: "Cinza com padrão geométrico sutil" },
        { codigo: "MT300505R", cor: "Bege", descricao: "Bege claro liso premium" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Padrão",
      categoria: "Sutil",
      imagem: "/catalog-images/lisos-23.jpg",
      descricao:
        "Série com padrões sutis e acabamentos lisos. Combina cinza com padrão geométrico discreto e bege liso para versatilidade máxima.",
    },
    {
      id: 24,
      nome: "Coleção EL500 - Ambiente Completo",
      modelos: [
        { codigo: "EL500403R", cor: "Bege", descricao: "Bege claro com textura" },
        { codigo: "EL500401R", cor: "Bege", descricao: "Bege natural texturizado" },
        { codigo: "EL500306R", cor: "Cinza", descricao: "Cinza médio com textura" },
        { codigo: "EL500305R", cor: "Cinza", descricao: "Cinza claro sutil" },
        { codigo: "EL500304R", cor: "Cinza", descricao: "Cinza escuro elegante" },
        { codigo: "EL500303R", cor: "Verde", descricao: "Verde claro suave" },
        { codigo: "EL500302R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "EL500301R", cor: "Bege", descricao: "Bege claro natural" },
      ],
      cores: ["Bege", "Cinza", "Verde"],
      textura: "Texturizada",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-24.jpg",
      descricao:
        "Coleção completa com 8 variações em tons neutros. Inclui aplicação em ambiente real mostrando a versatilidade da série.",
    },
    {
      id: 25,
      nome: "Linha EL500 - Texturas Lineares",
      modelos: [
        { codigo: "EL500504R", cor: "Cinza", descricao: "Cinza escuro com textura linear" },
        { codigo: "EL500501R", cor: "Bege", descricao: "Bege claro com textura linear" },
        { codigo: "EL500502R", cor: "Cinza", descricao: "Cinza claro com textura linear" },
        { codigo: "EL500503R", cor: "Cinza", descricao: "Cinza médio com textura linear" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Linear",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-25.jpg",
      descricao:
        "Linha com texturas lineares verticais em tons neutros. Perfeita para criar efeitos de altura e elegância em ambientes modernos.",
    },
    {
      id: 26,
      nome: "CR333001R - Ambiente Moderno",
      modelos: [{ codigo: "CR333001R", cor: "Cinza", descricao: "Cinza texturizado para ambientes modernos" }],
      cores: ["Cinza"],
      textura: "Texturizada",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-26.jpg",
      descricao:
        "Papel de parede cinza texturizado com aplicação em sala moderna. Demonstra a elegância e sofisticação em ambientes contemporâneos.",
    },
    {
      id: 27,
      nome: "Série 6A097 - Texturas Premium",
      modelos: [
        { codigo: "6A097005R", cor: "Cinza", descricao: "Cinza claro com textura premium" },
        { codigo: "6A097001R", cor: "Bege", descricao: "Bege claro premium" },
        { codigo: "6A097006R", cor: "Cinza", descricao: "Cinza médio com padrão sutil" },
        { codigo: "6A097002R", cor: "Cinza", descricao: "Cinza claro texturizado" },
        { codigo: "6A097004R", cor: "Verde", descricao: "Verde claro suave" },
      ],
      cores: ["Cinza", "Bege", "Verde"],
      textura: "Premium",
      categoria: "Luxo",
      imagem: "/catalog-images/lisos-27.jpg",
      descricao:
        "Série premium com texturas sofisticadas em tons neutros. Inclui verde claro para adicionar frescor aos ambientes elegantes.",
    },
    {
      id: 28,
      nome: "Série AD200 - Ambiente Claro",
      modelos: [
        { codigo: "AD200204R", cor: "Bege", descricao: "Bege claro suave" },
        { codigo: "AD200203R", cor: "Branco", descricao: "Branco com textura sutil" },
        { codigo: "AD200202R", cor: "Branco", descricao: "Branco puro texturizado" },
        { codigo: "AD200201R", cor: "Branco", descricao: "Branco claro premium" },
      ],
      cores: ["Bege", "Branco"],
      textura: "Sutil",
      categoria: "Claro",
      imagem: "/catalog-images/lisos-28.jpg",
      descricao:
        "Série em tons claros com aplicação em ambiente real. Perfeita para criar espaços luminosos e arejados com elegância.",
    },
    {
      id: 29,
      nome: "Coleção CR333 - Tons Vibrantes",
      modelos: [
        { codigo: "CR333036R", cor: "Marrom", descricao: "Marrom texturizado elegante" },
        { codigo: "CR333037R", cor: "Rosa", descricao: "Rosa claro delicado" },
        { codigo: "CR333038R", cor: "Vermelho", descricao: "Vermelho tijolo texturizado" },
        { codigo: "CR333034R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "CR333035R", cor: "Bege", descricao: "Bege natural texturizado" },
      ],
      cores: ["Marrom", "Rosa", "Vermelho", "Cinza", "Bege"],
      textura: "Texturizada",
      categoria: "Vibrante",
      imagem: "/catalog-images/lisos-29.jpg",
      descricao:
        "Coleção com tons mais vibrantes incluindo marrom, rosa e vermelho tijolo. Perfeita para criar ambientes com personalidade e caráter.",
    },
    {
      id: 30,
      nome: "Série CR333 - Ambiente Neutro",
      modelos: [
        { codigo: "CR333015R", cor: "Cinza", descricao: "Cinza texturizado elegante" },
        { codigo: "CR333012R", cor: "Bege", descricao: "Bege claro natural" },
        { codigo: "CR333013R", cor: "Marrom", descricao: "Marrom bege escuro" },
        { codigo: "CR333014R", cor: "Cinza", descricao: "Cinza claro suave" },
      ],
      cores: ["Cinza", "Bege", "Marrom"],
      textura: "Texturizada",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-30.jpg",
      descricao:
        "Série com 4 variações em tons neutros com aplicação em ambiente real. Perfeita para criar harmonia em espaços modernos e elegantes.",
    },
    {
      id: 31,
      nome: "Série VR980 - Padrões Sutis",
      modelos: [
        { codigo: "VR980703T", cor: "Cinza", descricao: "Cinza com padrão floral sutil" },
        { codigo: "VR980806R", cor: "Cinza", descricao: "Cinza liso claro premium" },
      ],
      cores: ["Cinza"],
      textura: "Padrão",
      categoria: "Sutil",
      imagem: "/catalog-images/lisos-31.jpg",
      descricao:
        "Série com padrões florais sutis e acabamentos lisos. Combina elegância discreta com versatilidade para ambientes sofisticados.",
    },
    {
      id: 32,
      nome: "Série CR333 - Tons Azuis",
      modelos: [
        { codigo: "CR333031R", cor: "Cinza", descricao: "Cinza claro texturizado" },
        { codigo: "CR333032R", cor: "Azul", descricao: "Azul escuro elegante" },
        { codigo: "CR333033R", cor: "Azul", descricao: "Azul escuro intenso" },
      ],
      cores: ["Cinza", "Azul"],
      textura: "Texturizada",
      categoria: "Azul",
      imagem: "/catalog-images/lisos-32.jpg",
      descricao:
        "Série com destaque para tons azuis escuros. Inclui 2 ambientes aplicados mostrando a versatilidade em salas modernas e elegantes.",
    },
    {
      id: 33,
      nome: "Coleção SE050 - Texturas Mistas",
      modelos: [
        { codigo: "SE050312", cor: "Cinza", descricao: "Cinza com textura mista" },
        { codigo: "SE050511", cor: "Cinza", descricao: "Cinza texturizado médio" },
        { codigo: "SE050502", cor: "Cinza", descricao: "Cinza com padrão geométrico" },
        { codigo: "SE050509", cor: "Bege", descricao: "Bege claro texturizado" },
        { codigo: "SE050508", cor: "Cinza", descricao: "Cinza claro sutil" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Mista",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-33.jpg",
      descricao:
        "Coleção com texturas mistas incluindo padrões geométricos e acabamentos variados. Perfeita para projetos que buscam diversidade textural.",
    },
    {
      id: 34,
      nome: "Série BR204 - Texturas Diagonais",
      modelos: [
        { codigo: "BR204006R", cor: "Cinza", descricao: "Cinza escuro com textura diagonal" },
        { codigo: "BR204005R", cor: "Cinza", descricao: "Cinza médio diagonal" },
        { codigo: "BR204004R", cor: "Cinza", descricao: "Cinza claro diagonal" },
        { codigo: "BR204003R", cor: "Bege", descricao: "Bege claro diagonal" },
        { codigo: "BR204002R", cor: "Bege", descricao: "Bege natural diagonal" },
        { codigo: "BR204001R", cor: "Bege", descricao: "Bege suave diagonal" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Diagonal",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-34.jpg",
      descricao:
        "Série completa com texturas diagonais em gradação perfeita. Do cinza escuro ao bege suave, ideal para criar movimento visual nos ambientes.",
    },
    {
      id: 35,
      nome: "CR333245R - Marrom Ambiente",
      modelos: [{ codigo: "CR333245R", cor: "Marrom", descricao: "Marrom texturizado para ambientes acolhedores" }],
      cores: ["Marrom"],
      textura: "Texturizada",
      categoria: "Acolhedor",
      imagem: "/catalog-images/lisos-35.jpg",
      descricao:
        "Papel de parede marrom texturizado com aplicação em sala moderna. Demonstra como tons terrosos criam ambientes acolhedores e sofisticados.",
    },
    {
      id: 36,
      nome: "Linha SE050 - Gradação Sutil",
      modelos: [
        { codigo: "SE051202", cor: "Cinza", descricao: "Cinza escuro texturizado" },
        { codigo: "SE050402", cor: "Bege", descricao: "Bege claro natural" },
        { codigo: "SE050404", cor: "Bege", descricao: "Bege médio texturizado" },
        { codigo: "SE050406", cor: "Cinza", descricao: "Cinza médio sutil" },
        { codigo: "SE050407", cor: "Cinza", descricao: "Cinza claro texturizado" },
        { codigo: "SE051201", cor: "Bege", descricao: "Bege natural premium" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Sutil",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-36.jpg",
      descricao:
        "Linha com gradação sutil em 6 variações. Combina tons de cinza e bege com texturas delicadas para máxima versatilidade.",
    },
    {
      id: 37,
      nome: "Coleção 6A097 - Gradação Completa",
      modelos: [
        { codigo: "6A097005R", cor: "Cinza", descricao: "Cinza escuro premium" },
        { codigo: "6A097007R", cor: "Bege", descricao: "Bege médio texturizado" },
        { codigo: "6A097008R", cor: "Cinza", descricao: "Cinza médio elegante" },
        { codigo: "6A097014R", cor: "Cinza", descricao: "Cinza claro premium" },
        { codigo: "6A097001R", cor: "Bege", descricao: "Bege claro natural" },
        { codigo: "6A097002R", cor: "Cinza", descricao: "Cinza claro sutil" },
        { codigo: "6A097003R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "6A097004R", cor: "Cinza", descricao: "Cinza escuro texturizado" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Premium",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-37.jpg",
      descricao:
        "Coleção premium com 8 variações em gradação completa. Oferece máxima flexibilidade para projetos que exigem harmonia tonal perfeita.",
    },
    {
      id: 38,
      nome: "CR333109R - Verde Ambiente",
      modelos: [{ codigo: "CR333109R", cor: "Verde", descricao: "Verde escuro texturizado para ambientes modernos" }],
      cores: ["Verde"],
      textura: "Texturizada",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-38.jpg",
      descricao:
        "Papel de parede verde escuro texturizado com aplicação em ambiente real. Perfeito para criar pontos focais elegantes e naturais.",
    },
    {
      id: 39,
      nome: "Série SE050 - Ambiente Moderno",
      modelos: [
        { codigo: "SE050301", cor: "Cinza", descricao: "Cinza claro moderno" },
        { codigo: "SE050302", cor: "Cinza", descricao: "Cinza médio texturizado" },
      ],
      cores: ["Cinza"],
      textura: "Moderna",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-39.jpg",
      descricao:
        "Série moderna com 2 variações em cinza e aplicação em ambiente real. Demonstra a elegância dos tons neutros em decoração contemporânea.",
    },
    {
      id: 40,
      nome: "Série CR333 - Gradação Mega Completa",
      modelos: [
        { codigo: "CR333204R", cor: "Cinza", descricao: "Cinza claro suave" },
        { codigo: "CR333205R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "CR333206R", cor: "Bege", descricao: "Bege claro natural" },
        { codigo: "CR333207R", cor: "Bege", descricao: "Bege médio texturizado" },
        { codigo: "CR333208R", cor: "Bege", descricao: "Bege escuro natural" },
        { codigo: "CR333209R", cor: "Cinza", descricao: "Cinza médio elegante" },
        { codigo: "CR333210R", cor: "Azul", descricao: "Azul escuro sofisticado" },
        { codigo: "CR333211R", cor: "Cinza", descricao: "Cinza claro premium" },
        { codigo: "CR333201R", cor: "Cinza", descricao: "Cinza claro delicado" },
        { codigo: "CR333202R", cor: "Azul", descricao: "Azul claro suave" },
        { codigo: "CR333203R", cor: "Azul", descricao: "Azul médio elegante" },
      ],
      cores: ["Cinza", "Bege", "Azul"],
      textura: "Variada",
      categoria: "Mega Gradação",
      imagem: "/catalog-images/lisos-40.jpg",
      descricao:
        "Série mega completa com 11 variações em gradação perfeita. Inclui tons de cinza, bege e azul para máxima versatilidade em projetos arquitetônicos.",
    },
    {
      id: 41,
      nome: "CR333101R - Cozinha Moderna",
      modelos: [{ codigo: "CR333101R", cor: "Cinza", descricao: "Cinza texturizado para cozinhas modernas" }],
      cores: ["Cinza"],
      textura: "Texturizada",
      categoria: "Cozinha",
      imagem: "/catalog-images/lisos-41.jpg",
      descricao:
        "Papel de parede cinza texturizado com aplicação em cozinha moderna. Demonstra elegância em ambientes gourmet com móveis dourados.",
    },
    {
      id: 42,
      nome: "Série NN591 - Texturas Especiais",
      modelos: [
        { codigo: "NN591704R", cor: "Cinza", descricao: "Cinza com textura linear sutil" },
        { codigo: "NN591705R", cor: "Cinza", descricao: "Cinza liso premium" },
        { codigo: "NN591602R", cor: "Cinza", descricao: "Cinza com textura mármore" },
        { codigo: "NN591601R", cor: "Cinza", descricao: "Cinza texturizado elegante" },
      ],
      cores: ["Cinza"],
      textura: "Especial",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-42.jpg",
      descricao:
        "Série com texturas especiais incluindo efeito mármore. Perfeita para projetos que exigem acabamentos únicos e sofisticados.",
    },
    {
      id: 43,
      nome: "Série MT300 - Quarto Clássico",
      modelos: [
        { codigo: "MT300501R", cor: "Rosa", descricao: "Bege rosado delicado para quartos" },
        { codigo: "MT300502R", cor: "Cinza", descricao: "Cinza texturizado clássico" },
      ],
      cores: ["Rosa", "Cinza", "Bege"],
      textura: "Clássica",
      categoria: "Quarto",
      imagem: "/catalog-images/lisos-43.jpg",
      descricao:
        "Série clássica com aplicação em quarto elegante. Combina bege rosado e cinza texturizado para ambientes acolhedores e sofisticados.",
    },
    {
      id: 44,
      nome: "Coleção 6A097 - Gradação Cinza Premium",
      modelos: [
        { codigo: "6A097007R", cor: "Cinza", descricao: "Cinza escuro premium" },
        { codigo: "6A097008R", cor: "Bege", descricao: "Bege acinzentado" },
        { codigo: "6A097009R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "6A097004R", cor: "Cinza", descricao: "Cinza claro premium" },
        { codigo: "6A097005R", cor: "Cinza", descricao: "Cinza claro sutil" },
        { codigo: "6A097006R", cor: "Cinza", descricao: "Cinza muito claro" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Premium",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-44.jpg",
      descricao:
        "Coleção premium com 6 variações em gradação perfeita de cinza. Ideal para criar harmonia tonal em projetos minimalistas.",
    },
    {
      id: 45,
      nome: "CR333446R - Quarto Verde Elegante",
      modelos: [{ codigo: "CR333446R", cor: "Verde", descricao: "Verde escuro texturizado para quartos elegantes" }],
      cores: ["Verde"],
      textura: "Texturizada",
      categoria: "Quarto",
      imagem: "/catalog-images/lisos-45.jpg",
      descricao:
        "Papel de parede verde escuro texturizado com aplicação em quarto elegante. Cria ambientes sofisticados e relaxantes.",
    },
    {
      id: 46,
      nome: "Série CR333 - Tons Diversos",
      modelos: [
        { codigo: "CR333610R", cor: "Bege", descricao: "Bege claro natural" },
        { codigo: "CR333612R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "CR333613R", cor: "Azul", descricao: "Azul claro suave" },
        { codigo: "CR333040AR", cor: "Cinza", descricao: "Cinza texturizado especial" },
        { codigo: "CR333609R", cor: "Verde", descricao: "Verde claro mint" },
      ],
      cores: ["Bege", "Cinza", "Azul", "Verde"],
      textura: "Diversa",
      categoria: "Variado",
      imagem: "/catalog-images/lisos-46.jpg",
      descricao:
        "Série com tons diversos incluindo bege, cinza, azul claro e verde mint. Máxima versatilidade para projetos criativos.",
    },
    {
      id: 47,
      nome: "CR333426R - Sala Azul Moderna",
      modelos: [{ codigo: "CR333426R", cor: "Azul", descricao: "Azul acinzentado para salas modernas" }],
      cores: ["Azul", "Cinza"],
      textura: "Texturizada",
      categoria: "Sala",
      imagem: "/catalog-images/lisos-47.jpg",
      descricao:
        "Papel de parede azul acinzentado com aplicação em sala moderna. Perfeito para criar ambientes contemporâneos e relaxantes.",
    },
    {
      id: 48,
      nome: "Série AD201 - Sala de Jantar",
      modelos: [
        { codigo: "AD201502R", cor: "Cinza", descricao: "Cinza médio para salas de jantar" },
        { codigo: "AD201501R", cor: "Cinza", descricao: "Cinza claro elegante" },
      ],
      cores: ["Cinza"],
      textura: "Elegante",
      categoria: "Sala de Jantar",
      imagem: "/catalog-images/lisos-48.jpg",
      descricao:
        "Série elegante com aplicação em sala de jantar moderna. Demonstra sofisticação em ambientes sociais contemporâneos.",
    },
    {
      id: 49,
      nome: "Coleção AD201 - Gradação Completa",
      modelos: [
        { codigo: "AD201510R", cor: "Cinza", descricao: "Cinza escuro intenso" },
        { codigo: "AD201509R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "AD201508R", cor: "Bege", descricao: "Bege acinzentado" },
        { codigo: "AD201507R", cor: "Bege", descricao: "Bege claro suave" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Gradação",
      categoria: "Completa",
      imagem: "/catalog-images/lisos-49.jpg",
      descricao:
        "Coleção completa com gradação perfeita do cinza escuro ao bege claro. Ideal para projetos que exigem continuidade tonal.",
    },
    {
      id: 50,
      nome: "Série CR333 - Ambientes Lineares",
      modelos: [
        { codigo: "CR333119R", cor: "Cinza", descricao: "Cinza claro com textura linear vertical" },
        { codigo: "CR333120R", cor: "Cinza", descricao: "Cinza médio linear elegante" },
        { codigo: "CR333121R", cor: "Bege", descricao: "Bege claro linear natural" },
        { codigo: "CR333122R", cor: "Bege", descricao: "Bege dourado linear premium" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Linear",
      categoria: "Ambientes",
      imagem: "/catalog-images/lisos-50.jpg",
      descricao:
        "Série com texturas lineares verticais aplicada em 2 ambientes reais (sala e quarto). Demonstra elegância e sofisticação em decoração contemporânea.",
    },
    {
      id: 51,
      nome: "Coleção CR333 - Tons Dourados",
      modelos: [
        { codigo: "CR333451R", cor: "Dourado", descricao: "Dourado texturizado premium" },
        { codigo: "CR333447R", cor: "Cinza", descricao: "Cinza médio elegante" },
        { codigo: "CR333448R", cor: "Verde", descricao: "Verde claro suave" },
        { codigo: "CR333449R", cor: "Verde", descricao: "Verde médio natural" },
        { codigo: "CR333450R", cor: "Dourado", descricao: "Dourado claro premium" },
      ],
      cores: ["Dourado", "Cinza", "Verde"],
      textura: "Premium",
      categoria: "Dourado",
      imagem: "/catalog-images/lisos-51.jpg",
      descricao:
        "Coleção premium com destaque para tons dourados. Inclui 2 ambientes aplicados (quarto e sala) mostrando luxo e sofisticação.",
    },
    {
      id: 52,
      nome: "Série 6A097 - Quarto Moderno",
      modelos: [
        { codigo: "6A097013R", cor: "Bege", descricao: "Bege claro para quartos" },
        { codigo: "6A097010R", cor: "Cinza", descricao: "Cinza claro moderno" },
        { codigo: "6A097011R", cor: "Azul", descricao: "Azul claro suave" },
        { codigo: "6A097012R", cor: "Cinza", descricao: "Cinza médio elegante" },
      ],
      cores: ["Bege", "Cinza", "Azul"],
      textura: "Moderna",
      categoria: "Quarto",
      imagem: "/catalog-images/lisos-52.jpg",
      descricao:
        "Série moderna com aplicação em quarto contemporâneo. Parede verde aplicada demonstra versatilidade em ambientes relaxantes.",
    },
    {
      id: 53,
      nome: "Linha CR333 - Gradação Linear",
      modelos: [
        { codigo: "CR333508R", cor: "Cinza", descricao: "Cinza claro linear" },
        { codigo: "CR333509R", cor: "Cinza", descricao: "Cinza médio linear" },
        { codigo: "CR333510R", cor: "Bege", descricao: "Bege claro linear" },
        { codigo: "CR333511R", cor: "Cinza", descricao: "Cinza escuro linear" },
        { codigo: "CR333512R", cor: "Cinza", descricao: "Cinza médio escuro linear" },
        { codigo: "CR333507R", cor: "Cinza", descricao: "Cinza claro sutil linear" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Linear",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-53.jpg",
      descricao:
        "Linha com 6 variações em gradação linear perfeita. Texturas verticais que criam efeitos de altura e elegância em ambientes modernos.",
    },
    {
      id: 54,
      nome: "Série AD201 - Tons Claros Premium",
      modelos: [
        { codigo: "AD201506R", cor: "Bege", descricao: "Bege claro premium" },
        { codigo: "AD201505R", cor: "Cinza", descricao: "Cinza claro delicado" },
        { codigo: "AD201504R", cor: "Branco", descricao: "Branco texturizado suave" },
        { codigo: "AD201503R", cor: "Cinza", descricao: "Cinza muito claro" },
      ],
      cores: ["Bege", "Cinza", "Branco"],
      textura: "Premium",
      categoria: "Claro",
      imagem: "/catalog-images/lisos-54.jpg",
      descricao:
        "Série premium em tons claros e neutros. Perfeita para criar ambientes luminosos e arejados com máxima elegância.",
    },
    {
      id: 55,
      nome: "Coleção CR333 - Tons Diversos Premium",
      modelos: [
        { codigo: "CR333608R", cor: "Verde", descricao: "Verde claro mint premium" },
        { codigo: "CR333604R", cor: "Cinza", descricao: "Cinza escuro elegante" },
        { codigo: "CR333605R", cor: "Branco", descricao: "Branco texturizado premium" },
        { codigo: "CR333606R", cor: "Branco", descricao: "Branco puro elegante" },
        { codigo: "CR333607R", cor: "Azul", descricao: "Azul acinzentado suave" },
      ],
      cores: ["Verde", "Cinza", "Branco", "Azul"],
      textura: "Premium",
      categoria: "Diverso",
      imagem: "/catalog-images/lisos-55.jpg",
      descricao:
        "Coleção premium com máxima diversidade de cores. Inclui verde mint, cinza escuro, branco puro e azul acinzentado para projetos únicos.",
    },
    {
      id: 56,
      nome: "Série CR333 - Tons Terrosos",
      modelos: [
        { codigo: "CR333456R", cor: "Cinza", descricao: "Cinza claro terroso" },
        { codigo: "CR333452R", cor: "Marrom", descricao: "Marrom escuro elegante" },
        { codigo: "CR333453R", cor: "Bege", descricao: "Bege claro natural" },
        { codigo: "CR333454R", cor: "Bege", descricao: "Bege médio terroso" },
        { codigo: "CR333455R", cor: "Cinza", descricao: "Cinza médio terroso" },
      ],
      cores: ["Cinza", "Marrom", "Bege"],
      textura: "Terrosa",
      categoria: "Terroso",
      imagem: "/catalog-images/lisos-56.jpg",
      descricao:
        "Série com tons terrosos que variam do cinza ao marrom escuro. Perfeita para criar ambientes acolhedores e conectados à natureza.",
    },
    {
      id: 57,
      nome: "Linha CR333 - Ambientes Integrados",
      modelos: [
        { codigo: "CR333506R", cor: "Bege", descricao: "Bege claro para ambientes integrados" },
        { codigo: "CR333502R", cor: "Cinza", descricao: "Cinza claro moderno" },
        { codigo: "CR333503R", cor: "Cinza", descricao: "Cinza médio elegante" },
        { codigo: "CR333504R", cor: "Cinza", descricao: "Cinza escuro sofisticado" },
        { codigo: "CR333505R", cor: "Bege", descricao: "Bege natural premium" },
      ],
      cores: ["Bege", "Cinza"],
      textura: "Integrada",
      categoria: "Ambientes",
      imagem: "/catalog-images/lisos-57.jpg",
      descricao:
        "Linha para ambientes integrados com aplicação em 2 ambientes reais. Demonstra harmonia perfeita entre sala e quarto com tons neutros.",
    },
    {
      id: 58,
      nome: "Série BR213 - Texturas Lineares Verticais",
      modelos: [
        { codigo: "BR213005R", cor: "Cinza", descricao: "Cinza escuro linear vertical" },
        { codigo: "BR213004R", cor: "Cinza", descricao: "Cinza médio linear vertical" },
        { codigo: "BR213003R", cor: "Cinza", descricao: "Cinza claro linear vertical" },
        { codigo: "BR213002R", cor: "Cinza", descricao: "Cinza muito claro linear" },
        { codigo: "BR213001R", cor: "Cinza", descricao: "Cinza suave linear vertical" },
      ],
      cores: ["Cinza"],
      textura: "Linear Vertical",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-58.jpg",
      descricao:
        "Série especializada em texturas lineares verticais. 5 variações em tons de cinza que criam efeitos de altura e movimento visual.",
    },
    {
      id: 59,
      nome: "Linha PT401 - Texturas Naturais Premium",
      modelos: [
        { codigo: "PT401601R", cor: "Bege", descricao: "Bege claro textura natural" },
        { codigo: "PT401602R", cor: "Bege", descricao: "Bege médio textura natural" },
        { codigo: "PT401603R", cor: "Cinza", descricao: "Cinza médio textura natural" },
        { codigo: "PT401604R", cor: "Cinza", descricao: "Cinza claro textura natural" },
      ],
      cores: ["Bege", "Cinza"],
      textura: "Natural Premium",
      categoria: "Natural",
      imagem: "/catalog-images/lisos-59.jpg",
      descricao:
        "Linha premium com texturas naturais em tons neutros. Acabamentos que remetem a materiais orgânicos para ambientes sofisticados e acolhedores.",
    },
    {
      id: 60,
      nome: "Série 6A097 - Tons Metalizados Premium",
      modelos: [
        { codigo: "6A097008R", cor: "Cinza", descricao: "Cinza metalizado premium" },
        { codigo: "6A097009R", cor: "Verde", descricao: "Verde metalizado elegante" },
        { codigo: "6A097010R", cor: "Cinza", descricao: "Cinza claro metalizado" },
        { codigo: "6A097005R", cor: "Bege", descricao: "Bege metalizado suave" },
        { codigo: "6A097006R", cor: "Verde", descricao: "Verde claro metalizado" },
        { codigo: "6A097007R", cor: "Cinza", descricao: "Cinza médio metalizado" },
      ],
      cores: ["Cinza", "Verde", "Bege"],
      textura: "Metalizada",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-60.jpg",
      descricao:
        "Série premium com acabamento metalizado em tons neutros e verdes. Perfeita para criar ambientes sofisticados e contemporâneos com um toque de luxo discreto.",
    },
    {
      id: 61,
      nome: "Coleção GR401 - Espectro Completo",
      modelos: [
        { codigo: "GR401006R", cor: "Azul", descricao: "Azul marinho intenso" },
        { codigo: "GR401005R", cor: "Verde", descricao: "Verde água suave" },
        { codigo: "GR401004R", cor: "Bege", descricao: "Bege dourado natural" },
        { codigo: "GR401003R", cor: "Branco", descricao: "Branco puro premium" },
        { codigo: "GE401001R", cor: "Rosa", descricao: "Rosa claro delicado" },
        { codigo: "GR401002R", cor: "Cinza", descricao: "Cinza escuro elegante" },
        { codigo: "GR401008R", cor: "Preto", descricao: "Preto intenso sofisticado" },
        { codigo: "GR401007R", cor: "Cinza", descricao: "Cinza chumbo moderno" },
      ],
      cores: ["Azul", "Verde", "Bege", "Branco", "Rosa", "Cinza", "Preto"],
      textura: "Linear",
      categoria: "Espectro",
      imagem: "/catalog-images/lisos-61.jpg",
      descricao:
        "Coleção completa com espectro de cores que vai do azul marinho ao preto, passando por tons claros e escuros. Máxima versatilidade para qualquer projeto de decoração.",
    },
    {
      id: 62,
      nome: "Série BR217 - Efeito Concreto Premium",
      modelos: [
        { codigo: "BR217004", cor: "Cinza", descricao: "Cinza claro efeito concreto" },
        { codigo: "BR217003", cor: "Cinza", descricao: "Cinza médio efeito concreto" },
        { codigo: "BR217002", cor: "Cinza", descricao: "Cinza escuro efeito concreto" },
        { codigo: "BR217001", cor: "Cinza", descricao: "Cinza prata efeito concreto" },
      ],
      cores: ["Cinza"],
      textura: "Concreto",
      categoria: "Industrial",
      imagem: "/catalog-images/lisos-67.jpg",
      descricao:
        "Série com efeito concreto premium, perfeita para criar ambientes industriais sofisticados. Inclui variações de cinza com acabamento metalizado para máxima elegância contemporânea.",
    },
    {
      id: 63,
      nome: "Série AD200 - Ambiente Minimalista",
      modelos: [
        { codigo: "AD200704R", cor: "Bege", descricao: "Bege texturizado natural" },
        { codigo: "AD200703R", cor: "Branco", descricao: "Branco texturizado premium" },
        { codigo: "AD200702R", cor: "Branco", descricao: "Branco puro texturizado" },
        { codigo: "AD200701R", cor: "Branco", descricao: "Branco neve texturizado" },
      ],
      cores: ["Bege", "Branco"],
      textura: "Minimalista",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-63.jpg",
      descricao:
        "Série minimalista com aplicação em ambiente moderno. Tons neutros de branco e bege com texturas sutis que criam espaços clean e sofisticados.",
    },
    {
      id: 64,
      nome: "CR333413 - Roxo Vibrante Ambiente",
      modelos: [
        { codigo: "CR333413", cor: "Roxo", descricao: "Roxo vibrante texturizado para ambientes sofisticados" },
      ],
      cores: ["Roxo", "Lilás"],
      textura: "Texturizada",
      categoria: "Vibrante",
      imagem: "/catalog-images/lisos-64.jpg",
      descricao:
        "Papel de parede roxo vibrante com aplicação em sala moderna. Cria ambientes sofisticados e cheios de personalidade, perfeito para quem busca um toque de cor marcante na decoração.",
    },
    {
      id: 65,
      nome: "Série SE05 - Texturas Especiais",
      modelos: [
        { codigo: "5E051304", cor: "Marrom", descricao: "Marrom ferrugem texturizado" },
        { codigo: "5E050303", cor: "Cinza", descricao: "Cinza claro texturizado" },
        { codigo: "5E050304", cor: "Cinza", descricao: "Cinza escuro texturizado" },
        { codigo: "5E051101", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "5E051302", cor: "Cinza", descricao: "Cinza claro texturizado" },
        { codigo: "5E051301", cor: "Cinza", descricao: "Cinza prata texturizado" },
      ],
      cores: ["Marrom", "Cinza"],
      textura: "Especial",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-65.jpg",
      descricao:
        "Série com texturas especiais incluindo um exclusivo tom ferrugem. Perfeita para criar ambientes com personalidade e sofisticação industrial.",
    },
    {
      id: 66,
      nome: "Série CR333 - Tons Lineares Verticais",
      modelos: [
        { codigo: "CR333102R", cor: "Cinza", descricao: "Cinza claro linear vertical" },
        { codigo: "CR333103R", cor: "Cinza", descricao: "Cinza escuro linear vertical" },
        { codigo: "CR333104R", cor: "Cinza", descricao: "Cinza médio linear vertical" },
        { codigo: "CR333105R", cor: "Cinza", descricao: "Cinza prata linear vertical" },
        { codigo: "CR333106R", cor: "Cinza", descricao: "Cinza claro linear vertical" },
        { codigo: "CR333107R", cor: "Azul", descricao: "Azul acinzentado linear vertical" },
        { codigo: "CR333108R", cor: "Azul", descricao: "Azul escuro linear vertical" },
      ],
      cores: ["Cinza", "Azul"],
      textura: "Linear Vertical",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-66.jpg",
      descricao:
        "Série completa com texturas lineares verticais em tons de cinza e azul. Perfeita para criar efeitos de altura e elegância em ambientes contemporâneos.",
    },
    {
      id: 67,
      nome: "Série 6A097 - Gradação Cinza-Verde",
      modelos: [
        { codigo: "6A097006R", cor: "Cinza", descricao: "Cinza claro linear" },
        { codigo: "6A097007R", cor: "Cinza", descricao: "Cinza médio linear" },
        { codigo: "6A097008R", cor: "Cinza", descricao: "Cinza escuro linear" },
        { codigo: "6A097001R", cor: "Bege", descricao: "Bege claro linear" },
        { codigo: "6A097002R", cor: "Verde", descricao: "Verde claro linear" },
        { codigo: "6A097003R", cor: "Cinza", descricao: "Cinza médio linear" },
        { codigo: "6A097004R", cor: "Cinza", descricao: "Cinza escuro linear" },
        { codigo: "6A097005R", cor: "Cinza", descricao: "Cinza prata linear" },
      ],
      cores: ["Cinza", "Bege", "Verde"],
      textura: "Linear",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-68.jpg",
      descricao:
        "Série com gradação perfeita de tons cinza, bege e verde com texturas lineares. Ideal para criar ambientes harmoniosos e elegantes com transições suaves.",
    },
    {
      id: 68,
      nome: "Série CR333 - Tons Linho Premium",
      modelos: [
        { codigo: "CR333307R", cor: "Verde", descricao: "Verde claro textura linho" },
        { codigo: "CR333305R", cor: "Branco", descricao: "Branco puro textura linho" },
        { codigo: "CR333306R", cor: "Bege", descricao: "Bege natural textura linho" },
      ],
      cores: ["Verde", "Branco", "Bege"],
      textura: "Linho",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-69.jpg",
      descricao:
        "Série premium com textura de linho em tons suaves. Perfeita para criar ambientes naturais e aconchegantes com toque de sofisticação.",
    },
    {
      id: 69,
      nome: "Coleção GR401 - Tons Lineares Premium",
      modelos: [
        { codigo: "GR401105R", cor: "Cinza", descricao: "Cinza claro linear premium" },
        { codigo: "GR401104R", cor: "Cinza", descricao: "Cinza escuro linear premium" },
        { codigo: "GR401103R", cor: "Cinza", descricao: "Cinza médio linear premium" },
        { codigo: "GR401102R", cor: "Verde", descricao: "Verde claro linear premium" },
        { codigo: "GR401101R", cor: "Bege", descricao: "Bege claro linear premium" },
        { codigo: "GR401107R", cor: "Bege", descricao: "Bege texturizado premium" },
        { codigo: "GR401106R", cor: "Cinza", descricao: "Cinza escuro premium" },
      ],
      cores: ["Cinza", "Verde", "Bege"],
      textura: "Linear Premium",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-70.jpg",
      descricao:
        "Coleção premium com 7 variações em texturas lineares sofisticadas. Combina tons de cinza, verde claro e bege para máxima elegância.",
    },
    {
      id: 70,
      nome: "Série 6A096 - Texturas Metalizadas",
      modelos: [
        { codigo: "6A096907R", cor: "Cinza", descricao: "Cinza claro metalizado" },
        { codigo: "6A096902R", cor: "Cinza", descricao: "Cinza azulado metalizado" },
        { codigo: "6A096903R", cor: "Bege", descricao: "Bege claro metalizado" },
        { codigo: "6A096904R", cor: "Cinza", descricao: "Cinza médio metalizado" },
        { codigo: "6A096905R", cor: "Branco", descricao: "Branco puro metalizado" },
        { codigo: "6A096906R", cor: "Cinza", descricao: "Cinza escuro metalizado" },
      ],
      cores: ["Cinza", "Bege", "Branco"],
      textura: "Metalizada",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-71.jpg",
      descricao:
        "Série com acabamentos metalizados em tons neutros. Perfeita para criar ambientes sofisticados com brilho sutil e elegância contemporânea.",
    },
    {
      id: 71,
      nome: "Série EL501 - Texturas Naturais Avançadas",
      modelos: [
        { codigo: "EL501001R", cor: "Bege", descricao: "Bege claro textura natural" },
        { codigo: "EL501002R", cor: "Bege", descricao: "Bege médio textura natural" },
        { codigo: "EL501003R", cor: "Bege", descricao: "Bege escuro textura natural" },
        { codigo: "EL501004R", cor: "Bege", descricao: "Bege dourado textura natural" },
        { codigo: "EL500901R", cor: "Cinza", descricao: "Cinza claro textura natural" },
        { codigo: "EL500902R", cor: "Cinza", descricao: "Cinza médio textura natural" },
        { codigo: "EL500903R", cor: "Cinza", descricao: "Cinza escuro textura natural" },
      ],
      cores: ["Bege", "Cinza"],
      textura: "Natural Avançada",
      categoria: "Natural",
      imagem: "/catalog-images/lisos-72.jpg",
      descricao:
        "Série avançada com 7 variações em texturas naturais sofisticadas. Combina tons de bege e cinza com acabamentos que remetem a materiais orgânicos.",
    },
    {
      id: 72,
      nome: "Série SE051 - Texturas Especiais Ambiente",
      modelos: [
        { codigo: "SE0511401", cor: "Bege", descricao: "Bege claro textura especial" },
        { codigo: "SE051402", cor: "Cinza", descricao: "Cinza médio textura especial" },
        { codigo: "SE051404", cor: "Cinza", descricao: "Cinza escuro textura especial" },
      ],
      cores: ["Bege", "Cinza"],
      textura: "Especial",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-73.jpg",
      descricao:
        "Série com texturas especiais aplicada em ambiente moderno. Demonstra versatilidade em decoração contemporânea com acabamentos únicos.",
    },
    {
      id: 73,
      nome: "Série CR333 - Tons Escuros Elegantes",
      modelos: [
        { codigo: "CR333406R", cor: "Preto", descricao: "Preto texturizado elegante" },
        { codigo: "CR333402R", cor: "Cinza", descricao: "Cinza claro elegante" },
        { codigo: "CR333403R", cor: "Cinza", descricao: "Cinza médio elegante" },
        { codigo: "CR333404R", cor: "Cinza", descricao: "Cinza escuro elegante" },
      ],
      cores: ["Preto", "Cinza"],
      textura: "Elegante",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-74.jpg",
      descricao:
        "Série elegante com destaque para preto texturizado. Inclui 2 ambientes aplicados (sala moderna e quarto clássico) mostrando versatilidade em decoração sofisticada.",
    },
    {
      id: 74,
      nome: "Série SE050 - Texturas Lineares Ambiente",
      modelos: [
        { codigo: "SE050510", cor: "Cinza", descricao: "Cinza claro linear ambiente" },
        { codigo: "SE050506", cor: "Cinza", descricao: "Cinza médio linear ambiente" },
        { codigo: "SE050504", cor: "Cinza", descricao: "Cinza escuro linear ambiente" },
      ],
      cores: ["Cinza"],
      textura: "Linear",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-75.jpg",
      descricao:
        "Série com texturas lineares aplicada em ambiente moderno. Demonstra elegância em sala contemporânea com tons neutros sofisticados.",
    },
    {
      id: 75,
      nome: "Série AD200 - Tons Claros Ambiente",
      modelos: [
        { codigo: "AD200012R", cor: "Branco", descricao: "Branco puro ambiente" },
        { codigo: "AD200011R", cor: "Azul", descricao: "Azul claro ambiente" },
        { codigo: "AD200010R", cor: "Cinza", descricao: "Cinza claro ambiente" },
        { codigo: "AD200009R", cor: "Bege", descricao: "Bege claro ambiente" },
      ],
      cores: ["Branco", "Azul", "Cinza", "Bege"],
      textura: "Ambiente",
      categoria: "Claro",
      imagem: "/catalog-images/lisos-76.jpg",
      descricao:
        "Série em tons claros com aplicação em ambiente real. Perfeita para criar espaços luminosos e arejados com máxima versatilidade.",
    },
    {
      id: 76,
      nome: "Série MT300 - Texturas Geométricas",
      modelos: [
        { codigo: "MT300703R", cor: "Bege", descricao: "Bege claro textura geométrica" },
        { codigo: "MT300504R", cor: "Bege", descricao: "Bege médio textura sutil" },
        { codigo: "MT300503R", cor: "Bege", descricao: "Bege claro textura suave" },
      ],
      cores: ["Bege"],
      textura: "Geométrica",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-77.jpg",
      descricao:
        "Série com texturas geométricas sutis em tons bege. Perfeita para adicionar interesse visual discreto aos ambientes elegantes.",
    },
    {
      id: 77,
      nome: "Série CR333 - Tons Linho Variados",
      modelos: [
        { codigo: "CR333002R", cor: "Bege", descricao: "Bege claro textura linho" },
        { codigo: "CR333003R", cor: "Dourado", descricao: "Dourado textura linho" },
        { codigo: "CR333004R", cor: "Azul", descricao: "Azul claro textura linho" },
        { codigo: "CR333005R", cor: "Azul", descricao: "Azul escuro textura linho" },
      ],
      cores: ["Bege", "Dourado", "Azul"],
      textura: "Linho",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-78.jpg",
      descricao:
        "Série com textura de linho em 4 variações de cores. Combina bege, dourado e azul para máxima versatilidade em projetos sofisticados.",
    },
    {
      id: 78,
      nome: "Série NN590/NN591 - Texturas Especiais Premium",
      modelos: [
        { codigo: "NN590802R", cor: "Branco", descricao: "Branco com padrão folhagem" },
        { codigo: "NN591706R", cor: "Cinza", descricao: "Cinza com textura mármore" },
        { codigo: "NN591102R", cor: "Verde", descricao: "Verde claro textura especial" },
        { codigo: "NN591002R", cor: "Cinza", descricao: "Cinza claro textura especial" },
      ],
      cores: ["Branco", "Cinza", "Verde"],
      textura: "Especial Premium",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-79.jpg",
      descricao:
        "Série premium com texturas especiais incluindo padrão folhagem e efeito mármore. Inclui ambiente aplicado mostrando sofisticação única.",
    },
    {
      id: 79,
      nome: "Série BR209 - Texturas Prateadas Premium",
      modelos: [
        { codigo: "BR209005R", cor: "Cinza", descricao: "Cinza prateado textura premium" },
        { codigo: "BR209004R", cor: "Cinza", descricao: "Cinza claro textura prateada" },
        { codigo: "BR209003R", cor: "Cinza", descricao: "Cinza médio textura prateada" },
        { codigo: "BR209002R", cor: "Cinza", descricao: "Cinza pérola textura premium" },
        { codigo: "BR209001R", cor: "Cinza", descricao: "Cinza suave textura prateada" },
      ],
      cores: ["Cinza", "Prata"],
      textura: "Prateada",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-80.jpg",
      descricao:
        "Série premium com 5 variações em texturas prateadas sofisticadas. Acabamento metalizado sutil que reflete a luz e cria ambientes elegantes e contemporâneos.",
    },
    {
      id: 80,
      nome: "Série CR333 - Gradação Linho Completa",
      modelos: [
        { codigo: "CR333016R", cor: "Branco", descricao: "Branco puro textura linho" },
        { codigo: "CR333017R", cor: "Cinza", descricao: "Cinza claro textura linho" },
        { codigo: "CR333018R", cor: "Cinza", descricao: "Cinza médio textura linho" },
        { codigo: "CR333019R", cor: "Cinza", descricao: "Cinza escuro textura linho" },
        { codigo: "CR333020R", cor: "Cinza", descricao: "Cinza chumbo textura linho" },
      ],
      cores: ["Branco", "Cinza"],
      textura: "Linho",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-81.jpg",
      descricao:
        "Série com gradação perfeita em textura de linho, do branco puro ao cinza chumbo. Ideal para criar ambientes sofisticados com transições harmoniosas.",
    },
    {
      id: 81,
      nome: "Série 6A097 - Tons Suaves Contemporâneos",
      modelos: [
        { codigo: "6A097508R", cor: "Cinza", descricao: "Cinza claro contemporâneo" },
        { codigo: "6A097509R", cor: "Verde", descricao: "Verde água contemporâneo" },
        { codigo: "6A097510R", cor: "Bege", descricao: "Bege claro contemporâneo" },
        { codigo: "6A097511R", cor: "Cinza", descricao: "Cinza texturizado contemporâneo" },
      ],
      cores: ["Cinza", "Verde", "Bege"],
      textura: "Contemporânea",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-82.jpg",
      descricao:
        "Série contemporânea com tons suaves e elegantes. Combina cinza, verde água e bege para criar ambientes modernos e acolhedores.",
    },
    {
      id: 82,
      nome: "Série BR207 - Efeito Concreto Gradação",
      modelos: [
        { codigo: "BR207005R", cor: "Cinza", descricao: "Cinza escuro efeito concreto" },
        { codigo: "BR207004R", cor: "Cinza", descricao: "Cinza médio efeito concreto" },
        { codigo: "BR207003R", cor: "Cinza", descricao: "Cinza claro efeito concreto" },
        { codigo: "BR207002R", cor: "Cinza", descricao: "Cinza pérola efeito concreto" },
        { codigo: "BR207001R", cor: "Cinza", descricao: "Cinza suave efeito concreto" },
      ],
      cores: ["Cinza"],
      textura: "Concreto",
      categoria: "Industrial",
      imagem: "/catalog-images/lisos-83.jpg",
      descricao:
        "Série com efeito concreto em gradação perfeita, do cinza escuro ao cinza suave. Ideal para criar ambientes industriais sofisticados com transições harmoniosas.",
    },
    {
      id: 83,
      nome: "Série CR333 - Tons Azuis e Cinzas",
      modelos: [
        { codigo: "CR333424R", cor: "Azul", descricao: "Azul médio texturizado" },
        { codigo: "CR333419R", cor: "Cinza", descricao: "Cinza escuro texturizado" },
        { codigo: "CR333420R", cor: "Cinza", descricao: "Cinza claro texturizado" },
        { codigo: "CR333421R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "CR333422R", cor: "Cinza", descricao: "Cinza chumbo texturizado" },
        { codigo: "CR333423R", cor: "Azul", descricao: "Azul claro texturizado" },
      ],
      cores: ["Azul", "Cinza"],
      textura: "Texturizada",
      categoria: "Azul",
      imagem: "/catalog-images/lisos-84.jpg",
      descricao:
        "Série com tons de azul e cinza em texturas sofisticadas. Perfeita para criar ambientes elegantes e relaxantes com toques de cor.",
    },
    {
      id: 84,
      nome: "Série 6A097 - Ambiente Minimalista",
      modelos: [
        { codigo: "6A097002R", cor: "Bege", descricao: "Bege claro minimalista" },
        { codigo: "6A097003R", cor: "Cinza", descricao: "Cinza claro minimalista" },
        { codigo: "6A097004R", cor: "Cinza", descricao: "Cinza médio minimalista" },
        { codigo: "6A097001R", cor: "Cinza", descricao: "Cinza azulado minimalista" },
      ],
      cores: ["Bege", "Cinza"],
      textura: "Minimalista",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-85.jpg",
      descricao:
        "Série minimalista com aplicação em ambiente moderno. Demonstra elegância em decoração contemporânea com peças de design e tons neutros sofisticados.",
    },
    {
      id: 85,
      nome: "Série SE050 - Texturas Lineares Verticais",
      modelos: [
        { codigo: "5E050803", cor: "Cinza", descricao: "Cinza claro linear vertical" },
        { codigo: "5E050802", cor: "Cinza", descricao: "Cinza médio linear vertical" },
        { codigo: "5E050401", cor: "Bege", descricao: "Bege claro linear vertical" },
        { codigo: "5E050403", cor: "Cinza", descricao: "Cinza pérola linear vertical" },
        { codigo: "5E050405", cor: "Bege", descricao: "Bege médio linear vertical" },
        { codigo: "5E050801", cor: "Cinza", descricao: "Cinza escuro linear vertical" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Linear Vertical",
      categoria: "Texturizado",
      imagem: "/catalog-images/lisos-86.jpg",
      descricao:
        "Série com texturas lineares verticais em tons de cinza e bege. Perfeita para criar efeitos de altura e elegância em ambientes contemporâneos.",
    },
    {
      id: 86,
      nome: "Série CR333 - Tons Pastéis Suaves",
      modelos: [
        { codigo: "CR333112R", cor: "Verde", descricao: "Verde claro pastel" },
        { codigo: "CR333113R", cor: "Cinza", descricao: "Cinza médio pastel" },
        { codigo: "CR333114R", cor: "Branco", descricao: "Branco puro pastel" },
        { codigo: "CR333115R", cor: "Branco", descricao: "Branco neve pastel" },
        { codigo: "CR333116R", cor: "Bege", descricao: "Bege claro pastel" },
        { codigo: "CR333117R", cor: "Azul", descricao: "Azul claro pastel" },
        { codigo: "CR333110R", cor: "Verde", descricao: "Verde água pastel" },
        { codigo: "CR333111R", cor: "Verde", descricao: "Verde menta pastel" },
      ],
      cores: ["Verde", "Cinza", "Branco", "Bege", "Azul"],
      textura: "Pastel",
      categoria: "Suave",
      imagem: "/catalog-images/lisos-87.jpg",
      descricao:
        "Série completa com 8 variações em tons pastéis suaves. Perfeita para criar ambientes delicados e relaxantes com cores leves e aconchegantes.",
    },
    {
      id: 87,
      nome: "Série 6A097 - Ambiente Moderno Completo",
      modelos: [
        { codigo: "6A097504R", cor: "Cinza", descricao: "Cinza claro ambiente" },
        { codigo: "6A097505R", cor: "Cinza", descricao: "Cinza médio ambiente" },
        { codigo: "6A097506R", cor: "Cinza", descricao: "Cinza escuro ambiente" },
        { codigo: "6A097507R", cor: "Azul", descricao: "Azul escuro ambiente" },
        { codigo: "6A097410R", cor: "Cinza", descricao: "Cinza pérola ambiente" },
        { codigo: "6A097501R", cor: "Bege", descricao: "Bege claro ambiente" },
        { codigo: "6A097503R", cor: "Bege", descricao: "Bege médio ambiente" },
      ],
      cores: ["Cinza", "Azul", "Bege"],
      textura: "Ambiente",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-88.jpg",
      descricao:
        "Série com aplicação em ambiente moderno completo. Demonstra versatilidade em decoração contemporânea com sofá cinza e parede verde, combinando tons neutros e acentos de cor.",
    },
    {
      id: 88,
      nome: "Série SE050/SE051 - Texturas Linho Premium",
      modelos: [
        { codigo: "5E050704", cor: "Cinza", descricao: "Cinza escuro textura linho" },
        { codigo: "5E050507", cor: "Cinza", descricao: "Cinza claro textura linho" },
        { codigo: "5E051004", cor: "Bege", descricao: "Bege dourado textura linho" },
        { codigo: "5E050705", cor: "Bege", descricao: "Bege claro textura linho" },
        { codigo: "5E051008", cor: "Bege", descricao: "Bege médio textura linho" },
        { codigo: "5E051003", cor: "Bege", descricao: "Bege natural textura linho" },
      ],
      cores: ["Cinza", "Bege", "Dourado"],
      textura: "Linho Premium",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-89.jpg",
      descricao:
        "Série premium com texturas de linho em tons de cinza e bege. Acabamentos sofisticados que adicionam elegância e naturalidade aos ambientes.",
    },
    {
      id: 89,
      nome: "CR333501R - Quarto Bege Elegante",
      modelos: [{ codigo: "CR333501R", cor: "Bege", descricao: "Bege texturizado para quartos elegantes" }],
      cores: ["Bege"],
      textura: "Texturizada",
      categoria: "Quarto",
      imagem: "/catalog-images/lisos-90.jpg",
      descricao:
        "Papel de parede bege texturizado com aplicação em quarto moderno. Cria ambientes aconchegantes e sofisticados com tons neutros que combinam com qualquer decoração.",
    },
    {
      id: 90,
      nome: "Série AD200 - Gradação Branco-Cinza",
      modelos: [
        { codigo: "AD200008R", cor: "Branco", descricao: "Branco puro premium" },
        { codigo: "AD200007R", cor: "Branco", descricao: "Branco suave texturizado" },
        { codigo: "AD200006R", cor: "Cinza", descricao: "Cinza claro prateado" },
        { codigo: "AD200005R", cor: "Cinza", descricao: "Cinza escuro elegante" },
      ],
      cores: ["Branco", "Cinza"],
      textura: "Premium",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-91.jpg",
      descricao:
        "Série com gradação perfeita do branco puro ao cinza escuro. Ideal para criar ambientes sofisticados com transições suaves e elegantes.",
    },
    {
      id: 91,
      nome: "Série AD200 - Tons Claros Premium",
      modelos: [
        { codigo: "AD200004R", cor: "Bege", descricao: "Bege claro premium" },
        { codigo: "AD200003R", cor: "Cinza", descricao: "Cinza azulado premium" },
        { codigo: "AD200002R", cor: "Branco", descricao: "Branco pérola premium" },
        { codigo: "AD200001R", cor: "Branco", descricao: "Branco puro premium" },
      ],
      cores: ["Bege", "Cinza", "Branco"],
      textura: "Premium",
      categoria: "Claro",
      imagem: "/catalog-images/lisos-92.jpg",
      descricao:
        "Série premium em tons claros e suaves. Perfeita para criar ambientes luminosos, elegantes e atemporais com máxima sofisticação.",
    },
    {
      id: 92,
      nome: "Série CR333 - Gradação Cinza Completa",
      modelos: [
        { codigo: "CR333445R", cor: "Branco", descricao: "Branco puro texturizado" },
        { codigo: "CR333441R", cor: "Cinza", descricao: "Cinza escuro texturizado" },
        { codigo: "CR333442R", cor: "Cinza", descricao: "Cinza médio texturizado" },
        { codigo: "CR333443R", cor: "Cinza", descricao: "Cinza claro texturizado" },
        { codigo: "CR333444R", cor: "Branco", descricao: "Branco suave texturizado" },
      ],
      cores: ["Branco", "Cinza"],
      textura: "Texturizada",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-93.jpg",
      descricao:
        "Série com gradação perfeita em 5 variações, do branco puro ao cinza escuro. Ideal para criar ambientes harmoniosos com transições elegantes.",
    },
    {
      id: 93,
      nome: "Série BR202 - Texturas Metalizadas Cruzadas",
      modelos: [
        { codigo: "BR202006", cor: "Cinza", descricao: "Cinza claro metalizado cruzado" },
        { codigo: "BR202005", cor: "Cinza", descricao: "Cinza médio metalizado cruzado" },
        { codigo: "BR202004", cor: "Cinza", descricao: "Cinza pérola metalizado cruzado" },
        { codigo: "BR202003", cor: "Cinza", descricao: "Cinza prata metalizado cruzado" },
        { codigo: "BR202002", cor: "Cinza", descricao: "Cinza brilhante metalizado cruzado" },
        { codigo: "BR202001", cor: "Cinza", descricao: "Cinza escuro metalizado cruzado" },
      ],
      cores: ["Cinza", "Prata"],
      textura: "Metalizada Cruzada",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-94.jpg",
      descricao:
        "Série exclusiva com texturas metalizadas cruzadas em tons de cinza. Efeito sofisticado que reflete a luz e cria ambientes luxuosos com movimento visual sutil.",
    },
    {
      id: 94,
      nome: "Série AD200 - Texturas Lineares Brancas",
      modelos: [
        { codigo: "AD200607R", cor: "Bege", descricao: "Bege claro linear vertical" },
        { codigo: "AD200606R", cor: "Branco", descricao: "Branco pérola linear vertical" },
        { codigo: "AD200605R", cor: "Branco", descricao: "Branco puro linear vertical" },
        { codigo: "AD200604R", cor: "Branco", descricao: "Branco neve linear vertical" },
      ],
      cores: ["Bege", "Branco"],
      textura: "Linear Vertical",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-95.jpg",
      descricao:
        "Série com texturas lineares verticais em tons brancos e bege. Inclui aplicação em ambiente moderno com sofá cinza, criando espaços luminosos e elegantes.",
    },
    {
      id: 95,
      nome: "Série CR333 - Tons Terrosos Neutros",
      modelos: [
        { codigo: "CR333425R", cor: "Bege", descricao: "Bege claro terroso" },
        { codigo: "CR333431R", cor: "Cinza", descricao: "Cinza escuro terroso" },
        { codigo: "CR333432R", cor: "Cinza", descricao: "Cinza médio terroso" },
        { codigo: "CR333433R", cor: "Cinza", descricao: "Cinza claro terroso" },
        { codigo: "CR333434R", cor: "Bege", descricao: "Bege médio terroso" },
      ],
      cores: ["Bege", "Cinza"],
      textura: "Terrosa",
      categoria: "Neutro",
      imagem: "/catalog-images/lisos-96.jpg",
      descricao:
        "Série com tons terrosos neutros em bege e cinza. Perfeita para criar ambientes aconchegantes e sofisticados com conexão à natureza.",
    },
    {
      id: 96,
      nome: "Série CR333 - Ambientes Azuis Modernos",
      modelos: [
        { codigo: "CR333440R", cor: "Azul", descricao: "Azul escuro moderno" },
        { codigo: "CR333437R", cor: "Cinza", descricao: "Cinza claro moderno" },
        { codigo: "CR333438R", cor: "Cinza", descricao: "Cinza escuro moderno" },
        { codigo: "CR333439R", cor: "Bege", descricao: "Bege claro moderno" },
      ],
      cores: ["Azul", "Cinza", "Bege"],
      textura: "Moderna",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-97.jpg",
      descricao:
        "Série com tons azuis e neutros aplicados em dois ambientes modernos. Inclui sala com sofá azul escuro e poltrona cinza com planta, demonstrando versatilidade em decoração contemporânea.",
    },
    {
      id: 97,
      nome: "Série BR210 - Texturas Metalizadas Brilhantes",
      modelos: [
        { codigo: "BR210001R", cor: "Cinza", descricao: "Cinza claro metalizado brilhante" },
        { codigo: "BR210002R", cor: "Prata", descricao: "Prata metalizado brilhante" },
        { codigo: "BR210003R", cor: "Prata", descricao: "Prata intenso metalizado brilhante" },
        { codigo: "BR210004R", cor: "Cinza", descricao: "Cinza pérola metalizado brilhante" },
      ],
      cores: ["Cinza", "Prata"],
      textura: "Metalizada Brilhante",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-98.jpg",
      descricao:
        "Série premium com texturas metalizadas brilhantes em tons de cinza e prata. Efeito luxuoso que reflete a luz e cria ambientes sofisticados com máximo brilho.",
    },
    {
      id: 98,
      nome: "Série BR203 - Efeito Prata Escovado",
      modelos: [
        { codigo: "BR203006R", cor: "Cinza", descricao: "Cinza claro efeito prata escovado" },
        { codigo: "BR203005R", cor: "Cinza", descricao: "Cinza médio efeito prata escovado" },
        { codigo: "BR203004R", cor: "Cinza", descricao: "Cinza pérola efeito prata escovado" },
        { codigo: "BR203003R", cor: "Cinza", descricao: "Cinza prata efeito prata escovado" },
        { codigo: "BR203002R", cor: "Cinza", descricao: "Cinza brilhante efeito prata escovado" },
        { codigo: "BR203001R", cor: "Cinza", descricao: "Cinza suave efeito prata escovado" },
      ],
      cores: ["Cinza", "Prata"],
      textura: "Prata Escovado",
      categoria: "Premium",
      imagem: "/catalog-images/lisos-99.jpg",
      descricao:
        "Série exclusiva com efeito prata escovado em 6 variações de cinza. Acabamento sofisticado que cria ambientes luxuosos com textura sutil e elegante.",
    },
    {
      id: 99,
      nome: "Série CR333 - Tons Neutros Ambiente",
      modelos: [
        { codigo: "CR333301R", cor: "Cinza", descricao: "Cinza claro texturizado" },
        { codigo: "CR333302R", cor: "Cinza", descricao: "Cinza escuro texturizado" },
        { codigo: "CR333303R", cor: "Verde", descricao: "Verde água texturizado" },
        { codigo: "CR333304R", cor: "Bege", descricao: "Bege claro texturizado" },
      ],
      cores: ["Cinza", "Verde", "Bege"],
      textura: "Texturizada",
      categoria: "Ambiente",
      imagem: "/catalog-images/lisos-100.jpg",
      descricao:
        "Série com tons neutros aplicados em dois ambientes modernos. Inclui sala com TV e quarto com sofá claro, demonstrando versatilidade em decoração contemporânea com tons suaves e elegantes.",
    },
    {
      id: 100,
      nome: "CR333011R - Sala Elegante",
      modelos: [
        { codigo: "CR333011R", cor: "Cinza", descricao: "Cinza médio textura linho para ambientes sofisticados" },
      ],
      cores: ["Cinza"],
      textura: "Linho",
      categoria: "Sala",
      imagem: "/catalog-images/lisos-101.jpg",
      descricao:
        "Papel de parede cinza médio com textura de linho aplicado em sala elegante com sofá branco e almofadas decorativas. Cria um ambiente sofisticado e acolhedor com neutralidade refinada.",
    },
    {
      id: 101,
      nome: "Série SE05 - Texturas Linho Modernas",
      modelos: [
        { codigo: "SE051007", cor: "Cinza", descricao: "Cinza escuro textura linho" },
        { codigo: "SE050702", cor: "Cinza", descricao: "Cinza médio textura linho" },
        { codigo: "SE051002", cor: "Cinza", descricao: "Cinza claro textura linho" },
      ],
      cores: ["Cinza"],
      textura: "Linho",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-102.jpg",
      descricao:
        "Série com texturas de linho em tons de cinza aplicada em ambiente moderno com sofá cinza claro, planta e quadro geométrico dourado. Perfeita para criar espaços contemporâneos e elegantes.",
    },
    {
      id: 102,
      nome: "Série SE05 - Gradação Completa Linho",
      modelos: [
        { codigo: "SE050113", cor: "Cinza", descricao: "Cinza escuro textura linho" },
        { codigo: "SE051001", cor: "Cinza", descricao: "Cinza médio escuro textura linho" },
        { codigo: "SE050703", cor: "Cinza", descricao: "Cinza médio textura linho" },
        { codigo: "SE051009", cor: "Cinza", descricao: "Cinza azulado textura linho" },
        { codigo: "SE051006", cor: "Cinza", descricao: "Cinza claro textura linho" },
        { codigo: "SE050701", cor: "Cinza", descricao: "Cinza prata textura linho" },
      ],
      cores: ["Cinza"],
      textura: "Linho",
      categoria: "Gradação",
      imagem: "/catalog-images/lisos-103.jpg",
      descricao:
        "Série com gradação perfeita em 6 variações de cinza com textura de linho. Ideal para criar ambientes sofisticados com transições harmoniosas e elegantes.",
    },
    {
      id: 103,
      nome: "Série CR333 - Tons Neutros Linho",
      modelos: [
        { codigo: "CR333008R", cor: "Cinza", descricao: "Cinza claro textura linho" },
        { codigo: "CR333009R", cor: "Cinza", descricao: "Cinza médio textura linho" },
        { codigo: "CR333010R", cor: "Cinza", descricao: "Cinza escuro textura linho" },
        { codigo: "CR333006R", cor: "Bege", descricao: "Bege claro textura linho" },
        { codigo: "CR333007R", cor: "Bege", descricao: "Bege natural textura linho" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Linho",
      categoria: "Neutro",
      imagem: "/catalog-images/lisos-104.jpg",
      descricao:
        "Série com 5 variações em tons neutros de cinza e bege com textura de linho. Perfeita para criar ambientes elegantes e atemporais com máxima sofisticação.",
    },
    {
      id: 104,
      nome: "Série CR333 - Tons Claros Premium",
      modelos: [
        { codigo: "CR333601R", cor: "Bege", descricao: "Bege claro premium" },
        { codigo: "CR333603R", cor: "Cinza", descricao: "Cinza muito claro premium" },
        { codigo: "CR333602R", cor: "Branco", descricao: "Branco puro premium" },
      ],
      cores: ["Bege", "Cinza", "Branco"],
      textura: "Premium",
      categoria: "Quarto",
      imagem: "/catalog-images/lisos-105.jpg",
      descricao:
        "Série premium em tons claros com aplicação em quarto minimalista. Cria ambientes luminosos, elegantes e relaxantes com máxima sofisticação e pureza visual.",
    },
    {
      id: 105,
      nome: "Série SE05 - Texturas Especiais Modernas",
      modelos: [
        { codigo: "SE050108", cor: "Azul", descricao: "Azul texturizado moderno" },
        { codigo: "SE050109", cor: "Cinza", descricao: "Cinza texturizado moderno" },
        { codigo: "SE050110", cor: "Verde", descricao: "Verde textura trançada moderna" },
      ],
      cores: ["Azul", "Cinza", "Verde"],
      textura: "Especial",
      categoria: "Moderno",
      imagem: "/catalog-images/lisos-106.jpg",
      descricao:
        "Série com texturas especiais incluindo o exclusivo padrão trançado verde. Aplicação em ambiente moderno com poltrona cinza, perfeita para criar espaços contemporâneos com personalidade única.",
    },
  ]

  const cores = [
    "Todas as Cores",
    "Branco",
    "Cinza",
    "Bege",
    "Creme",
    "Verde",
    "Azul",
    "Marrom",
    "Preto",
    "Natural",
    "Terracota",
    "Rosa",
    "Vermelho",
    "Amarelo",
    "Dourado",
    "Lilás",
    "Roxo",
    "Prata",
  ]

  if (!cores.includes("Marrom")) {
    cores.push("Marrom")
  }

  if (!cores.includes("Vermelho")) {
    cores.push("Vermelho")
  }

  if (!cores.includes("Azul")) {
    cores.push("Azul")
  }

  if (!cores.includes("Roxo")) {
    cores.push("Roxo")
  }

  if (!cores.includes("Prata")) {
    cores.push("Prata")
  }

  const filteredProducts = produtos.filter((produto) => {
    const matchesSearch = produto.cores.some((cor) => cor.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesColor = selectedColor === "Todas as Cores" || produto.cores.includes(selectedColor)
    return matchesSearch && matchesColor
  })

  const openModal = (produto: any) => {
    setSelectedProduto(produto)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setSelectedProduto(null)
    setIsModalOpen(false)
  }

  const goToPrevious = () => {
    if (selectedProduto && filteredProducts.length > 0) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const previousIndex = currentIndex === 0 ? filteredProducts.length - 1 : currentIndex - 1
      setSelectedProduto(filteredProducts[previousIndex])
    }
  }

  const goToNext = () => {
    if (selectedProduto && filteredProducts.length > 0) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const nextIndex = currentIndex === filteredProducts.length - 1 ? 0 : currentIndex + 1
      setSelectedProduto(filteredProducts[nextIndex])
    }
  }

  const handlePedirOrcamento = (produto: any) => {
    const message = `Olá! Gostaria de solicitar um orçamento para o produto: ${produto.nome}. Modelos inclusos: ${produto.modelos.map((m: any) => m.codigo).join(", ")}.`
    const whatsappUrl = `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-100">
      <Header />

      <div className="pt-24">
        {/* Breadcrumb */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-3 md:py-4">
            <div className="flex items-center gap-3 md:gap-4">
              <Link href="/" className="flex items-center gap-2 text-blue-700 hover:text-blue-800 transition-colors">
                <ArrowLeft className="w-4 h-4 md:w-5 md:h-5" />
                <span className="font-medium text-sm md:text-base">Voltar</span>
              </Link>
              <div className="h-4 md:h-6 w-px bg-gray-300" />
              <h1 className="text-xl md:text-2xl font-bold text-gray-900">Catálogo Lisos</h1>
            </div>
          </div>
        </div>

        {/* Hero Section */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-12 md:py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-3 md:mb-4">Coleção Lisos</h2>
            <p className="text-lg md:text-xl lg:text-2xl mb-4 md:mb-6 text-blue-100">
              Elegância minimalista em cores neutras
            </p>
            <p className="text-base md:text-lg text-blue-200 max-w-2xl mx-auto px-4">
              Descubra nossa linha de papéis lisos, perfeitos para criar ambientes clean e sofisticados.
            </p>
          </div>
        </div>

        {/* Filtros e Busca */}
        <div className="container mx-auto px-4 py-6 md:py-8">
          <div className="bg-white rounded-lg shadow-sm border p-4 md:p-6 mb-6 md:mb-8">
            <div className="flex flex-col gap-4">
              {/* Busca */}
              <div className="w-full">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar por cor..."
                    className="pl-10 h-12 text-base"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              {/* Filtros */}
              <div className="flex flex-col gap-3">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600 font-medium">Filtrar por cor:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {cores.map((cor) => (
                    <Badge
                      key={cor}
                      variant={cor === selectedColor ? "default" : "outline"}
                      className="cursor-pointer hover:bg-blue-100 px-3 py-1.5 text-sm"
                      onClick={() => setSelectedColor(cor)}
                    >
                      {cor}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Grid de Produtos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
            {filteredProducts.map((produto) => (
              <div
                key={produto.id}
                className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-all duration-300 overflow-hidden group"
              >
                <div className="relative">
                  <Image
                    src={produto.imagem || "/placeholder.svg"}
                    alt={produto.nome}
                    width={450}
                    height={300}
                    className="w-full aspect-[3/2] object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                    onClick={() => openModal(produto)}
                  />
                  <div className="absolute top-2 md:top-3 right-2 md:right-3 flex gap-1 md:gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="w-8 h-8 md:w-10 md:h-10 p-0 bg-white/90 hover:bg-white"
                      onClick={() => openModal(produto)}
                    >
                      <Eye className="w-3 h-3 md:w-4 md:h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="w-8 h-8 md:w-10 md:h-10 p-0 bg-white/90 hover:bg-white"
                    >
                      <Heart className="w-3 h-3 md:w-4 md:h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="w-8 h-8 md:w-10 md:h-10 p-0 bg-white/90 hover:bg-white"
                    >
                      <Share2 className="w-3 h-3 md:w-4 md:h-4" />
                    </Button>
                  </div>
                  <div className="absolute bottom-2 md:bottom-3 left-2 md:left-3 flex gap-1">
                    {produto.cores.slice(0, 3).map((cor, index) => (
                      <div
                        key={index}
                        className="w-3 h-3 md:w-4 md:h-4 rounded-full border-2 border-white shadow-sm"
                        style={{
                          backgroundColor:
                            cor === "Cinza"
                              ? "#6B7280"
                              : cor === "Bege"
                                ? "#D2B48C"
                                : cor === "Creme"
                                  ? "#F5F5DC"
                                  : cor === "Branco"
                                    ? "#FFFFFF"
                                    : cor === "Verde"
                                      ? "#10B981"
                                      : cor === "Azul"
                                        ? "#3B82F6"
                                        : cor === "Marrom"
                                          ? "#8B4513"
                                          : cor === "Preto"
                                            ? "#000000"
                                            : cor === "Natural"
                                              ? "#DEB887"
                                              : cor === "Terracota"
                                                ? "#E2725B"
                                                : cor === "Rosa"
                                                  ? "#F472B6"
                                                  : cor === "Vermelho"
                                                    ? "#EF4444"
                                                    : cor === "Dourado"
                                                      ? "#FFD700"
                                                      : cor === "Amarelo"
                                                        ? "#FCD34D"
                                                        : cor === "Roxo"
                                                          ? "#800080"
                                                          : cor === "Prata"
                                                            ? "#C0C0C0"
                                                            : "#9CA3AF",
                        }}
                      />
                    ))}
                    {produto.cores.length > 3 && (
                      <div className="w-3 h-3 md:w-4 md:h-4 rounded-full border-2 border-white shadow-sm bg-gray-400 flex items-center justify-center text-xs text-white font-bold">
                        +
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-3 md:p-4">
                  <h3 className="font-semibold text-base md:text-lg text-gray-900 mb-2 line-clamp-2">{produto.nome}</h3>
                  <p className="text-xs md:text-sm text-gray-600 mb-1 md:mb-2">
                    {produto.modelos.length} {produto.modelos.length === 1 ? "modelo incluso" : "modelos inclusos"}
                  </p>
                  <p className="text-xs md:text-sm text-gray-600 mb-3 line-clamp-2">
                    Cores: {produto.cores.slice(0, 3).join(", ")}
                    {produto.cores.length > 3 && "..."}
                  </p>

                  <div className="flex items-center justify-center">
                    <Button
                      className="w-full bg-green-600 hover:bg-green-700 text-white h-10 md:h-11 text-sm md:text-base"
                      onClick={() => handlePedirOrcamento(produto)}
                    >
                      💬 Pedir Orçamento
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-500">Tente buscar por uma cor diferente</p>
            </div>
          )}

          {/* Informações Adicionais */}
        </div>
      </div>
      {/* Modal de Produto */}
      {isModalOpen && selectedProduto && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="relative max-w-6xl max-h-full w-full flex flex-col">
            {/* Image Container */}
            <div className="relative flex-1 flex items-center justify-center mb-4">
              <Image
                src={selectedProduto.imagem || "/placeholder.svg"}
                alt={selectedProduto.nome}
                width={1200}
                height={800}
                className="max-w-full max-h-[70vh] object-contain rounded-lg"
                priority
              />

              {/* Close Button */}
              <button
                className="absolute top-4 right-4 text-white bg-black bg-opacity-50 hover:bg-opacity-75 rounded-full w-12 h-12 flex items-center justify-center transition-all duration-200 hover:scale-110"
                onClick={closeModal}
                aria-label="Fechar modal"
              >
                <X className="w-6 h-6" />
              </button>

              {/* Navigation Arrows */}
              {filteredProducts.length > 1 && (
                <>
                  <button
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white bg-black bg-opacity-50 hover:bg-opacity-75 rounded-full w-12 h-12 flex items-center justify-center transition-all duration-200 hover:scale-110"
                    onClick={goToPrevious}
                    aria-label="Produto anterior"
                  >
                    <ArrowLeft className="w-6 h-6" />
                  </button>

                  <button
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white bg-black bg-opacity-50 hover:bg-opacity-75 rounded-full w-12 h-12 flex items-center justify-center transition-all duration-200 hover:scale-110"
                    onClick={goToNext}
                    aria-label="Próximo produto"
                  >
                    <ArrowRight className="w-6 h-6" />
                  </button>
                </>
              )}

              {/* Counter */}
              {filteredProducts.length > 1 && (
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-50 text-white px-3 py-1 rounded-full text-sm">
                  {filteredProducts.findIndex((p) => p.id === selectedProduto.id) + 1} / {filteredProducts.length}
                </div>
              )}
            </div>

            {/* Content */}
            <div className="bg-black bg-opacity-75 text-white p-6 rounded-lg max-w-full max-h-[30vh] overflow-y-auto">
              <h3 className="font-bold text-xl mb-3">{selectedProduto.nome}</h3>
              {selectedProduto.descricao && <p className="text-sm mb-4 text-gray-200">{selectedProduto.descricao}</p>}
              <div className="text-sm">
                <strong className="block mb-2">Modelos inclusos ({selectedProduto.modelos.length}):</strong>
                <div className="space-y-2">
                  {selectedProduto.modelos.map((modelo: any, index: number) => (
                    <div key={index} className="bg-white bg-opacity-10 p-2 rounded">
                      <strong>{modelo.codigo}</strong> - {modelo.cor}
                      {modelo.descricao && <div className="text-xs text-gray-300 mt-1">{modelo.descricao}</div>}
                    </div>
                  ))}
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <span className="text-xs text-gray-400">Cores disponíveis:</span>
                {selectedProduto.cores.map((cor: string, index: number) => (
                  <span key={index} className="bg-white bg-opacity-20 px-2 py-1 rounded text-xs">
                    {cor}
                  </span>
                ))}
              </div>
              <div className="mt-4 flex gap-3">
                <Button
                  className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => handlePedirOrcamento(selectedProduto)}
                >
                  💬 Pedir Orçamento
                </Button>
                <Button
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-black"
                  onClick={closeModal}
                >
                  Fechar
                </Button>
              </div>
              <p className="text-xs text-gray-400 mt-4">
                Use as setas do teclado ou clique nas setas para navegar • ESC ou clique fora para fechar
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
