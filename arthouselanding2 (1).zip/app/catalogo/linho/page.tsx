"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"

export default function RedirectToLinho() {
  const router = useRouter()

  useEffect(() => {
    // Redireciona para a versão correta do catálogo
    router.replace("/catalogos/linho")
  }, [router])

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-100 flex items-center justify-center">
      <div className="text-center">
        <div className="inline-block h-16 w-16 animate-spin rounded-full border-4 border-solid border-amber-600 border-r-transparent"></div>
        <h2 className="mt-4 text-xl font-semibold text-gray-700">Redirecionando para o catálogo...</h2>
      </div>
    </div>
  )
}
