"use client"

import type React from "react"
import { useCallback, useEffect } from "react"
import Image from "next/image"
import { ArrowLeft, ArrowRight, X } from "lucide-react"

interface ImageModalProps {
  isOpen: boolean
  onClose: () => void
  imageSrc: string
  imageAlt: string
  imageTitle: string
  description?: string
  modelosHtml?: string
  currentIndex?: number
  totalItems?: number
  onNext?: () => void
  onPrev?: () => void
}

const ImageModal: React.FC<ImageModalProps> = ({
  isOpen,
  onClose,
  imageSrc,
  imageAlt,
  imageTitle,
  description,
  modelosHtml,
  currentIndex = 0,
  totalItems = 0,
  onNext,
  onPrev,
}) => {
  // Prevent scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "auto"
    }
    return () => {
      document.body.style.overflow = "auto"
    }
  }, [isOpen])

  // Close on escape key
  const handleEsc = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
      if (e.key === "ArrowLeft" && onPrev) onPrev()
      if (e.key === "ArrowRight" && onNext) onNext()
    },
    [onClose, onNext, onPrev],
  )

  useEffect(() => {
    if (isOpen) {
      window.addEventListener("keydown", handleEsc)
      return () => window.removeEventListener("keydown", handleEsc)
    }
  }, [handleEsc, isOpen])

  if (!isOpen) return null

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <div className="relative max-w-6xl max-h-full w-full flex flex-col">
        {/* Image Container */}
        <div className="relative flex-1 flex items-center justify-center mb-4">
          <Image
            src={imageSrc || "/placeholder.svg"}
            alt={imageAlt}
            width={1200}
            height={800}
            className="max-w-full max-h-[70vh] object-contain rounded-lg"
            priority
          />

          {/* Close Button */}
          <button
            className="absolute top-4 right-4 text-white bg-black bg-opacity-50 hover:bg-opacity-75 rounded-full w-12 h-12 flex items-center justify-center transition-all duration-200 hover:scale-110"
            onClick={onClose}
            aria-label="Fechar modal"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Navigation Arrows */}
          {onPrev && totalItems > 1 && (
            <button
              className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white bg-black bg-opacity-50 hover:bg-opacity-75 rounded-full w-12 h-12 flex items-center justify-center transition-all duration-200 hover:scale-110"
              onClick={onPrev}
              aria-label="Produto anterior"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
          )}

          {onNext && totalItems > 1 && (
            <button
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white bg-black bg-opacity-50 hover:bg-opacity-75 rounded-full w-12 h-12 flex items-center justify-center transition-all duration-200 hover:scale-110"
              onClick={onNext}
              aria-label="Próximo produto"
            >
              <ArrowRight className="w-6 h-6" />
            </button>
          )}

          {/* Counter */}
          {totalItems > 1 && (
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-50 text-white px-3 py-1 rounded-full text-sm">
              {currentIndex + 1} / {totalItems}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="bg-black bg-opacity-75 text-white p-6 rounded-lg max-w-full max-h-[30vh] overflow-y-auto">
          <h3 className="font-bold text-xl mb-3">{imageTitle}</h3>
          {description && <p className="text-sm mb-4 text-gray-200">{description}</p>}
          {modelosHtml && (
            <div className="text-sm">
              <strong className="block mb-2">Modelos inclusos:</strong>
              <div dangerouslySetInnerHTML={{ __html: modelosHtml }} className="space-y-1" />
            </div>
          )}
          <p className="text-xs text-gray-400 mt-4">
            Use as setas do teclado ou clique nas setas para navegar • ESC ou clique fora para fechar
          </p>
        </div>
      </div>
    </div>
  )
}

export default ImageModal
