import Link from "next/link"
import { ArrowLeft, Heart, Users, Award, Sparkles, Clock, Shield, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"

export default function SobrePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-50">
      <Header />
      <WhatsAppFloat />

      {/* Back Button */}
      <div className="container mx-auto px-4 py-6 pt-24">
        <Button variant="ghost" asChild className="mb-6 hover:bg-green-100 transition-colors">
          <Link href="/" className="flex items-center gap-2 text-green-700">
            <ArrowLeft className="h-4 w-4" />
            Voltar ao início
          </Link>
        </Button>
      </div>

      {/* Hero Section */}
      <section className="container mx-auto px-4 pb-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Heart className="h-4 w-4" />
              Feito com amor há 25 anos
            </div>
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-green-600 to-green-800 bg-clip-text text-transparent mb-6">
              Nossa História de Amor
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Não somos apenas uma loja. Somos uma família que transforma sonhos em realidade, uma parede de cada vez.
              ✨
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-16">
            <Card className="text-center p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Clock className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-3xl font-bold text-green-600 mb-2">25+</h3>
                <p className="text-gray-600 font-medium">Anos de Experiência</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-3xl font-bold text-blue-600 mb-2">5000+</h3>
                <p className="text-gray-600 font-medium">Famílias Felizes</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-3xl font-bold text-purple-600 mb-2">100%</h3>
                <p className="text-gray-600 font-medium">Especializada</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="text-3xl font-bold text-yellow-600 mb-2">98%</h3>
                <p className="text-gray-600 font-medium">Indicações</p>
              </CardContent>
            </Card>
          </div>

          {/* Main Story */}
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div className="space-y-6">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">💝 Por que escolhemos cuidar de você?</h2>
              <p className="text-lg text-gray-700 leading-relaxed">
                Há 25 anos, começamos com um sonho simples: <strong>transformar casas em lares</strong>. Descobrimos que
                não vendemos apenas papel de parede — vendemos momentos especiais, memórias que grudam na parede junto
                com nossos produtos.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                Cada cliente que entra na Art House não é apenas um número. É uma história única, um sonho esperando
                para acontecer. Por isso, nosso atendimento é como uma conversa entre amigos —{" "}
                <strong>caloroso, honesto e cheio de carinho</strong>.
              </p>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-blue-500 rounded-2xl blur-xl opacity-20"></div>
              <img
                src="/loja-interior.jpeg"
                alt="Interior acolhedor da Art House"
                className="relative rounded-2xl shadow-2xl w-full h-80 object-cover"
              />
            </div>
          </div>

          {/* Values Section */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">💚 O que nos move todos os dias</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="p-8 border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100 hover:shadow-xl transition-all duration-300">
                <CardContent className="p-0 text-center">
                  <div className="w-20 h-20 bg-green-200 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Heart className="h-10 w-10 text-green-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Amor em Cada Detalhe</h3>
                  <p className="text-gray-700">
                    Tratamos cada projeto como se fosse nossa própria casa. Seu sorriso é nossa maior recompensa.
                  </p>
                </CardContent>
              </Card>

              <Card className="p-8 border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100 hover:shadow-xl transition-all duration-300">
                <CardContent className="p-0 text-center">
                  <div className="w-20 h-20 bg-blue-200 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Shield className="h-10 w-10 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Confiança Construída</h3>
                  <p className="text-gray-700">
                    25 anos de relacionamentos sólidos. Nossos clientes se tornam nossa família estendida.
                  </p>
                </CardContent>
              </Card>

              <Card className="p-8 border-0 shadow-lg bg-gradient-to-br from-purple-50 to-purple-100 hover:shadow-xl transition-all duration-300">
                <CardContent className="p-0 text-center">
                  <div className="w-20 h-20 bg-purple-200 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Sparkles className="h-10 w-10 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Magia Personalizada</h3>
                  <p className="text-gray-700">
                    Cada ambiente é único, assim como você. Criamos soluções sob medida para seus sonhos.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Promise Section */}
          <Card className="p-12 border-0 shadow-2xl bg-gradient-to-r from-green-600 to-green-700 text-white mb-16">
            <CardContent className="p-0 text-center">
              <h2 className="text-3xl font-bold mb-6">🤝 Nossa Promessa para Você</h2>
              <div className="grid md:grid-cols-2 gap-8 text-left">
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-lg">Atendimento humanizado, nunca robotizado</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-lg">Produtos de qualidade que duram anos</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-lg">Preços justos e transparentes</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-lg">Suporte completo do início ao fim</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-lg">Criações exclusivas e personalizadas</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-lg">Relacionamento que vai além da venda</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Testimonial */}
          <Card className="p-8 border-0 shadow-lg bg-white/80 backdrop-blur-sm mb-16">
            <CardContent className="p-0 text-center">
              <div className="flex justify-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-6 w-6 text-yellow-400 fill-current" />
                ))}
              </div>
              <blockquote className="text-xl italic text-gray-700 mb-6 max-w-3xl mx-auto">
                "A Art House não apenas decorou nossa casa, eles criaram o lar dos nossos sonhos. O carinho e atenção
                que recebemos foi além de qualquer expectativa. Hoje, cada parede conta nossa história de amor."
              </blockquote>
              <cite className="text-gray-600 font-medium">— Maria e João, clientes há 8 anos</cite>
            </CardContent>
          </Card>

          {/* CTA Section */}
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">🌟 Pronto para transformar seu lar?</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Vamos conversar! Conte-nos seus sonhos e vamos criar algo incrível juntos.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-4">
                <a
                  href="https://wa.me/5561986792057?text=Olá! Acabei de conhecer a história da Art House e gostaria de transformar meu lar também! 💚"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  💬 Vamos Conversar no WhatsApp
                </a>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="text-lg px-8 py-4 border-green-600 text-green-600 hover:bg-green-50"
              >
                <Link href="/contato">📍 Visite Nossa Loja</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
