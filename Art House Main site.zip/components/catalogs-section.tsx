"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

export default function CatalogsSection() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)

  const catalogs = [
    {
      title: "Lisos",
      description: "Cores sólidas e elegantes para todos os ambientes",
      image: "/catalog-covers/lisos-cover.png",
      href: "/catalogos/lisos",
      color: "from-blue-500/20 via-blue-500/5 to-transparent",
    },
    {
      title: "Texturas",
      description: "Texturas sutis que adicionam profundidade e elegância",
      image: "/catalog-covers/texturas-cover.png",
      href: "/catalogos/texturas",
      color: "from-amber-500/20 via-amber-500/5 to-transparent",
    },
    {
      title: "Infantis",
      description: "Designs divertidos e coloridos para quartos de crianças",
      image: "/catalog-covers/infantis-cover.png",
      href: "/catalogos/infantis",
      color: "from-pink-500/20 via-pink-500/5 to-transparent",
    },
    {
      title: "Geométricos",
      description: "Padrões modernos e contemporâneos para espaços arrojados",
      image: "/catalog-covers/geometricos-cover.png",
      href: "/catalogos/geometricos",
      color: "from-purple-500/20 via-purple-500/5 to-transparent",
    },
    {
      title: "Estampados",
      description: "Estampas exclusivas para ambientes com personalidade",
      image: "/catalog-covers/estampados-cover.png",
      href: "/catalogos/estampados",
      color: "from-green-500/20 via-green-500/5 to-transparent",
    },
    {
      title: "3D",
      description: "Efeitos tridimensionais que transformam qualquer espaço",
      image: "/catalog-covers/3d-cover.png",
      href: "/catalogos/3d",
      color: "from-indigo-500/20 via-indigo-500/5 to-transparent",
    },
    {
      title: "Folhagens",
      description: "Padrões naturais que trazem o verde para dentro de casa",
      image: "/catalog-covers/folhagens-cover.png",
      href: "/catalogos/folhagens",
      color: "from-emerald-500/20 via-emerald-500/5 to-transparent",
    },
    {
      title: "Ripados",
      description: "Texturas que imitam madeira para ambientes aconchegantes",
      image: "/catalog-covers/ripados-cover.jpg",
      href: "/catalogos/ripados",
      color: "from-orange-500/20 via-orange-500/5 to-transparent",
    },
    {
      title: "Personalizados",
      description: "Crie seu próprio design exclusivo para seu ambiente",
      image: "/catalog-covers/personalizados-cover.png",
      href: "/catalogos/personalizados",
      color: "from-red-500/20 via-red-500/5 to-transparent",
    },
    {
      title: "Mica",
      description: "Papéis com partículas de mica para um brilho sofisticado",
      image: "/catalog-covers/mica-cover.png",
      href: "/catalogos/mica",
      color: "from-yellow-500/20 via-yellow-500/5 to-transparent",
    },
    {
      title: "Clássicos",
      description: "Designs atemporais que nunca saem de moda",
      image: "/catalog-covers/classicos-cover.png",
      href: "/catalogos/classicos",
      color: "from-teal-500/20 via-teal-500/5 to-transparent",
    },
    {
      title: "Linho",
      description: "Texturas que imitam tecidos naturais para ambientes sofisticados",
      image: "/catalog-covers/linho-cover.png",
      href: "/catalogos/linho",
      color: "from-amber-500/20 via-amber-500/5 to-transparent",
    },
  ]

  return (
    <section id="catalogos" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Nossos Catálogos</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore nossa ampla variedade de papéis de parede para todos os estilos e ambientes
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {catalogs.map((catalog, index) => (
            <Link href={catalog.href} key={index}>
              <motion.div
                className="group relative h-[280px] overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm transition-all hover:shadow-lg"
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <div className="absolute inset-0 z-10 bg-gradient-to-b from-transparent via-black/50 to-black/80" />
                <div
                  className={cn(
                    "absolute inset-0 z-10 bg-gradient-to-t opacity-0 transition-opacity group-hover:opacity-100",
                    catalog.color,
                  )}
                />
                <div className="relative h-full w-full overflow-hidden">
                  <Image
                    src={catalog.image || "/placeholder.svg"}
                    alt={catalog.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="absolute inset-0 z-20 flex flex-col justify-end p-6">
                  <h3 className="font-bold text-xl text-white mb-1">{catalog.title}</h3>
                  <p className="text-sm text-gray-200 line-clamp-2">{catalog.description}</p>
                  <div className="mt-4">
                    <span className="inline-flex items-center justify-center rounded-full bg-white/20 backdrop-blur-sm px-3 py-1 text-sm font-medium text-white transition-colors group-hover:bg-white group-hover:text-gray-900">
                      Ver Catálogo
                    </span>
                  </div>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
