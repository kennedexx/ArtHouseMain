"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Share2, Search, Filter, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"
import ImageModal from "@/components/ImageModal"
import { useState } from "react"

export default function Catalogo3D() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedColor, setSelectedColor] = useState("Todas as Cores")
  const [selectedProduto, setSelectedProduto] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const produtos = [
    // Geométricos 3D - Imagem 3d-1.jpg
    {
      id: 1,
      nome: "3D Geométrico Hexagonal Premium",
      modelos: [
        { codigo: "GR400901R", cor: "Cinza", descricao: "3D Hexágonos Cinza Claro" },
        { codigo: "GR400902R", cor: "Branco", descricao: "3D Hexágonos Branco" },
        { codigo: "GR400903R", cor: "Bege", descricao: "3D Hexágonos Bege" },
      ],
      cores: ["Cinza", "Branco", "Bege"],
      textura: "3D Geométrico",
      categoria: "Geométrico Premium",
      imagem: "/catalog-images/3d-1.jpg",
      descricao: "Ambiente moderno com poltrona turquesa destacando padrões geométricos 3D hexagonais e repetitivos.",
    },

    // Madeira 3D Vertical - Imagem 3d-2.jpg
    {
      id: 2,
      nome: "3D Madeira Vertical Contemporânea",
      modelos: [
        { codigo: "MT300201R", cor: "Cinza", descricao: "3D Madeira Vertical Cinza" },
        { codigo: "MT300202R", cor: "Marrom", descricao: "3D Madeira Vertical Marrom" },
        { codigo: "MT300203R", cor: "Bege", descricao: "3D Madeira Vertical Bege" },
      ],
      cores: ["Cinza", "Marrom", "Bege"],
      textura: "3D Madeira",
      categoria: "Madeira 3D",
      imagem: "/catalog-images/3d-2.jpg",
      descricao: "Quarto moderno com efeito de ripado vertical em madeira, criando profundidade e elegância.",
    },

    // Listrados Neutros - Imagem 3d-3.jpg
    {
      id: 3,
      nome: "3D Listras Neutras Elegantes",
      modelos: [
        { codigo: "AD200801R", cor: "Bege", descricao: "3D Listras Bege Claro" },
        { codigo: "AD200802R", cor: "Creme", descricao: "3D Listras Creme" },
        { codigo: "AD200803R", cor: "Marrom", descricao: "3D Listras Marrom Claro" },
        { codigo: "AD200804R", cor: "Marrom", descricao: "3D Listras Marrom Escuro" },
      ],
      cores: ["Bege", "Creme", "Marrom"],
      textura: "3D Listrado",
      categoria: "Listrado Premium",
      imagem: "/catalog-images/3d-3.jpg",
      descricao: "Sala de estar sofisticada com listras verticais em tons neutros, criando amplitude visual.",
    },

    // Madeira Gradação - Imagem 3d-4.jpg
    {
      id: 4,
      nome: "3D Madeira Gradação Completa",
      modelos: [
        { codigo: "AD200805R", cor: "Preto", descricao: "3D Madeira Escura" },
        { codigo: "AD200806R", cor: "Cinza", descricao: "3D Madeira Cinza" },
        { codigo: "AD200807R", cor: "Bege", descricao: "3D Madeira Bege" },
        { codigo: "AD200808R", cor: "Marrom", descricao: "3D Madeira Marrom" },
      ],
      cores: ["Preto", "Cinza", "Bege", "Marrom"],
      textura: "3D Madeira",
      categoria: "Madeira Premium",
      imagem: "/catalog-images/3d-4.jpg",
      descricao: "Coleção completa de madeiras 3D em gradação do claro ao escuro para máxima versatilidade.",
    },

    // Pedra Natural - Imagem 3d-5.jpg
    {
      id: 5,
      nome: "3D Pedra Natural Empilhada",
      modelos: [
        { codigo: "MT301001R", cor: "Cinza", descricao: "3D Pedra Cinza Natural" },
        { codigo: "MT301002R", cor: "Bege", descricao: "3D Pedra Bege Natural" },
        { codigo: "MT301003R", cor: "Branco", descricao: "3D Pedra Branca Natural" },
      ],
      cores: ["Cinza", "Bege", "Branco"],
      textura: "3D Pedra",
      categoria: "Pedra Natural",
      imagem: "/catalog-images/3d-5.jpg",
      descricao:
        "Sala de jantar moderna com efeito de pedras naturais empilhadas, criando textura rústica sofisticada.",
    },

    // Pedra TV Wall - Imagem 3d-6.jpg
    {
      id: 6,
      nome: "3D Pedra TV Wall Premium",
      modelos: [
        { codigo: "MT301002R", cor: "Cinza", descricao: "3D Pedra TV Wall Cinza" },
        { codigo: "MT301004R", cor: "Preto", descricao: "3D Pedra TV Wall Preta" },
        { codigo: "MT301005R", cor: "Bege", descricao: "3D Pedra TV Wall Bege" },
      ],
      cores: ["Cinza", "Preto", "Bege"],
      textura: "3D Pedra",
      categoria: "TV Wall Premium",
      imagem: "/catalog-images/3d-6.jpg",
      descricao: "Painel para TV com efeito de pedra natural empilhada, ideal para salas de estar modernas.",
    },

    // Produtos originais mantidos
    {
      id: 7,
      nome: "3D Listras Madeira Contemporânea",
      modelos: [
        { codigo: "TD500101R", cor: "Marrom", descricao: "3D Listras Madeira Escura" },
        { codigo: "TD500102R", cor: "Bege", descricao: "3D Listras Madeira Bege" },
        { codigo: "TD500103R", cor: "Creme", descricao: "3D Listras Madeira Creme" },
        { codigo: "TD500104R", cor: "Branco", descricao: "3D Listras Madeira Branca" },
      ],
      cores: ["Marrom", "Bege", "Creme", "Branco"],
      textura: "3D Listrada",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/5.jpg",
      descricao: "Ambiente contemporâneo com sofá cinza, destacando efeito 3D de listras verticais em tons de madeira.",
    },

    {
      id: 8,
      nome: "3D Ripado Madeira Natural",
      modelos: [
        { codigo: "TD500201R", cor: "Marrom", descricao: "3D Ripado Madeira Marrom" },
        { codigo: "TD500202R", cor: "Bege", descricao: "3D Ripado Madeira Bege Claro" },
        { codigo: "TD500203R", cor: "Cinza", descricao: "3D Ripado Madeira Cinza" },
        { codigo: "TD500204R", cor: "Cinza", descricao: "3D Ripado Madeira Cinza Escuro" },
      ],
      cores: ["Marrom", "Bege", "Cinza"],
      textura: "3D Ripado",
      categoria: "Natural",
      imagem: "/catalog-images/5-.jpg",
      descricao: "Texturas 3D que simulam madeira ripada em diferentes tonalidades naturais.",
    },
  ]

  const cores = ["Todas as Cores", "Marrom", "Bege", "Creme", "Branco", "Cinza", "Preto"]

  const filteredProducts = produtos.filter((produto) => {
    const matchesSearch = produto.cores.some((cor) => cor.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesColor = selectedColor === "Todas as Cores" || produto.cores.includes(selectedColor)
    return matchesSearch && matchesColor
  })

  const openModal = (produto: any) => {
    setSelectedProduto(produto)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setSelectedProduto(null)
    setIsModalOpen(false)
  }

  const goToPrevious = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const previousIndex = currentIndex === 0 ? filteredProducts.length - 1 : currentIndex - 1
      setSelectedProduto(filteredProducts[previousIndex])
    }
  }

  const goToNext = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.findIndex((p) => p.id === selectedProduto.id)
      const nextIndex = currentIndex === filteredProducts.length - 1 ? 0 : currentIndex + 1
      setSelectedProduto(filteredProducts[nextIndex])
    }
  }

  const handlePedirOrcamento = (produto: any) => {
    const modelosTexto = produto.modelos
      .map((modelo: any) => `• ${modelo.codigo} - ${modelo.descricao} (${modelo.cor})`)
      .join("\n")

    const mensagem = `Olá! Gostaria de solicitar um orçamento para os papéis de parede:

*${produto.nome}*

Modelos inclusos:
${modelosTexto}

Aguardo retorno. Obrigado!`

    const whatsappUrl = `https://wa.me/5561986792057?text=${encodeURIComponent(mensagem)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-blue-50">
      <Header />

      <div className="pt-24">
        {/* Breadcrumb */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link
                href="/"
                className="flex items-center gap-2 text-indigo-700 hover:text-indigo-800 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                <span className="font-medium">Voltar</span>
              </Link>
              <div className="h-6 w-px bg-gray-300" />
              <h1 className="text-2xl font-bold text-gray-900">Catálogo 3D</h1>
            </div>
          </div>
        </div>

        {/* Hero Section */}
        <div className="bg-gradient-to-r from-indigo-600 to-blue-800 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Coleção 3D</h2>
            <p className="text-xl md:text-2xl mb-6 text-indigo-100">Dimensão e profundidade visual</p>
            <p className="text-lg text-indigo-200 max-w-2xl mx-auto">
              Descubra nossa linha de papéis com efeito 3D que transformam paredes em elementos arquitetônicos.
            </p>
          </div>
        </div>

        {/* Filtros e Busca */}
        <div className="container mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="flex-1 max-w-md">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar por cor..."
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600">Filtrar por cor:</span>
                <div className="flex flex-wrap gap-2">
                  {cores.slice(0, 4).map((cor) => (
                    <Badge
                      key={cor}
                      variant={cor === selectedColor ? "default" : "outline"}
                      className="cursor-pointer hover:bg-indigo-100"
                      onClick={() => setSelectedColor(cor)}
                    >
                      {cor}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Grid de Produtos */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((produto) => (
              <div
                key={produto.id}
                className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-all duration-300 overflow-hidden group"
              >
                <div className="relative">
                  <Image
                    src={produto.imagem || "/placeholder.svg"}
                    alt={produto.nome}
                    width={450}
                    height={300}
                    className="w-full aspect-[3/2] object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                    onClick={() => openModal(produto)}
                  />
                  <div className="absolute top-3 right-3 flex gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="w-8 h-8 p-0 bg-white/90 hover:bg-white"
                      onClick={() => openModal(produto)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white">
                      <Heart className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white">
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="absolute bottom-3 left-3 flex gap-1">
                    {produto.cores.map((cor, index) => (
                      <div
                        key={index}
                        className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
                        style={{
                          backgroundColor:
                            cor === "Marrom"
                              ? "#8B4513"
                              : cor === "Bege"
                                ? "#D2B48C"
                                : cor === "Creme"
                                  ? "#F5F5DC"
                                  : cor === "Branco"
                                    ? "#FFFFFF"
                                    : cor === "Cinza"
                                      ? "#6B7280"
                                      : cor === "Preto"
                                        ? "#1F2937"
                                        : "#9CA3AF",
                        }}
                      />
                    ))}
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="font-semibold text-lg text-gray-900 mb-2">{produto.nome}</h3>
                  <p className="text-sm text-gray-600 mb-2">{produto.modelos.length} modelos inclusos</p>
                  <p className="text-sm text-gray-600 mb-3">Cores: {produto.cores.join(", ")}</p>

                  <div className="flex items-center justify-center">
                    <Button
                      className="w-full bg-green-600 hover:bg-green-700 text-white"
                      onClick={() => handlePedirOrcamento(produto)}
                    >
                      💬 Pedir Orçamento
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-500">Tente buscar por uma cor diferente</p>
            </div>
          )}

          {/* Informações Adicionais */}
          <div className="mt-12 bg-white rounded-lg shadow-sm border p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Por que escolher nossa Coleção 3D?</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🎭</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">Efeito Tridimensional</h4>
                <p className="text-gray-600">Papéis que criam ilusão de profundidade e movimento nas paredes.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🏗️</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">Elemento Arquitetônico</h4>
                <p className="text-gray-600">Transformam paredes simples em elementos decorativos marcantes.</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">✨</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">Impacto Visual</h4>
                <p className="text-gray-600">Criam pontos focais únicos que valorizam qualquer ambiente.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <WhatsAppFloat />

      {/* Image Modal */}
      <ImageModal
        isOpen={isModalOpen}
        onClose={closeModal}
        imageSrc={selectedProduto?.imagem || "/placeholder.svg"}
        imageAlt={selectedProduto?.nome || ""}
        imageTitle={selectedProduto?.nome || ""}
        description={selectedProduto?.descricao}
        modelosHtml={
          selectedProduto?.modelos
            ?.map(
              (modelo: any) =>
                `<p class="text-sm mb-1"><strong>${modelo.codigo}:</strong> ${modelo.descricao} (${modelo.cor})</p>`,
            )
            .join("") || ""
        }
        currentIndex={selectedProduto ? filteredProducts.findIndex((p) => p.id === selectedProduto.id) : 0}
        totalItems={filteredProducts.length}
        onNext={goToNext}
        onPrev={goToPrevious}
      />
    </div>
  )
}
