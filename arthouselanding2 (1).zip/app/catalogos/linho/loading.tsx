export default function Loading() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-100 flex items-center justify-center">
      <div className="text-center">
        <div className="inline-block h-16 w-16 animate-spin rounded-full border-4 border-solid border-amber-600 border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
        <h2 className="mt-4 text-xl font-semibold text-gray-700">Carregando catálogo de Linho...</h2>
        <p className="mt-2 text-gray-500">Estamos preparando os melhores produtos para você.</p>
      </div>
    </div>
  )
}
