"use client"
import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"

export default function CatalogoClassicos() {
  const [selectedColor, setSelectedColor] = useState("Todas as Cores")
  const [selectedCategory, setSelectedCategory] = useState("Todas as Categorias")
  const [imageError, setImageError] = useState<{ [key: number]: boolean }>({})

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const produtos = [
    // Cada imagem aparece apenas uma vez
    {
      id: 1,
      nome: "Textura Lisa Cinza Claro",
      codigo: "NN591004R",
      cor: "Cinza Claro",
      textura: "Lisa",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/classicos-1.jpg",
      descricao: "Textura lisa em cinza claro, perfeita para ambientes modernos e minimalistas.",
      modelos: [
        { codigo: "NN591004R", descricao: "Lisa Cinza Claro", cor: "Cinza Claro" },
        { codigo: "NN591103R", descricao: "Lisa Cinza Azulado", cor: "Cinza Azulado" },
        { codigo: "NN590304R", descricao: "Floral Vintage", cor: "Neutro" },
      ],
    },
    {
      id: 2,
      nome: "Floral Branco Romântico",
      codigo: "NN590302R",
      cor: "Branco",
      textura: "Floral",
      categoria: "Romântico",
      imagem: "/catalog-images/classicos-2.jpg",
      descricao: "Papel floral branco romântico, perfeito para criar ambientes acolhedores e delicados.",
      modelos: [
        { codigo: "NN590302R", descricao: "Floral Branco", cor: "Branco" },
        { codigo: "NN591706R", descricao: "Folhagens Sutis", cor: "Verde Sutil" },
        { codigo: "NN591102R", descricao: "Lisa Verde Claro", cor: "Verde Claro" },
      ],
    },
    {
      id: 3,
      nome: "Damasco Dourado Luxo",
      codigo: "VR981302T",
      cor: "Dourado",
      textura: "Damasco",
      categoria: "Luxo",
      imagem: "/catalog-images/classicos-3.jpg",
      descricao: "Clássico padrão damasco em dourado sobre fundo claro, símbolo de elegância.",
      modelos: [
        { codigo: "VR981302T", descricao: "Damasco Dourado", cor: "Dourado" },
        { codigo: "VR981402R", descricao: "Lisa Bege", cor: "Bege" },
        { codigo: "VR981802R", descricao: "Envelhecida Cinza", cor: "Cinza Envelhecido" },
        { codigo: "VR981903T", descricao: "Geométrico Dourado", cor: "Dourado" },
      ],
    },
    {
      id: 4,
      nome: "Floral Vintage Ambiente",
      codigo: "NN590303R",
      cor: "Neutro Vintage",
      textura: "Floral",
      categoria: "Vintage",
      imagem: "/catalog-images/classicos-4.jpg",
      descricao: "Papel floral vintage para ambientes de estar, com padrão delicado e atemporal.",
      modelos: [
        { codigo: "NN590303R", descricao: "Floral Vintage", cor: "Neutro Vintage" },
        { codigo: "NN591105R", descricao: "Lisa Marrom", cor: "Marrom" },
      ],
    },
    {
      id: 5,
      nome: "Damasco Clássico Cinza",
      codigo: "VR981307T",
      cor: "Cinza",
      textura: "Damasco",
      categoria: "Clássico",
      imagem: "/catalog-images/classicos-5.jpg",
      descricao: "Damasco clássico em cinza sobre fundo claro, elegância discreta e sofisticada.",
      modelos: [
        { codigo: "VR981307T", descricao: "Damasco Cinza", cor: "Cinza" },
        { codigo: "VR981407R", descricao: "Lisa Cinza Premium", cor: "Cinza" },
      ],
    },
    {
      id: 6,
      nome: "Damasco Dourado Tradicional",
      codigo: "VR981303T",
      cor: "Dourado",
      textura: "Damasco",
      categoria: "Tradicional",
      imagem: "/catalog-images/classicos-6.jpg",
      descricao: "Damasco tradicional dourado, símbolo de luxo e sofisticação clássica.",
      modelos: [
        { codigo: "VR981303T", descricao: "Damasco Dourado", cor: "Dourado" },
        { codigo: "VR981806R", descricao: "Envelhecida Dourada", cor: "Dourado Envelhecido" },
        { codigo: "VR981704R", descricao: "Losango Dourado", cor: "Dourado" },
      ],
    },
    {
      id: 7,
      nome: "Textura Lisa Bege Suave",
      codigo: "VR981102R",
      cor: "Bege",
      textura: "Lisa",
      categoria: "Suave",
      imagem: "/catalog-images/classicos-7.jpg",
      descricao: "Textura lisa em bege suave, ideal para ambientes tranquilos e acolhedores.",
      modelos: [
        { codigo: "VR981102R", descricao: "Lisa Bege Suave", cor: "Bege" },
        { codigo: "VR981202R", descricao: "Lisa Rosa Claro", cor: "Rosa Claro" },
        { codigo: "VR981702R", descricao: "Losango Premium", cor: "Dourado" },
      ],
    },
    {
      id: 8,
      nome: "Geométrico Pequeno Moderno",
      codigo: "VR981905T",
      cor: "Neutro",
      textura: "Geométrica",
      categoria: "Moderno",
      imagem: "/catalog-images/classicos-8.jpg",
      descricao: "Padrão geométrico pequeno e moderno, ideal para ambientes contemporâneos.",
      modelos: [
        { codigo: "VR981905T", descricao: "Geométrico Pequeno", cor: "Neutro" },
        { codigo: "VR982003T", descricao: "Linear Contemporânea", cor: "Cinza" },
        { codigo: "VR981703R", descricao: "Losango Escuro", cor: "Escuro" },
      ],
    },
    {
      id: 9,
      nome: "Losango Geométrico Cinza",
      codigo: "VR981705R",
      cor: "Cinza",
      textura: "Geométrica",
      categoria: "Elegante",
      imagem: "/catalog-images/classicos-9.jpg",
      descricao: "Padrão geométrico de losangos em cinza, elegância discreta e moderna.",
      modelos: [
        { codigo: "VR981705R", descricao: "Losango Cinza", cor: "Cinza" },
        { codigo: "VR981405R", descricao: "Lisa Rosa Suave", cor: "Rosa" },
        { codigo: "VR981804R", descricao: "Envelhecida Escura", cor: "Escuro Envelhecido" },
        { codigo: "VR981305T", descricao: "Damasco Premium", cor: "Dourado" },
      ],
    },
    {
      id: 10,
      nome: "Textura Cinza Ambiente",
      codigo: "GR400801R",
      cor: "Cinza",
      textura: "Lisa",
      categoria: "Ambiente",
      imagem: "/catalog-images/classicos-10.jpg",
      descricao: "Textura cinza especial para ambientes, versatilidade e elegância.",
      modelos: [
        { codigo: "GR400801R", descricao: "Cinza Ambiente", cor: "Cinza" },
        { codigo: "GR400805T", descricao: "Ornamental Preto", cor: "Dourado" },
        { codigo: "GR400803R", descricao: "Ornamental Marrom", cor: "Dourado" },
      ],
    },
    {
      id: 11,
      nome: "Damasco Dourado Bege Premium",
      codigo: "VR981306T",
      cor: "Dourado",
      textura: "Damasco",
      categoria: "Premium",
      imagem: "/catalog-images/classicos-11.jpg",
      descricao: "Damasco dourado sobre fundo bege, elegância clássica premium.",
      modelos: [
        { codigo: "VR981306T", descricao: "Damasco Bege", cor: "Dourado" },
        { codigo: "VR981406R", descricao: "Lisa Cinza Média", cor: "Cinza" },
        { codigo: "VR981103R", descricao: "Lisa Bege Claro", cor: "Bege Claro" },
        { codigo: "VR981205R", descricao: "Sutil Cinza", cor: "Cinza Sutil" },
      ],
    },
    {
      id: 12,
      nome: "Textura Marmorizada Bege",
      codigo: "VR981201R",
      cor: "Bege Marmorizado",
      textura: "Marmorizada",
      categoria: "Natural",
      imagem: "/catalog-images/classicos-12.jpg",
      descricao: "Textura marmorizada em bege, inspiração natural sofisticada.",
      modelos: [
        { codigo: "VR981201R", descricao: "Marmorizada Bege", cor: "Bege Marmorizado" },
        { codigo: "VR981701R", descricao: "Losango Branco", cor: "Branco" },
        { codigo: "VR981901T", descricao: "Ornamental Clássico", cor: "Dourado" },
        { codigo: "VR981101R", descricao: "Lisa Bege Neutro", cor: "Bege Neutro" },
      ],
    },
    {
      id: 13,
      nome: "Damasco Dourado Escuro",
      codigo: "VR981301T",
      cor: "Dourado",
      textura: "Damasco",
      categoria: "Sofisticado",
      imagem: "/catalog-images/classicos-13.jpg",
      descricao: "Damasco dourado sobre fundo escuro, sofisticação dramática.",
      modelos: [
        { codigo: "VR981301T", descricao: "Damasco Escuro", cor: "Dourado" },
        { codigo: "VR981401R", descricao: "Lisa Escura", cor: "Escuro" },
        { codigo: "VR982005T", descricao: "Linear Moderna", cor: "Cinza Moderno" },
      ],
    },
    {
      id: 14,
      nome: "Chevron Espinha de Peixe",
      codigo: "VR982104T",
      cor: "Neutro Chevron",
      textura: "Chevron",
      categoria: "Geométrico",
      imagem: "/catalog-images/classicos-14.jpg",
      descricao: "Padrão chevron espinha de peixe, geometria clássica moderna.",
      modelos: [
        { codigo: "VR982104T", descricao: "Chevron", cor: "Neutro Chevron" },
        { codigo: "VR982002T", descricao: "Linear Dourada", cor: "Dourado Linear" },
        { codigo: "VR981808R", descricao: "Envelhecida Premium", cor: "Cinza Envelhecido Premium" },
        { codigo: "VR981706R", descricao: "Losango Escuro Premium", cor: "Escuro Geométrico" },
      ],
    },
    {
      id: 15,
      nome: "Floral Vintage Cinza",
      codigo: "NN590801R",
      cor: "Cinza Vintage",
      textura: "Floral",
      categoria: "Vintage Floral",
      imagem: "/catalog-images/classicos-15.jpg",
      descricao: "Padrão floral vintage em cinza, charme atemporal.",
      modelos: [
        { codigo: "NN590801R", descricao: "Floral Vintage", cor: "Cinza Vintage" },
        { codigo: "NN591603R", descricao: "Lisa Bege Vintage", cor: "Bege Vintage" },
        { codigo: "NN591104R", descricao: "Linear Marrom", cor: "Marrom Linear" },
        { codigo: "NN591702R", descricao: "Lisa Azul Acinzentado", cor: "Azul Acinzentado" },
        { codigo: "NN591101R", descricao: "Lisa Azul Claro", cor: "Azul Claro" },
        { codigo: "NN591001R", descricao: "Lisa Azul Muito Claro", cor: "Azul Muito Claro" },
      ],
    },
    {
      id: 16,
      nome: "Floral Sutil Minimalista",
      codigo: "NN591501R",
      cor: "Neutro Floral",
      textura: "Floral",
      categoria: "Minimalista Floral",
      imagem: "/catalog-images/classicos-16.jpg",
      descricao: "Padrão floral sutil minimalista, elegância discreta.",
      modelos: [
        { codigo: "NN591501R", descricao: "Floral Minimalista", cor: "Neutro Floral" },
        { codigo: "NN591502R", descricao: "Floral Ambiente", cor: "Neutro Ambiente" },
      ],
    },
    {
      id: 17,
      nome: "Damasco Dourado Cinza Clássico",
      codigo: "VR981304T",
      cor: "Dourado Cinza",
      textura: "Damasco",
      categoria: "Clássico Premium",
      imagem: "/catalog-images/classicos-17.jpg",
      descricao: "Damasco dourado sobre fundo cinza, clássico premium atemporal.",
      modelos: [{ codigo: "VR981304T", descricao: "Damasco Cinza Clássico", cor: "Dourado Cinza" }],
    },
  ]

  const cores = [
    "Todas as Cores",
    "Rosa",
    "Dourado",
    "Azul",
    "Bege",
    "Verde",
    "Bordô",
    "Creme",
    "Preto",
    "Vinho",
    "Marrom",
    "Cinza",
    "Cinza Azulado",
    "Neutro",
    "Branco",
    "Verde Sutil",
    "Cinza Envelhecido",
    "Neutro Vintage",
    "Dourado Envelhecido",
    "Escuro",
    "Rosa Claro",
    "Escuro Envelhecido",
    "Bege Claro",
    "Cinza Sutil",
    "Bege Marmorizado",
    "Bege Neutro",
    "Cinza Moderno",
    "Neutro Chevron",
    "Dourado Linear",
    "Cinza Envelhecido Premium",
    "Escuro Geométrico",
    "Cinza Vintage",
    "Bege Vintage",
    "Marrom Linear",
    "Azul Acinzentado",
    "Azul Claro",
    "Azul Muito Claro",
    "Neutro Floral",
    "Neutro Ambiente",
    "Dourado Cinza",
  ]

  const categorias = [
    "Todas as Categorias",
    "Romântico",
    "Luxo",
    "Tradicional",
    "Elegante",
    "Vitoriano",
    "Francês",
    "Oriental",
    "Barroco",
    "Contemporâneo",
    "Vintage",
    "Natural",
    "Clássico",
    "Rústico",
    "Premium",
    "Suave",
    "Moderno",
    "Sofisticado",
    "Delicado",
    "Ambiente",
    "Minimalista",
    "Clean",
    "Neutro",
    "Dramático",
    "Geométrico",
    "Luxo Linear",
    "Vintage Premium",
    "Premium Escuro",
    "Vintage Floral",
    "Vintage Lisa",
    "Natural Linear",
    "Azul Sutil",
    "Azul Suave",
    "Azul Delicado",
    "Minimalista Floral",
    "Ambiente Floral",
    "Clássico Premium",
  ]

  const produtosFiltrados = produtos.filter((produto) => {
    const corMatch = selectedColor === "Todas as Cores" || produto.cor === selectedColor
    const categoriaMatch = selectedCategory === "Todas as Categorias" || produto.categoria === selectedCategory
    return corMatch && categoriaMatch
  })

  const handleImageError = (index: number) => {
    setImageError((prev) => ({ ...prev, [index]: true }))
  }

  const handleImageClick = (produto: any) => {
    const modelosHtml = produto.modelos
      .map(
        (modelo: any) =>
          `<p class="text-sm mb-1"><strong>${modelo.codigo}:</strong> ${modelo.descricao} (${modelo.cor})</p>`,
      )
      .join("")

    const modal = document.createElement("div")
    modal.className = "fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
    modal.innerHTML = `
      <div class="relative max-w-4xl max-h-full w-full">
        <div class="flex flex-col md:flex-row bg-white rounded-lg overflow-hidden max-h-[90vh]">
          <div class="md:w-2/3">
            <img src="${produto.imagem}" alt="${produto.nome}" class="w-full h-64 md:h-full object-cover" />
          </div>
          <div class="md:w-1/3 p-6 overflow-y-auto">
            <h3 class="font-bold text-xl mb-3 text-gray-800">${produto.nome}</h3>
            <p class="text-gray-600 mb-4">${produto.descricao}</p>
            <div class="space-y-2 mb-4">
              <p class="text-sm"><strong>Código:</strong> ${produto.codigo}</p>
              <p class="text-sm"><strong>Cor:</strong> ${produto.cor}</p>
              <p class="text-sm"><strong>Textura:</strong> ${produto.textura}</p>
              <p class="text-sm"><strong>Categoria:</strong> ${produto.categoria}</p>
            </div>
            <div class="border-t pt-4">
              <strong class="text-sm block mb-2">Modelos inclusos:</strong>
              ${modelosHtml}
            </div>
            <div class="mt-6">
              <a href="https://wa.me/5561986792057?text=Olá! Gostaria de saber mais sobre o ${produto.nome} (${produto.codigo})" 
                 target="_blank" 
                 class="block w-full bg-green-500 text-white text-center py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors">
                💬 Solicitar Orçamento
              </a>
            </div>
          </div>
        </div>
        <button class="absolute top-4 right-4 text-white bg-black bg-opacity-50 rounded-full w-10 h-10 flex items-center justify-center hover:bg-opacity-75 transition-colors" onclick="this.parentElement.parentElement.remove()">
          ✕
        </button>
      </div>
    `
    modal.onclick = (e) => {
      if (e.target === modal) modal.remove()
    }
    document.body.appendChild(modal)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-gray-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-lg border-b border-gray-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4">
              <Image src="/logo-art-house.png" alt="Art House Logo" width={120} height={60} className="h-12 w-auto" />
            </Link>
            <div className="flex items-center space-x-6">
              <a
                href="/#catalogos"
                className="hidden md:block text-gray-700 hover:text-[#1B5E3A] transition-colors font-medium"
              >
                ← Voltar aos Catálogos
              </a>
              <a
                href="https://wa.me/5561986792057"
                target="_blank"
                className="bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-6 py-2 rounded-full font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                rel="noreferrer"
              >
                💬 WhatsApp
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-400/10 to-gray-400/10"></div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-slate-400 to-gray-600 rounded-3xl mb-8 text-4xl">
              🏛️
            </div>

            <h1 className="font-montserrat font-bold text-5xl md:text-6xl bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] bg-clip-text text-transparent mb-6">
              Papéis Clássicos
            </h1>

            <p className="text-xl text-gray-600 mb-6 max-w-3xl mx-auto leading-relaxed">
              Designs atemporais que nunca saem de moda. Nossa coleção clássica oferece elegância e sofisticação para
              ambientes que valorizam a tradição e o bom gosto.
            </p>

            <p className="text-gray-500 text-lg mb-8 max-w-3xl mx-auto">
              (Não encontrou o que procura? Entre em contato no nosso WhatsApp, possuímos mais catálogos fora do site,
              além disso, também podemos fazer personalizados.)
            </p>

            <div className="w-24 h-1 bg-gradient-to-r from-slate-400 to-gray-400 mx-auto rounded-full"></div>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Cor</label>
                <select
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-slate-500 focus:border-transparent bg-white"
                >
                  {cores.map((cor) => (
                    <option key={cor} value={cor}>
                      {cor}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Categoria</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-slate-500 focus:border-transparent bg-white"
                >
                  {categorias.map((categoria) => (
                    <option key={categoria} value={categoria}>
                      {categoria}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="mt-4 text-center">
              <p className="text-gray-600">
                Mostrando <span className="font-semibold text-slate-600">{produtosFiltrados.length}</span> produtos
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {produtosFiltrados.map((produto, index) => (
              <div
                key={produto.id}
                className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 overflow-hidden border border-slate-100"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  {!imageError[index] ? (
                    <Image
                      src={produto.imagem || "/placeholder.svg"}
                      alt={produto.nome}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                      onError={() => handleImageError(index)}
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-slate-100 to-gray-100 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-4xl mb-2">🏛️</div>
                        <p className="text-gray-500 text-sm">{produto.nome}</p>
                      </div>
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-slate-500/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

                  <div className="absolute bottom-4 left-4 right-4 transform translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                    <h3 className="text-white font-semibold text-lg mb-2">{produto.nome}</h3>
                    <button
                      className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-white/30 transition-colors w-full"
                      onClick={() => handleImageClick(produto)}
                    >
                      Ver Detalhes
                    </button>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="font-semibold text-lg text-gray-800 mb-2">{produto.nome}</h3>
                  <p className="text-gray-600 text-sm mb-3">{produto.descricao}</p>
                  <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
                    <span className="bg-slate-100 text-slate-700 px-2 py-1 rounded-full">{produto.cor}</span>
                    <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full">{produto.categoria}</span>
                  </div>
                  <button
                    onClick={() => handleImageClick(produto)}
                    className="w-full bg-gradient-to-r from-slate-500 to-gray-500 text-white py-2 rounded-lg font-medium hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                  >
                    Ver Modelos
                  </button>
                </div>
              </div>
            ))}
          </div>

          {produtosFiltrados.length === 0 && (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-2xl font-semibold text-gray-700 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-500">Tente ajustar os filtros para encontrar o que procura.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-slate-400/10 to-gray-400/10">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="font-montserrat font-bold text-3xl text-[#1B5E3A] mb-6">Gostou de algum modelo?</h2>
            <p className="text-gray-600 text-lg mb-8">
              Entre em contato conosco para solicitar orçamento, tirar dúvidas ou conhecer mais opções disponíveis.
            </p>
            <a
              href="https://wa.me/5561986792057"
              target="_blank"
              className="group inline-flex items-center gap-3 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] text-white px-10 py-4 rounded-2xl font-montserrat font-semibold text-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 hover:-translate-y-2 relative overflow-hidden"
              rel="noreferrer"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></span>
              <span className="relative">💬 Falar no WhatsApp</span>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 to-black text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#1B5E3A]/10 to-transparent"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div className="animate-fade-in-up">
              <div className="flex items-center mb-6">
                <Image
                  src="/logo-art-house.png"
                  alt="Art House Logo"
                  width={150}
                  height={75}
                  className="h-16 w-auto filter brightness-0 invert"
                />
              </div>
              <h3 className="font-montserrat font-bold text-2xl text-white mb-4">
                Art House | 25 anos transformando ambientes em Brasília.
              </h3>
              <p className="text-gray-300 text-lg leading-relaxed">
                Especialistas em papel de parede com a qualidade e confiança que você merece.
              </p>
            </div>

            <div className="animate-fade-in-up animation-delay-200">
              <h4 className="font-montserrat font-bold text-xl text-white mb-6">Links Rápidos</h4>
              <div className="space-y-3">
                <a href="/#hero" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Home
                </a>
                <a href="/#produtos" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Produtos
                </a>
                <a href="/#catalogos" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Catálogos
                </a>
                <a href="/#vantagens" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Vantagens
                </a>
                <a href="/sobre" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Sobre
                </a>
                <a href="/contato" className="block text-gray-300 hover:text-white transition-colors text-lg">
                  Contato
                </a>
              </div>
            </div>

            <div className="animate-fade-in-up animation-delay-400">
              <h4 className="font-montserrat font-bold text-xl text-white mb-6">Contato</h4>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📍
                  </div>
                  <p className="text-gray-300 text-lg">CLS 311, Bloco C, Loja 29, Asa Sul, Brasília - DF</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📧
                  </div>
                  <a
                    href="mailto:contato@arthousepapeldeparede.com.br"
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                  >
                    contato@arthousepapeldeparede.com.br
                  </a>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-[#1B5E3A] to-[#2d7a4f] rounded-full flex items-center justify-center">
                    📱
                  </div>
                  <a
                    href="https://wa.me/5561986792057"
                    target="_blank"
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                    rel="noreferrer"
                  >
                    (61) 9 8679-2057
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-400 text-lg">
              &copy; 2024 Art House. Todos os direitos reservados. | Desenvolvido com ❤️ para transformar ambientes.
            </p>
          </div>
        </div>
      </footer>

      {/* Floating Back Button - Mobile Only */}
      <a
        href="/#catalogos"
        className="fixed bottom-6 left-6 z-50 md:hidden bg-gradient-to-r from-gray-600 to-gray-700 text-white p-4 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 group"
      >
        <svg
          className="w-6 h-6 group-hover:scale-110 transition-transform duration-300"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold">
          📖
        </div>
      </a>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/5561986792057"
        target="_blank"
        className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-green-500 to-green-600 text-white p-5 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-110 animate-pulse-slow group"
        rel="noreferrer"
      >
        <svg
          className="w-8 h-8 group-hover:scale-110 transition-transform duration-300"
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488" />
        </svg>
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-xs font-bold animate-bounce">
          !
        </div>
      </a>
    </div>
  )
}
