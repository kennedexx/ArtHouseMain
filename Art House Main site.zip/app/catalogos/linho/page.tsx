"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Share2, Search, Filter, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import WhatsAppFloat from "@/components/WhatsAppFloat"
import { useState } from "react"
import ImageModal from "@/components/ImageModal"

export default function CatalogoLinho() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedColor, setSelectedColor] = useState("Todas as Cores")
  const [selectedProduto, setSelectedProduto] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const produtos = [
    // Produtos baseados nas imagens reais enviadas
    {
      id: 1,
      nome: "Linho Cinza Contemporâneo",
      codigo: "CR333030R",
      modelos: [{ codigo: "CR333030R", cor: "Cinza", descricao: "Linho Cinza Texturizado Contemporâneo" }],
      cores: ["Cinza"],
      textura: "Linho",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/linho-1.jpg",
      descricao:
        "Ambiente moderno com sofá cinza, destacando papel de parede com textura de linho em tom cinza neutro.",
    },
    {
      id: 2,
      nome: "Texturas Pequenas Variadas",
      codigo: "SE050601",
      modelos: [
        { codigo: "SE050601", cor: "Bege", descricao: "Textura Pequena Bege" },
        { codigo: "SE050604", cor: "Verde", descricao: "Textura Pequena Verde" },
        { codigo: "SE050612", cor: "Cinza", descricao: "Textura Média Cinza" },
        { codigo: "SE050101", cor: "Cinza", descricao: "Textura Lisa Cinza" },
        { codigo: "SE050105", cor: "Bege", descricao: "Textura Lisa Bege Claro" },
        { codigo: "SE050104", cor: "Bege", descricao: "Textura Lisa Bege" },
      ],
      cores: ["Bege", "Verde", "Cinza"],
      textura: "Variada",
      categoria: "Natural",
      imagem: "/catalog-images/linho-2.jpg",
      descricao: "Coleção de texturas pequenas e lisas em tons naturais, perfeitas para ambientes aconchegantes.",
    },
    {
      id: 3,
      nome: "Linho Azul Escuro Premium",
      codigo: "SE050504",
      modelos: [
        { codigo: "SE050504", cor: "Azul Escuro", descricao: "Linho Azul Escuro Texturizado" },
        { codigo: "SE051203", cor: "Cinza", descricao: "Linho Cinza Claro" },
        { codigo: "SE051204", cor: "Cinza", descricao: "Linho Cinza Médio" },
      ],
      cores: ["Azul Escuro", "Cinza"],
      textura: "Linho",
      categoria: "Premium",
      imagem: "/catalog-images/linho-3.jpg",
      descricao: "Ambiente moderno com papel azul escuro texturizado, complementado por tons de cinza elegantes.",
    },
    {
      id: 4,
      nome: "Linho Tons Azuis e Verdes",
      codigo: "CR333025R",
      modelos: [
        { codigo: "CR333025R", cor: "Azul Acinzentado", descricao: "Linho Azul Acinzentado Texturizado" },
        { codigo: "CR333026R", cor: "Azul Claro", descricao: "Linho Azul Claro Texturizado" },
        { codigo: "CR333027R", cor: "Verde Claro", descricao: "Linho Verde Claro Texturizado" },
        { codigo: "CR333028R", cor: "Verde Médio", descricao: "Linho Verde Médio Texturizado" },
        { codigo: "CR333029R", cor: "Verde Escuro", descricao: "Linho Verde Escuro Texturizado" },
      ],
      cores: ["Azul", "Verde"],
      textura: "Linho",
      categoria: "Natural",
      imagem: "/catalog-images/linho-4.jpg",
      descricao:
        "Coleção de papéis com textura de linho em tons de verde e azul, desde tons claros até mais escuros e intensos.",
    },
    {
      id: 5,
      nome: "Linho Tons Neutros e Rosa",
      codigo: "SE050103",
      modelos: [
        { codigo: "SE050103", cor: "Bege Claro", descricao: "Linho Bege Claro Texturizado" },
        { codigo: "SE050102", cor: "Cinza Médio", descricao: "Linho Cinza Médio Texturizado" },
        { codigo: "SE050408", cor: "Rosa Claro", descricao: "Linho Rosa Claro Texturizado" },
      ],
      cores: ["Bege", "Cinza", "Rosa"],
      textura: "Linho",
      categoria: "Suave",
      imagem: "/catalog-images/linho-5.jpg",
      descricao: "Tons suaves e neutros com destaque para o rosa claro, perfeitos para ambientes delicados.",
    },
    {
      id: 6,
      nome: "Linho Tons Terrosos",
      codigo: "CR333036R",
      modelos: [
        { codigo: "CR333036R", cor: "Marrom", descricao: "Linho Marrom Texturizado" },
        { codigo: "CR333037R", cor: "Rosa Claro", descricao: "Linho Rosa Claro Texturizado" },
        { codigo: "CR333038R", cor: "Terracota", descricao: "Linho Terracota Texturizado" },
        { codigo: "CR333034R", cor: "Cinza Médio", descricao: "Linho Cinza Médio Texturizado" },
        { codigo: "CR333035R", cor: "Cinza Claro", descricao: "Linho Cinza Claro Texturizado" },
      ],
      cores: ["Marrom", "Rosa", "Terracota", "Cinza"],
      textura: "Linho",
      categoria: "Natural",
      imagem: "/catalog-images/linho-6.jpg",
      descricao:
        "Coleção de papéis com textura de linho em tons terrosos e neutros, desde marrom e terracota até rosa claro e cinza.",
    },
    {
      id: 7,
      nome: "Texturas Variadas Premium",
      codigo: "SE050111",
      modelos: [
        { codigo: "SE050111", cor: "Cinza Claro", descricao: "Textura Lisa Cinza Claro" },
        { codigo: "SE050110", cor: "Cinza", descricao: "Textura Lisa Cinza" },
        { codigo: "SE050608", cor: "Marrom Claro", descricao: "Textura Pequena Marrom Claro" },
        { codigo: "SE050607", cor: "Marrom", descricao: "Textura Pequena Marrom" },
      ],
      cores: ["Cinza", "Marrom"],
      textura: "Variada",
      categoria: "Premium",
      imagem: "/catalog-images/linho-7.jpg",
      descricao: "Ambiente com papel marrom na parede, complementado por texturas variadas em tons neutros.",
    },
    {
      id: 8,
      nome: "Linho Cinza Claro Elegante",
      codigo: "CR333031R",
      modelos: [{ codigo: "CR333031R", cor: "Cinza Claro", descricao: "Linho Cinza Claro Elegante" }],
      cores: ["Cinza"],
      textura: "Linho",
      categoria: "Elegante",
      imagem: "/catalog-images/linho-8.jpg",
      descricao:
        "Ambiente minimalista com móveis modernos, destacando papel de parede com textura de linho em tom cinza claro.",
    },
    {
      id: 9,
      nome: "Linho Dourado Premium",
      codigo: "CR333021R",
      modelos: [{ codigo: "CR333021R", cor: "Dourado", descricao: "Linho Dourado Texturizado Premium" }],
      cores: ["Dourado"],
      textura: "Linho",
      categoria: "Premium",
      imagem: "/catalog-images/linho-9.jpg",
      descricao: "Ambiente sofisticado com papel de parede dourado vibrante, criando um espaço luxuoso e acolhedor.",
    },
    {
      id: 10,
      nome: "Texturas Neutras e Verdes",
      codigo: "SE050106",
      modelos: [
        { codigo: "SE050106", cor: "Bege", descricao: "Textura Pequena Bege" },
        { codigo: "SE050609", cor: "Verde Escuro", descricao: "Textura Pequena Verde Escuro" },
        { codigo: "SE050010", cor: "Verde Escuro", descricao: "Linho Verde Escuro" },
        { codigo: "SE050105", cor: "Cinza", descricao: "Linho Cinza" },
        { codigo: "SE050107", cor: "Cinza Claro", descricao: "Linho Cinza Claro" },
      ],
      cores: ["Bege", "Verde", "Cinza"],
      textura: "Variada",
      categoria: "Natural",
      imagem: "/catalog-images/linho-10.jpg",
      descricao: "Coleção variada de texturas em tons neutros e verdes, desde texturas pequenas até linho tradicional.",
    },
    // Produtos das imagens adicionais anteriores
    {
      id: 11,
      nome: "Linho Cinza Ambiente Moderno",
      codigo: "CR333001R",
      modelos: [{ codigo: "CR333001R", cor: "Cinza", descricao: "Linho Cinza Texturizado Moderno" }],
      cores: ["Cinza"],
      textura: "Linho",
      categoria: "Moderno",
      imagem: "/catalog-images/linho-11.jpg",
      descricao:
        "Ambiente moderno com poltrona cinza e papel de parede linho cinza texturizado, criando harmonia visual.",
    },
    {
      id: 12,
      nome: "Linho Tons Azuis Premium",
      codigo: "CR333031R",
      modelos: [
        { codigo: "CR333031R", cor: "Cinza Azulado", descricao: "Linho Cinza Azulado Texturizado" },
        { codigo: "CR333032R", cor: "Cinza", descricao: "Linho Cinza Texturizado" },
        { codigo: "CR333033R", cor: "Azul Escuro", descricao: "Linho Azul Escuro Texturizado" },
      ],
      cores: ["Azul", "Cinza"],
      textura: "Linho",
      categoria: "Premium",
      imagem: "/catalog-images/linho-12.jpg",
      descricao:
        "Ambientes sofisticados com papéis em tons de cinza azulado e azul escuro, perfeitos para espaços elegantes.",
    },
    {
      id: 13,
      nome: "Texturas Variadas Cinza",
      codigo: "SE050512",
      modelos: [
        { codigo: "SE050512", cor: "Cinza Escuro", descricao: "Textura Variada Cinza Escuro" },
        { codigo: "SE050513", cor: "Cinza Médio", descricao: "Textura Variada Cinza Médio" },
        { codigo: "SE050502", cor: "Cinza Claro", descricao: "Textura Variada Cinza Claro" },
        { codigo: "SE050509", cor: "Bege", descricao: "Textura Variada Bege" },
        { codigo: "SE050511", cor: "Cinza", descricao: "Textura Variada Cinza" },
        { codigo: "SE050508", cor: "Cinza Claro", descricao: "Textura Variada Cinza Claro" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Variada",
      categoria: "Versátil",
      imagem: "/catalog-images/linho-13.jpg",
      descricao:
        "Coleção de texturas variadas em tons de cinza e bege, oferecendo versatilidade para diferentes ambientes.",
    },
    {
      id: 14,
      nome: "Linho Tons Neutros Clássicos",
      codigo: "CR333015R",
      modelos: [
        { codigo: "CR333015R", cor: "Cinza", descricao: "Linho Cinza Texturizado" },
        { codigo: "CR333012R", cor: "Off-White", descricao: "Linho Off-White Texturizado" },
        { codigo: "CR333013R", cor: "Bege", descricao: "Linho Bege Texturizado" },
        { codigo: "CR333014R", cor: "Cinza Claro", descricao: "Linho Cinza Claro Texturizado" },
      ],
      cores: ["Cinza", "Bege", "Off-White"],
      textura: "Linho",
      categoria: "Clássico",
      imagem: "/catalog-images/linho-14.jpg",
      descricao:
        "Ambiente clássico com móvel branco, destacando papéis com textura de linho em tons neutros clássicos.",
    },
    {
      id: 15,
      nome: "Linho Tons Claros Premium",
      codigo: "CR333307R",
      modelos: [
        { codigo: "CR333307R", cor: "Cinza Claro", descricao: "Linho Cinza Claro Premium" },
        { codigo: "CR333305R", cor: "Off-White", descricao: "Linho Off-White Premium" },
        { codigo: "CR333306R", cor: "Bege Claro", descricao: "Linho Bege Claro Premium" },
      ],
      cores: ["Cinza", "Off-White", "Bege"],
      textura: "Linho",
      categoria: "Premium",
      imagem: "/catalog-images/linho-15.jpg",
      descricao: "Três amostras premium de linho em tons claros e neutros, perfeitos para ambientes minimalistas.",
    },
    {
      id: 16,
      nome: "Texturas Modernas Ambiente",
      codigo: "SE050510",
      modelos: [
        { codigo: "SE050510", cor: "Cinza Escuro", descricao: "Textura Moderna Cinza Escuro" },
        { codigo: "SE050506", cor: "Cinza Médio", descricao: "Textura Moderna Cinza Médio" },
        { codigo: "SE050504", cor: "Cinza Claro", descricao: "Textura Moderna Cinza Claro" },
      ],
      cores: ["Cinza"],
      textura: "Moderna",
      categoria: "Contemporâneo",
      imagem: "/catalog-images/linho-16.jpg",
      descricao: "Ambiente moderno com sofá cinza e três texturas modernas em diferentes tons de cinza.",
    },
    {
      id: 17,
      nome: "Linho Tons Variados Premium",
      codigo: "CR333002R",
      modelos: [
        { codigo: "CR333002R", cor: "Off-White", descricao: "Linho Off-White Premium" },
        { codigo: "CR333003R", cor: "Dourado", descricao: "Linho Dourado Texturizado" },
        { codigo: "CR333004R", cor: "Cinza Azulado", descricao: "Linho Cinza Azulado Texturizado" },
        { codigo: "CR333005R", cor: "Azul Escuro", descricao: "Linho Azul Escuro Texturizado" },
      ],
      cores: ["Off-White", "Dourado", "Cinza", "Azul"],
      textura: "Linho",
      categoria: "Premium",
      imagem: "/catalog-images/linho-17.jpg",
      descricao: "Quatro amostras premium de linho em tons variados: off-white, dourado, cinza azulado e azul escuro.",
    },
    {
      id: 18,
      nome: "Texturas Neutras Variadas",
      codigo: "SE050704",
      modelos: [
        { codigo: "SE050704", cor: "Cinza Escuro", descricao: "Textura Neutra Cinza Escuro" },
        { codigo: "SE050507", cor: "Off-White", descricao: "Textura Neutra Off-White" },
        { codigo: "SE051004", cor: "Bege", descricao: "Textura Neutra Bege" },
        { codigo: "SE050705", cor: "Cinza Claro", descricao: "Textura Neutra Cinza Claro" },
        { codigo: "SE051008", cor: "Off-White", descricao: "Textura Neutra Off-White Claro" },
        { codigo: "SE051003", cor: "Bege Claro", descricao: "Textura Neutra Bege Claro" },
      ],
      cores: ["Cinza", "Off-White", "Bege"],
      textura: "Neutra",
      categoria: "Versátil",
      imagem: "/catalog-images/linho-18.jpg",
      descricao:
        "Seis amostras de texturas neutras em tons de cinza, off-white e bege, perfeitas para qualquer ambiente.",
    },
    {
      id: 19,
      nome: "Linho Tons Cinza Gradação",
      codigo: "CR333016R",
      modelos: [
        { codigo: "CR333016R", cor: "Cinza Escuro", descricao: "Linho Cinza Escuro Texturizado" },
        { codigo: "CR333017R", cor: "Off-White", descricao: "Linho Off-White Texturizado" },
        { codigo: "CR333018R", cor: "Cinza Claro", descricao: "Linho Cinza Claro Texturizado" },
        { codigo: "CR333019R", cor: "Cinza Médio", descricao: "Linho Cinza Médio Texturizado" },
        { codigo: "CR333020R", cor: "Cinza Escuro", descricao: "Linho Cinza Escuro Premium" },
      ],
      cores: ["Cinza", "Off-White"],
      textura: "Linho",
      categoria: "Gradação",
      imagem: "/catalog-images/linho-19.jpg",
      descricao:
        "Cinco amostras de linho em gradação de cinza, desde off-white até cinza escuro, criando harmonia visual.",
    },
    {
      id: 20,
      nome: "Texturas Ambiente Verde",
      codigo: "SE050108",
      modelos: [
        { codigo: "SE050108", cor: "Cinza", descricao: "Textura Ambiente Cinza" },
        { codigo: "SE050109", cor: "Cinza Claro", descricao: "Textura Ambiente Cinza Claro" },
        { codigo: "SE050501", cor: "Verde", descricao: "Textura Ambiente Verde" },
      ],
      cores: ["Cinza", "Verde"],
      textura: "Ambiente",
      categoria: "Natural",
      imagem: "/catalog-images/linho-20.jpg",
      descricao: "Ambiente com poltrona moderna e três texturas: duas em tons de cinza e uma em verde natural.",
    },
    // Novos produtos das imagens adicionais
    {
      id: 21,
      nome: "Linho Tons Neutros Modernos",
      codigo: "SE051007",
      modelos: [
        { codigo: "SE051007", cor: "Cinza", descricao: "Linho Cinza Moderno" },
        { codigo: "SE050702", cor: "Cinza Médio", descricao: "Linho Cinza Médio Moderno" },
        { codigo: "SE051002", cor: "Cinza Claro", descricao: "Linho Cinza Claro Moderno" },
      ],
      cores: ["Cinza"],
      textura: "Linho",
      categoria: "Moderno",
      imagem: "/catalog-images/linho-21.jpg",
      descricao: "Ambiente contemporâneo com sofá cinza e almofada rosa, destacando texturas de linho em tons neutros.",
    },
    {
      id: 22,
      nome: "Linho Cinza Elegante Ambiente",
      codigo: "CR333011R",
      modelos: [{ codigo: "CR333011R", cor: "Cinza Claro", descricao: "Linho Cinza Claro Elegante" }],
      cores: ["Cinza"],
      textura: "Linho",
      categoria: "Elegante",
      imagem: "/catalog-images/linho-22.jpg",
      descricao:
        "Ambiente sofisticado com sofá branco e almofadas decorativas, destacando papel de parede linho cinza.",
    },
    {
      id: 23,
      nome: "Linho Tons Neutros Variados",
      codigo: "SE050113",
      modelos: [
        { codigo: "SE050113", cor: "Cinza Escuro", descricao: "Linho Cinza Escuro Texturizado" },
        { codigo: "SE051001", cor: "Cinza Médio", descricao: "Linho Cinza Médio Texturizado" },
        { codigo: "SE050703", cor: "Cinza Claro", descricao: "Linho Cinza Claro Texturizado" },
        { codigo: "SE051009", cor: "Bege Esverdeado", descricao: "Linho Bege Esverdeado Texturizado" },
        { codigo: "SE051006", cor: "Cinza Claro", descricao: "Linho Cinza Claro Suave" },
        { codigo: "SE050701", cor: "Cinza Texturizado", descricao: "Linho Cinza Texturizado Premium" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Linho",
      categoria: "Versátil",
      imagem: "/catalog-images/linho-23.jpg",
      descricao: "Coleção completa de linhos em tons neutros variados, desde cinza escuro até bege esverdeado.",
    },
    {
      id: 24,
      nome: "Linho Tons Neutros Premium",
      codigo: "CR333008R",
      modelos: [
        { codigo: "CR333008R", cor: "Cinza Claro", descricao: "Linho Cinza Claro Premium" },
        { codigo: "CR333009R", cor: "Cinza Médio", descricao: "Linho Cinza Médio Premium" },
        { codigo: "CR333010R", cor: "Cinza Escuro", descricao: "Linho Cinza Escuro Premium" },
        { codigo: "CR333006R", cor: "Cinza Esverdeado", descricao: "Linho Cinza Esverdeado Premium" },
        { codigo: "CR333007R", cor: "Bege Claro", descricao: "Linho Bege Claro Premium" },
      ],
      cores: ["Cinza", "Bege"],
      textura: "Linho",
      categoria: "Premium",
      imagem: "/catalog-images/linho-24.jpg",
      descricao:
        "Cinco amostras premium de linho em tons neutros, desde cinza claro até bege, com acabamento superior.",
    },
    {
      id: 25,
      nome: "Linho Ambientes Sofisticados",
      codigo: "CR333301R",
      modelos: [
        { codigo: "CR333301R", cor: "Cinza Azulado", descricao: "Linho Cinza Azulado Sofisticado" },
        { codigo: "CR333302R", cor: "Cinza Médio", descricao: "Linho Cinza Médio Sofisticado" },
        { codigo: "CR333303R", cor: "Verde Claro", descricao: "Linho Verde Claro Sofisticado" },
        { codigo: "CR333304R", cor: "Off-White", descricao: "Linho Off-White Sofisticado" },
      ],
      cores: ["Cinza", "Verde", "Off-White"],
      textura: "Linho",
      categoria: "Sofisticado",
      imagem: "/catalog-images/linho-25.jpg",
      descricao: "Ambientes sofisticados com móveis modernos e quatro opções de linho em tons suaves e elegantes.",
    },
  ]

  const cores = [
    "Todas as Cores",
    "Cinza",
    "Bege",
    "Verde",
    "Azul Escuro",
    "Azul",
    "Rosa",
    "Marrom",
    "Terracota",
    "Dourado",
    "Off-White",
  ]

  const filteredProducts = produtos.filter((produto) => {
    const matchesSearch =
      produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      produto.cores.some((cor) => cor.toLowerCase().includes(searchTerm.toLowerCase())) ||
      produto.codigo?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesColor = selectedColor === "Todas as Cores" || produto.cores.includes(selectedColor)
    return matchesSearch && matchesColor
  })

  const openModal = (produto: any) => {
    setSelectedProduto(produto)
    setIsModalOpen(true)
  }

  const closeModal = () => {
    setSelectedProduto(null)
    setIsModalOpen(false)
  }

  const goToPrevious = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.indexOf(selectedProduto)
      const previousIndex = currentIndex === 0 ? filteredProducts.length - 1 : currentIndex - 1
      setSelectedProduto(filteredProducts[previousIndex])
    }
  }

  const goToNext = () => {
    if (selectedProduto) {
      const currentIndex = filteredProducts.indexOf(selectedProduto)
      const nextIndex = currentIndex === filteredProducts.length - 1 ? 0 : currentIndex + 1
      setSelectedProduto(filteredProducts[nextIndex])
    }
  }

  const handlePedirOrcamento = (produto: any) => {
    const modelosTexto = produto.modelos
      .map((modelo: any) => `• ${modelo.codigo} - ${modelo.descricao} (${modelo.cor})`)
      .join("\n")

    const mensagem = `Olá! Gostaria de solicitar um orçamento para os papéis de parede:

*${produto.nome}*
${produto.codigo ? `Código Principal: ${produto.codigo}` : ""}

Modelos inclusos:
${modelosTexto}

Aguardo retorno. Obrigado!`

    const whatsappUrl = `https://wa.me/5561986792057?text=${encodeURIComponent(mensagem)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-100">
      <Header />

      <div className="pt-24">
        {/* Breadcrumb */}
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2 text-amber-700 hover:text-amber-800 transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span className="font-medium">Voltar</span>
              </Link>
              <div className="h-6 w-px bg-gray-300" />
              <h1 className="text-2xl font-bold text-gray-900">Catálogo Linho</h1>
            </div>
          </div>
        </div>

        {/* Hero Section */}
        <div className="bg-gradient-to-r from-amber-600 to-amber-800 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Coleção Linho</h2>
            <p className="text-xl md:text-2xl mb-6 text-amber-100">
              Texturas naturais que trazem elegância e sofisticação
            </p>
            <p className="text-lg text-amber-200 max-w-2xl mx-auto">
              Descubra nossa exclusiva linha de papéis de parede com textura de linho, perfeitos para criar ambientes
              acolhedores e refinados.
            </p>
          </div>
        </div>

        {/* Filtros e Busca */}
        <div className="container mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
            <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
              <div className="flex-1 max-w-md w-full">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar por nome, cor ou código..."
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-600 whitespace-nowrap">Filtrar por cor:</span>
                <div className="flex flex-wrap gap-2">
                  {cores.slice(0, 6).map((cor) => (
                    <Badge
                      key={cor}
                      variant={cor === selectedColor ? "default" : "outline"}
                      className="cursor-pointer hover:bg-amber-100 text-xs"
                      onClick={() => setSelectedColor(cor)}
                    >
                      {cor}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Grid de Produtos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((produto) => (
              <div
                key={produto.id}
                className="bg-white rounded-lg shadow-sm border hover:shadow-lg transition-all duration-300 overflow-hidden group"
              >
                <div className="relative">
                  <div className="w-full aspect-[4/3] relative overflow-hidden">
                    <Image
                      src={produto.imagem || "/placeholder.svg"}
                      alt={produto.nome}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                      onClick={() => openModal(produto)}
                    />
                  </div>
                  <div className="absolute top-3 right-3 flex gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="w-8 h-8 p-0 bg-white/90 hover:bg-white shadow-sm"
                      onClick={() => openModal(produto)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white shadow-sm">
                      <Heart className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="secondary" className="w-8 h-8 p-0 bg-white/90 hover:bg-white shadow-sm">
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="absolute bottom-3 left-3 flex gap-1">
                    {produto.cores.slice(0, 4).map((cor, index) => (
                      <div
                        key={index}
                        className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
                        style={{
                          backgroundColor:
                            cor === "Cinza"
                              ? "#6B7280"
                              : cor === "Marrom"
                                ? "#8B4513"
                                : cor === "Rosa"
                                  ? "#F472B6"
                                  : cor === "Terracota"
                                    ? "#CD5C5C"
                                    : cor === "Dourado"
                                      ? "#DAA520"
                                      : cor === "Azul"
                                        ? "#3B82F6"
                                        : cor === "Verde"
                                          ? "#10B981"
                                          : cor === "Bege"
                                            ? "#D2B48C"
                                            : cor === "Azul Escuro"
                                              ? "#1E3A8A"
                                              : cor === "Off-White"
                                                ? "#F8FAFC"
                                                : "#9CA3AF",
                        }}
                      />
                    ))}
                    {produto.cores.length > 4 && (
                      <div className="w-4 h-4 rounded-full border-2 border-white shadow-sm bg-gray-300 flex items-center justify-center">
                        <span className="text-xs text-gray-600">+</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="font-semibold text-lg text-gray-900 mb-1 line-clamp-2">{produto.nome}</h3>
                  {produto.codigo && (
                    <p className="text-sm text-amber-600 font-medium mb-2">Código: {produto.codigo}</p>
                  )}
                  <p className="text-sm text-gray-600 mb-2">
                    {produto.modelos.length} modelo{produto.modelos.length > 1 ? "s" : ""} incluso
                    {produto.modelos.length > 1 ? "s" : ""}
                  </p>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-1">Cores: {produto.cores.join(", ")}</p>

                  <Button
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-medium"
                    onClick={() => handlePedirOrcamento(produto)}
                  >
                    💬 Pedir Orçamento
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-500">Tente buscar por uma cor, nome ou código diferente</p>
            </div>
          )}

          {/* Informações Adicionais */}
          <div className="mt-16 bg-white rounded-lg shadow-sm border p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Por que escolher nossa Coleção Linho?</h3>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🌿</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">Textura Natural</h4>
                <p className="text-gray-600">
                  Reprodução fiel da textura do linho natural, proporcionando um toque orgânico e sofisticado aos
                  ambientes.
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">✨</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">Elegância Atemporal</h4>
                <p className="text-gray-600">
                  Design clássico que nunca sai de moda, perfeito para qualquer estilo de decoração e arquitetura.
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🏠</span>
                </div>
                <h4 className="font-semibold text-lg mb-2">Versatilidade Total</h4>
                <p className="text-gray-600">
                  Ideal para salas, quartos, escritórios e qualquer ambiente que busque requinte e aconchego.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <WhatsAppFloat />

      {/* Image Modal */}
      <ImageModal
        isOpen={isModalOpen}
        onClose={closeModal}
        imageSrc={selectedProduto?.imagem || "/placeholder.svg"}
        imageAlt={selectedProduto?.nome || ""}
        imageTitle={selectedProduto?.nome || ""}
        description={selectedProduto?.descricao}
        modelosHtml={
          selectedProduto?.modelos
            ?.map(
              (modelo: any) =>
                `<p class="text-sm mb-1"><strong>${modelo.codigo}:</strong> ${modelo.descricao} (${modelo.cor})</p>`,
            )
            .join("") || ""
        }
        currentIndex={selectedProduto ? filteredProducts.indexOf(selectedProduto) : 0}
        totalItems={filteredProducts.length}
        onNext={goToNext}
        onPrev={goToPrevious}
      />
    </div>
  )
}
